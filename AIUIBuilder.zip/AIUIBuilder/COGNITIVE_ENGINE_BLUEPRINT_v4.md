# COGNITIVE ENGINE — DEEP ANALYSIS & IMPLEMENTATION PLAN v4.0
## From Pipeline to Activation Network: The Brain-Inspired Architecture

**Date:** 2026-06-29
**Status:** Analysis + Implementation Plan (no code changes)
**Based on:** Source code (48 files), session dumps, ChatGPT's analysis, and 2025-2026 research on spreading activation, hippocampal memory, attention competition, and predictive processing.

---

## PART 0: WHAT THE CODEBASE ALREADY HAS

Before planning what to build, here's what already exists in the code:

### ✅ Already Implemented (Partial or Full)

| Component | Status | Where in Code |
|-----------|--------|---------------|
| **Spreading Activation** | Partial | `MemorySystems.kt:128` — `retrievalScore()` with `spreadingBoost` parameter |
| **Semantic Graph** | Partial | `SemanticNode` + `SemanticEdge` with `addNode()`, `addEdge()`, `getNeighbors()` |
| **Hebbian Learning** | Partial | `touchCount`, `newSinceTouch` on nodes; `computeSpreadingActivation()` |
| **Working Memory** | Exists | `WorkingMemory` object: 5 items, 800 chars, `loadFactor()` |
| **Episodic Memory** | Exists | `EpisodicMemory.record()`, `replayHighSurprise()` |
| **External Memory** | Exists | `ExternalMemory.writeNote()`, `retrieveRelevant()` |
| **Procedural Memory** | Exists | `ProceduralMemory.addSkill()`, `extractSkillFromTrace()` |
| **Metacognitive Monitor** | Exists | `decideNext()`, `isStuck()`, `detectContradictions()` |
| **Phase State Machine** | New | Deterministic ORIENT→DECOMPOSE→SOLVE→HYPOTHESIZE→VERIFY→INTEGRATE |
| **Belief Audit** | New | `auditBelief()` — checks for prompt echoes, circular reasoning |
| **Contradiction Detection** | New | `detectContradictions()` — negation patterns, word overlap |
| **Curiosity Operator** | New | `runCuriosity()` — generates alternatives for weak beliefs |
| **Hypothesis Testing** | New | `runHypothesize()` — combines solved chunks into testable hypothesis |
| **Memory Types** | New | orientation, plan, fact, analogy, hypothesis, prediction, verification |

### ❌ Missing (What ChatGPT Identified)

| Component | Status | What's Needed |
|-----------|--------|---------------|
| **Activation Network** | Missing | Nodes should have dynamic activation that spreads and decays |
| **Pattern Formation** | Missing | Store relational patterns, not just text strings |
| **Attention Competition** | Missing | Thoughts should compete; focus shifts when one wins |
| **Memory Reconsolidation** | Missing | Recall should update memory, not just read it |
| **Internal World Model** | Missing | Simulate before answering; predict then check |
| **Cognitive Energy** | Missing | Attention budget that depletes and restores |
| **Executive Control** | Basic | Monitor should track uncertainty, novelty, cognitive load |

---

## PART 1: THE ARCHITECTURE GAP (ChatGPT's Analysis Mapped to Code)

### Gap 1: Activation Network

**What ChatGPT said:**
> "Right now the engine stores memories. Instead it should maintain an activation graph. Each node has: activation, strength, confidence, novelty, recency, usefulness. When 'Function' activates... everything connected gets partial activation."

**What the code already has:**
```kotlin
// MemorySystems.kt:128
fun retrievalScore(node: SemanticNode, query: String, 
    lambdaCentrality: Float = 0.25f, spreadingBoost: Float = 0f): Float {
    // Spreading activation (Collins & Loftus, 1975)
    val activation = node.importance * (1f + spreadingBoost) *
        (1f / (1f + lambdaCentrality * node.touchCount))
}
```

**What's missing:**
- Activation doesn't actually SPREAD to neighbors when a node is accessed
- No decay over time (only interference-based decay via `newSinceTouch`)
- No competitive inhibition (activating one node doesn't suppress unrelated nodes)
- The `spreadingBoost` parameter is always passed as 0 — it's never computed

**Research grounding:**
- Collins & Loftus (1975): Spreading Activation Theory — activation spreads along associative links, strength determined by production frequency norms
- Anderson ACT-R (1983): Hebbian learning — neurons that fire together wire together
- OpenCog ECAN: Economic Attention Allocation — treats attention as an economic resource distributed over a graph
- SYNAPSE (arXiv:2601.02744, 2025): 34% reduction in hallucination via spreading activation

**Implementation plan:**
```
1. Add `activation: Float` field to SemanticNode (0.0 to 1.0)
2. When a node is accessed (retrieved, written, or referenced):
   a. Set activation = 1.0
   b. For each neighbor (via edges): neighbor.activation += 0.3 * edge.weight
   c. For each neighbor's neighbor: activation += 0.1 * edge.weight
3. After each operator: decay all activations by 0.05
4. WorkingMemory.load() should prefer HIGH activation nodes
5. When building prompts, include nodes with activation > 0.3
```

**Estimated effort: 2 hours**

---

### Gap 2: Pattern Formation

**What ChatGPT said:**
> "Your AI currently stores facts. Brains don't. Brains store patterns. Instead of 'Dogs bark' store: Animal → Dog → Produces Sound → Bark. Then wolf activates animal → sound → pack → dog → bark. Similarities emerge naturally."

**What the code already has:**
- `SemanticEdge` with relation types: SUPPORTS, CONTRADICTS, DEPENDS_ON, ISA, PART_OF, CAUSES, RELATED
- `addEdge()` and `getNeighbors()` in SemanticMemory

**What's missing:**
- Edges are rarely created. Most nodes are isolated (no edges to other nodes)
- No automatic edge creation when two nodes share concepts
- No pattern completion (given partial cue, reconstruct full pattern)

**Research grounding:**
- HiCL (arXiv:2508.16651, 2025): Hippocampal-inspired — DG does pattern separation, CA3 does pattern completion
- ZenBrain (arXiv:2604.23878, 2026): 7-layer memory with reconsolidation engine
- COLMA (arXiv:2509.13235, 2025): Knowledge-graph-style exploration expanding outward from core nodes

**Implementation plan:**
```
1. After SOLVE_CHUNK deposits a belief:
   a. Extract key concepts from the belief text
   b. Find existing nodes that share concepts
   c. Create edges: RELATED, CAUSES, ISA based on concept overlap
2. Implement pattern completion:
   a. Given a partial query, find the most activated node
   b. Follow edges to reconstruct the full pattern
   c. Include reconstructed pattern in the prompt
3. Implement pattern separation:
   a. When two beliefs are similar but different, create distinct nodes
   b. Use edge type CONTRADICTS or DEPENDS_ON to link them
```

**Estimated effort: 3 hours**

---

### Gap 3: Attention Competition

**What ChatGPT said:**
> "Every thought competetor. Neuron Hardware (0.91) → Transistor (0.73) → Ion channel (0.61). After exploring Physics: Physics (0.84) → Transistor (0.74) → Neuron (0.53). The focus shifts. Nothing is deleted. Only activation changes."

**What the code already has:**
- `WorkingMemory` with MAX_ITEMS = 5 — items are evicted when full
- `loadFactor()` — returns how full working memory is

**What's missing:**
- No competition between items for working memory slots
- Items are evicted by recency, not by activation/relevance
- No "focus shift" mechanism — the engine doesn't dynamically change what it's thinking about

**Research grounding:**
- Desimone & Duncan (1995): Biased Competition Framework — attention resolves competition by biasing processing toward task-relevant inputs
- Cowan (2001): Magical number 4 limit for short-term memory chunks
- Lee et al. (2026, Georgia Tech): Working memory capacity predicts multitasking through attention control, not storage

**Implementation plan:**
```
1. Replace WorkingMemory's simple list with a competition-based system:
   a. Each item has: activation, relevance, recency, importance
   b. Score = 0.4*activation + 0.3*relevance + 0.2*recency + 0.1*importance
   c. When loading, items compete: highest score wins
   d. When a new item enters, lowest-scoring item is evicted
2. Implement focus shift:
   a. Track currentFocusNodeId
   b. When a new node has higher activation than current focus, shift focus
   c. Log the shift: "Focus shifted from X to Y"
3. Implement competitive inhibition:
   a. When a node activates, suppress unrelated nodes by 0.1
   b. This creates natural "winner-take-all" dynamics
```

**Estimated effort: 2 hours**

---

### Gap 4: Memory Reconsolidation

**What ChatGPT said:**
> "Current: save memory. Brain: retrieve → modify → save again → connections strengthen. Every recall updates memory. That's called reconsolidation."

**What the code already has:**
- `SemanticNode.touchCount` — incremented on access
- `SemanticNode.lastTouchIter` — updated on access
- `newSinceTouch` — interference counter

**What's missing:**
- Recall doesn't MODIFY the memory content
- No "replay and update" mechanism
- No consolidation from short-term to long-term

**Research grounding:**
- Nature (2024): Generative model of memory construction — hippocampus encodes, generative networks consolidate via replay
- ZenBrain (2026): ReconsolidationEngine applies prediction-error-gated updates at read time
- HiCL (2025): CA3 autoassociative network for pattern completion + EWC for consolidation

**Implementation plan:**
```
1. When a node is retrieved for a prompt:
   a. Check if new information contradicts or extends it
   b. If yes: update node.content with new information
   c. Increase node.confidence if confirmed, decrease if contradicted
   d. Increment touchCount
2. Implement consolidation:
   a. After each session, replay high-surprise memories
   b. For each replayed memory, check if it can be generalized
   c. If yes: create a new "consolidated" node with higher importance
3. Implement forgetting:
   a. Nodes with low activation AND low touchCount AND old lastTouchIter
   b. Archive them (don't delete — just reduce retrieval priority)
```

**Estimated effort: 2 hours**

---

### Gap 5: Internal World Model

**What ChatGPT said:**
> "The engine shouldn't ask 'What's the answer?' Instead: build a small internal model → simulate it → observe → repair → repeat. Humans constantly imagine before answering."

**What the code already has:**
- `runHypothesize()` — creates a hypothesis from solved chunks
- `runVerify()` — checks claims against evidence

**What's missing:**
- No simulation/prediction step before verification
- No "imagine the consequences" mechanism
- No iterative repair loop

**Research grounding:**
- MAP (Nature, 2025): Predictor module predicts next state given action; Evaluator estimates value
- Predictive Processing (Friston): Brain reduces prediction error, not answers questions
- Embodied AI (IEEE Circuits & Systems, 2025): Joint MLLM-WM architecture for prediction

**Implementation plan:**
```
1. Add PREDICT operator:
   a. Given current beliefs, predict what would happen if they're correct
   b. Generate 2-3 testable predictions
   c. Store predictions as "prediction" type nodes
2. Add SIMULATE operator:
   a. Given a prediction, simulate the outcome
   b. Use the LLM to reason about: "If X is true, then Y should happen"
   c. Compare simulated outcome with actual evidence
3. Add REPAIR operator:
   a. If simulation reveals a mismatch, generate a repair
   b. Update the belief that caused the mismatch
   c. Re-simulate with updated belief
```

**Estimated effort: 3 hours**

---

### Gap 6: Cognitive Energy

**What ChatGPT said:**
> "I'd literally implement attention_budget = 100. Every operation spends energy. Interesting discoveries restore energy. Loops waste energy. High-value thoughts receive more computation."

**What the code already has:**
- `while (iterations < 20)` — hard iteration limit
- `MetacognitiveMonitor.MAX_ITERATIONS = 20`
- `consecutiveNoProgress` counter

**What's missing:**
- No energy/resource concept
- All operations cost the same (one iteration)
- No mechanism to allocate more compute to promising paths

**Research grounding:**
- OpenCog ECAN: Economic Attention Allocation — attention as economic resource
- Strategic Allocation Theory (Murray, 2024): Proactive vs reactive strategies with costs/benefits
- Value-directed prioritization (PMC, 2024): High-value items get more attention

**Implementation plan:**
```
1. Add cognitiveEnergy field to CognitiveEngine:
   var cognitiveEnergy = 100f
2. Each operator costs energy:
   - ORIENT: 5
   - DECOMPOSE: 10
   - SOLVE_CHUNK: 15
   - VERIFY: 20
   - HYPOTHESIZE: 15
   - CURIOSITY: 10
   - INTEGRATE: 5
3. Energy restoration:
   - High surprise (>0.5): +10 (interesting discovery)
   - New contradiction found: +5 (worth investigating)
   - High confidence belief confirmed: +5
4. Energy depletion penalties:
   - Repeated operator (stuck): -10
   - Low confidence output: -5
   - Contradiction with existing belief: -5
5. When energy <= 0: force INTEGRATE with current results
6. Allocate more tokens to operators when energy is high:
   - energy > 80: MAX_TOKENS * 1.2
   - energy < 30: MAX_TOKENS * 0.7
```

**Estimated effort: 1.5 hours**

---

### Gap 7: Executive Control (Enhanced Metacognitive Monitor)

**What ChatGPT said:**
> "Your monitor currently checks confidence, contradictions. I'd also monitor: uncertainty, novelty, cognitive load, repeated loops, exploration diversity, dead-end detection, forgotten important goals, reasoning depth, analogy quality."

**What the code already has:**
- `isStuck()` — detects repeated operators
- `consecutiveNoProgress` — tracks knowledge gain
- `detectContradictions()` — checks for conflicts
- `shouldExternalize()` — memory load check

**What's missing:**
- No uncertainty tracking
- No novelty detection
- No exploration diversity measure
- No dead-end detection
- No goal forgetting detection

**Implementation plan:**
```
1. Add to MetacognitiveMonitor:
   - uncertaintyHistory: track confidence over time
   - noveltyHistory: track surprise over time
   - explorationDiversity: count distinct operators used
   - goalProgress: track how many subgoals are solved vs total
2. Enhanced decideNext():
   - If uncertainty increasing for 3 iterations → force VERIFY
   - If novelty decreasing → force CURIOSITY
   - If exploration diversity < 3 operators used → try different operator
   - If dead-end (3 consecutive low-confidence outputs) → REFLECT
   - If important goal forgotten (goalStack has items not addressed) → retrieve
3. Add cognitive load estimation:
   - WorkingMemory.loadFactor() + pendingChunks.size + reasoningTrace.size
   - If load > 0.8 → SAVE_NOTE to offload
```

**Estimated effort: 2 hours**

---

## PART 2: IMPLEMENTATION ROADMAP

### Phase A: Activation Network + Attention Competition (4 hours)
**Impact: Highest | This transforms the engine from a pipeline to a network**

| Step | What | Files | Time |
|------|------|-------|------|
| A1 | Add `activation` field to SemanticNode | MemorySystems.kt | 15min |
| A2 | Implement spreadActivation() — when node accessed, spread to neighbors | MemorySystems.kt | 45min |
| A3 | Implement decayActivations() — decay all by 0.05 per operator | CognitiveEngine.kt | 15min |
| A4 | Replace WorkingMemory.load() with competition-based selection | MemorySystems.kt | 45min |
| A5 | Implement focus shift tracking | CognitiveEngine.kt | 30min |
| A6 | Add competitive inhibition (suppress unrelated nodes) | MemorySystems.kt | 30min |
| A7 | Build prompts from high-activation nodes, not just WorkingMemory | CognitiveEngine.kt | 30min |

### Phase B: Pattern Formation + Reconsolidation (5 hours)
**Impact: High | This makes memory actually evolve**

| Step | What | Files | Time |
|------|------|-------|------|
| B1 | Auto-create edges when beliefs share concepts | CognitiveEngine.kt | 1hr |
| B2 | Implement pattern completion (reconstruct from partial cue) | MemorySystems.kt | 1hr |
| B3 | Implement reconsolidation (recall updates memory) | MemorySystems.kt | 1hr |
| B4 | Implement consolidation (replay → generalize → store) | CognitiveEngine.kt | 1hr |
| B5 | Implement forgetting (archive low-activation nodes) | MemorySystems.kt | 30min |
| B6 | Display activation network in observatory | LiveObservatoryUi.kt | 30min |

### Phase C: Internal World Model (3 hours)
**Impact: High | This adds prediction and simulation**

| Step | What | Files | Time |
|------|------|-------|------|
| C1 | Add PREDICT operator (generate testable predictions) | CognitiveEngine.kt, ReasoningOperators.kt | 1hr |
| C2 | Add SIMULATE operator (imagine consequences) | CognitiveEngine.kt, ReasoningOperators.kt | 1hr |
| C3 | Add REPAIR operator (fix mismatched beliefs) | CognitiveEngine.kt | 45min |
| C4 | Integrate into phase state machine | CognitiveEngine.kt | 15min |

### Phase D: Cognitive Energy + Enhanced Executive Control (3.5 hours)
**Impact: Medium | This adds resource management**

| Step | What | Files | Time |
|------|------|-------|------|
| D1 | Add cognitiveEnergy to CognitiveEngine | CognitiveEngine.kt | 30min |
| D2 | Implement energy costs per operator | CognitiveEngine.kt | 30min |
| D3 | Implement energy restoration on discoveries | CognitiveEngine.kt | 30min |
| D4 | Add uncertainty/novelty/diversity tracking to MetacognitiveMonitor | MetacognitiveMonitor.kt | 1hr |
| D5 | Enhanced decideNext() with new signals | MetacognitiveMonitor.kt | 1hr |

### Phase E: Curiosity as Always-On (1 hour)
**Impact: Medium | This makes every operator ask "What am I missing?"**

| Step | What | Files | Time |
|------|------|-------|------|
| E1 | After each operator, generate one alternative hypothesis | CognitiveEngine.kt | 30min |
| E2 | Compare alternative with current belief | CognitiveEngine.kt | 15min |
| E3 | If alternative is stronger, switch to it | CognitiveEngine.kt | 15min |

---

## PART 3: TOTAL ESTIMATED EFFORT

| Phase | Hours | Impact |
|-------|-------|--------|
| A: Activation + Attention | 4 | Transforms pipeline → network |
| B: Pattern + Reconsolidation | 5 | Memory actually evolves |
| C: World Model | 3 | Prediction before answer |
| D: Energy + Executive | 3.5 | Resource management |
| E: Always-On Curiosity | 1 | Every step explores |
| **TOTAL** | **16.5** | |

**Minimum viable (A + B): 9 hours** — This alone would make the engine operate as an activation network with evolving memory, not a pipeline with static storage.

---

## PART 4: THE KEY INVARIANT

> "Intelligence is less about adding more reasoning phases and more about maintaining a continuously evolving network of activations, memories, goals, and predictions that compete, reinforce, weaken, and reconnect over time. That dynamic network—not the LLM—is what should become the 'brain.'" — ChatGPT

The LLM becomes one module in a larger cognitive system:
```
Memory (activation network)
    ↓
Attention (competition)
    ↓
Goal (current focus)
    ↓
Planner (phase state machine)
    ↓
Retriever (pattern completion)
    ↓
Simulation (world model)
    ↓
LLM (generation)
    ↓
Verifier (belief audit)
    ↓
Memory Update (reconsolidation)
```

---

*Blueprint v4.0 — Analysis only, no code changes.*
*Ready to implement when approved.*
