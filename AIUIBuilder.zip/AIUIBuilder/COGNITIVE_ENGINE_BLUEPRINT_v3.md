# COGNITIVE ENGINE — DEEP ANALYSIS & IMPLEMENTATION PLAN v3.0
## From Reasoning Transcript to Evolving Cognitive Process

**Date:** 2026-06-29
**Status:** Analysis + Implementation Plan (no code changes yet)
**Based on:** Source code analysis (47 files), session dumps, ChatGPT's analysis, and 2025-2026 research on agentic cognitive architectures, predictive processing, CoT faithfulness, and belief-state verification.

---

## PART 0: THE CORE DIAGNOSIS (One Paragraph)

The Cognitive Engine currently operates as a **single-shot question-answerer with
decorative logging**, not as an evolving cognitive process. ORIENT runs once,
the model produces an answer in a single LLM call, and INTEGRATE wraps it.
The "reasoning trace" is a post-hoc log of which operator ran, not a record of
how beliefs changed. Working memory never evolves — every node is ORIENT.
Confidence is a hardcoded float, not derived from evidence. The model's prompt
instructions (===JSON===, "Do not output anything else") leak into the reasoning
stream because they're part of the raw generation. There is no contradiction
detection, no curiosity-driven exploration, no hypothesis testing, and no
belief revision. The architecture has the *shape* of a cognitive pipeline but
not the *behavior* of one.

---

## PART 1: THE 9 CONCRETE PROBLEMS (Rooted in Code)

### Problem 1: Prompt Instructions Leak into Reasoning Stream

**Evidence from session dump:**
```
 Do not output anything else.
===JSON===
{"topic": "artificial brain neuron hardware", ...}
===JSON===
 Do not add any other words...
===JSON===
{"how_i_got_here": "...", "definition": "..."}
```

**Root cause in code:** `CognitiveEngine.buildPrompt()` (line 274):
```kotlin
return """
    |Current goal: $goal
    |
    |Active working memory (only relevant items):
    |${WorkingMemory.toPromptString()}
    |
    |$operatorPrompt
    |$jsonInstruction   ← THIS is the problem
""".trimMargin()
```

The `jsonInstruction` contains:
```
You may reason freely in your own words first -- think out loud...
When you have reached your answer, write the line ===JSON=== by itself...
```

This instruction text becomes part of the model's generation because:
1. The model sees it in the prompt
2. The model echoes it back in its output (especially small models)
3. `cumulativeThinking` captures EVERYTHING the model generates
4. The thinking stream shows this raw instruction text to the user

**Why it matters:** The user sees "Do not output anything else" as part of
the "reasoning." This is not reasoning — it's prompt echo. It makes the
engine look broken even when it's working.

**Research grounding:** SAVeR (arXiv:2604.08401, April 2026) shows that
unfaithful intermediate reasoning traces — including prompt echoes — lead to
"systematic behavioral drift in long-horizon agentic systems." The prompt
instructions should never enter the reasoning state.

---

### Problem 2: Only One Operator Ran (ORIENT → INTEGRATE, nothing between)

**Evidence:** Reasoning trace shows only:
```
[1] ORIENT -> Topic: artificial brain neuron hardware. Confusion: medium. Next: DECOMPOSE
```

Pipeline diagnostics show only GOAL_SELECTION completed. Everything else is PENDING.

**Root cause chain:**
1. ORIENT runs, returns `structured` with the hallucinated INTEGRATE JSON (because `extractJson` grabbed the wrong block — now fixed with `indexOf` instead of `lastIndexOf`)
2. Metacognitive monitor returns CONTINUE
3. `mapSignalToOperator(CONTINUE, ...)` — the model's `next_operator` field was null in the extracted JSON
4. Default was `"INTEGRATE"` (now fixed to `"DECOMPOSE"`)
5. INTEGRATE runs and breaks the loop

**Status:** Partially fixed. The `indexOf` fix and default-to-DECOMPOSE fix should
make ORIENT → DECOMPOSE → SOLVE_CHUNK work. But the deeper problem remains:
the metacognitive monitor doesn't drive the pipeline — it just follows the LLM.

---

### Problem 3: The Reasoning Isn't Discovering — It's Post-Hoc Rationalization

**Evidence:** The `how_i_got_here` field says:
> "I first asked what a brain neuron actually does at its membrane level..."

This was generated in a SINGLE LLM call during INTEGRATE. The model didn't
actually "ask" anything — it invented the narrative after the fact.

**Root cause in code:** `runIntegrate()` calls `buildIntegratePrompt()` which asks:
```
"how_i_got_here": narrate the actual reasoning path above in plain language,
  as a short story of the questions you asked yourself and what each one revealed
```

But `reasoningPath` is just `reasoningTrace.takeLast(12).joinToString("\n")`,
which is `[1] ORIENT -> Topic: ...`. The model sees almost no real path,
so it invents one.

**Research grounding:** Anthropic's "Reasoning models don't always say what
they think" (2025) and Turpin et al. (2023) show this is a fundamental LLM
failure mode: post-hoc rationalization. The model generates a plausible-sounding
narrative that has no causal relationship to how it actually reached the answer.

**Why it matters:** The user sees a "reasoning path" that looks thoughtful but
is entirely fabricated. This undermines trust in the entire cognitive engine.

---

### Problem 4: Working Memory Never Evolves

**Evidence:** Memory snapshot shows:
```
[problem] Root topic (conf=1.00, imp=1.00) — "hi"
[claim] ORIENT result (conf=0.90, imp=0.85) — "Topic: hi..."
[claim] ORIENT result (conf=0.96, imp=0.94) — "Topic: How to make..."
[claim] ORIENT result (conf=0.94, imp=0.91) — "Topic: How to make..."
[claim] ORIENT result (conf=0.92, imp=0.88) — "Topic: How to make..."
```

Every node is an ORIENT result. No hypotheses, no verified facts, no
analogies, no solved chunks. Memory accumulates ORIENT outputs from
multiple sessions but never evolves within a session.

**Root cause in code:** Memory nodes are only written by:
- `runOrient` → writes to `reasoningTrace` only (not SemanticMemory)
- `runFirstPrinciples` → writes ONE node
- `REFLECT` and `INTEGRATE` → writes at the END of the loop
- `runSolveChunk` → NOW writes to SemanticMemory (our fix), but SOLVE_CHUNK never runs (Problem 2)

The core issue: most operators don't write to SemanticMemory. They produce
text output that goes into `lastResult.output` and is never stored.

---

### Problem 5: Confidence Is a Hardcoded Float, Not Derived from Evidence

**Evidence:** "Confidence: 75.0%" — but no evidence was gathered, no tests
were run, no verification happened.

**Root cause in code:**
- `runOrient`: `confidence = 0.8f` (hardcoded)
- `runDecompose`: `confidence = 0.75f` (hardcoded)
- `runFirstPrinciples`: `confidence = 0.7f` (hardcoded)
- `runAnalogize`: `confidence = 0.65f` (hardcoded)
- `runSolveChunk`: `confidence = when(structured["confidence"]) { "high" -> 0.9f ... }` (from LLM self-report)

The LLM self-reports its confidence, and we trust it. But a model that
hasn't verified anything has no basis for confidence.

**Research grounding:** CoALA (arXiv:2309.02427, 2024) and BeliefMem
(arXiv:2605.05583, 2026) show that confidence must be derived from
evidence aggregation, not self-report. A belief's confidence should be
a function of: how many independent sources support it, whether it
survived verification, and whether it contradicts other beliefs.

---

### Problem 6: No Curiosity-Driven Exploration

**Evidence:** The engine never asks "What if...?" or "Wait, but..." or
"Could it instead be...?" It simply explains.

**Root cause:** There is no curiosity operator. The metacognitive monitor
decides based on stuckness and confidence, not on information gain.
There's no mechanism to generate alternative hypotheses and compare them.

**Research grounding:** Loewenstein (1994) information gap theory;
Oudeyer & Kaplan (2007) learning progress as intrinsic motivation;
the brain-inspired MAP architecture (Nature, 2025) which uses an
Evaluator to estimate the value of exploring alternative states.

---

### Problem 7: No Contradiction Detection

**Evidence:** The engine never says "Wait, this doesn't match what I
said earlier." There's no mechanism to compare new outputs against
existing beliefs.

**Root cause:** No operator checks for consistency. `runVerify` checks
against external evidence (web search), but there's no internal
consistency check between beliefs in SemanticMemory.

**Research grounding:** SAVeR (2026) identifies `Contradiction` as one
of 6 faithfulness violation types. The architecture needs a lightweight
consistency gate that runs after every operator.

---

### Problem 8: The ===JSON=== Marker System Is Fragile

**Evidence:** The model produces multiple `===JSON===` markers in a
single response, and `extractJson` has to guess which one is "real."

**Root cause:** Small models (1.5B-7B running on a phone) don't reliably
follow formatting instructions. They echo prompt text, produce multiple
markers, truncate JSON mid-string, and generate arrays when objects are
expected (and vice versa).

**Why the current approach is fragile:**
- `extractJson` uses `indexOf` (first marker) — but the model sometimes
  produces the WRONG JSON first and the correct one second
- `extractBalancedFromEnd` scans backward — but truncated JSON has
  unbalanced braces
- `callModelExpectingJson` retries with a correction prompt — but the
  retry also echoes prompt text

**Research grounding:** RLM (Recursive Language Models, MIT CSAIL, 2025)
shows that treating the prompt as a variable in a REPL — rather than
passing it to the context window — gives the model control over its own
decomposition strategy. This is the opposite of our approach (we control
the decomposition and the model just generates text).

---

### Problem 9: The Metacognitive Monitor Measures Activity, Not Knowledge

**Evidence:** The monitor tracks `operatorHistory` and `surpriseHistory`,
but never asks: "Did we learn anything new this iteration?"

**Root cause in code:** `MetacognitiveMonitor.decideNext()` checks:
- Budget exhaustion (iteration count)
- Adaptive early exit (confidence + surprise)
- Stuckness (same operator repeating)
- Low confidence → VERIFY
- All chunks solved → INTEGRATE
- Problem broad → DECOMPOSE

It NEVER checks:
- Did `solvedChunks` grow since last iteration?
- Did any belief's confidence change?
- Are there contradictions between beliefs?
- Is the current operator producing new information?

---

## PART 2: THE ARCHITECTURE WE NEED (Based on Research)

### The Predictive Processing Model

The brain doesn't "answer questions" — it reduces prediction error.
The architecture should be:

```
Current Belief State (Mental Model)
    ↓
Prediction: "If my model is correct, then X should be true"
    ↓
Reality Check: Test X against evidence, memory, or logic
    ↓
Error Signal: Prediction matched? → Strengthen belief
              Prediction failed? → Revise belief, generate new hypothesis
    ↓
Updated Belief State
    ↓
Next highest-uncertainty area → new focus
```

This is fundamentally different from the current model:
```
Current: Question → Operator → Text Output → Next Operator
Needed:  Belief → Prediction → Test → Error → Revised Belief
```

### The SAVeR Framework (Self-Audited Verified Reasoning)

From arXiv:2604.08401 (April 2026), the key insight is:

> "Coherent reasoning can still violate logical or evidential constraints,
> allowing unsupported beliefs repeatedly stored and propagated across
> decision steps, leading to systematic behavioral drift."

The fix: **Verify before commit.** Every belief must pass an audit before
being stored in memory. The audit checks for:
1. Missing Assumption
2. Invalid Precondition
3. Unjustified Inference
4. Circular Reasoning
5. Contradiction
6. Overgeneralization

### The Modular Agentic Planner (MAP)

From Nature (2025), the brain-inspired architecture uses specialized modules:
- **Task Decomposer** — breaks goals into subgoals
- **Actor** — generates proposed actions
- **Monitor** — gates actions against constraints
- **Predictor** — predicts next state given action
- **Evaluator** — estimates value of predicted state
- **Orchestrator** — coordinates modules, detects completion

Our engine has Task Decomposer (DECOMPOSE) and Actor (SOLVE_CHUNK), but
no Predictor, Evaluator, or Monitor.

---

## PART 3: IMPLEMENTATION PLAN (5 Phases, Ordered by Impact)

### PHASE 1: Stop the Leaks, Fix the Flow (1-2 hours)
**Impact: High | Risk: Low | Files: CognitiveEngine.kt, ReasoningOperators.kt**

**1.1 — Separate system prompt from reasoning stream**

In `buildPrompt()`, move `jsonInstruction` OUT of the prompt that gets fed
back into the thinking stream. The instruction should be a system-level
directive, not part of the model's "thinking."

Implementation:
- Add a `systemDirective` parameter to `buildPrompt()`
- The `jsonInstruction` goes into the system directive (not echoed in output)
- The thinking stream only captures the model's actual reasoning, not
  the formatting instructions

**1.2 — Strip prompt echoes from the thinking stream**

In `CognitivePanel.kt`'s pollJob, filter out known prompt fragments:
```kotlin
val cleaned = progressText
    .replace(Regex("===JSON==="), "")
    .replace(Regex("Do not [aA]dd.*?\\."), "")
    .replace(Regex("Output ONLY.*?\\."), "")
    .replace(Regex("You may reason freely.*?\\."), "")
```

This is a cosmetic fix — the real fix is 1.1 — but it immediately
improves the user experience.

**1.3 — Make operators write to SemanticMemory**

Every operator should deposit its result as a belief node:
- ORIENT → `type: "orientation"`, content = topic + unknowns
- DECOMPOSE → `type: "plan"`, content = chunk list
- FIRST_PRINCIPLES → already writes a node (good)
- ANALOGIZE → `type: "analogy"`, content = mapping + insight
- SOLVE_CHUNK → already writes (our fix)
- VERIFY → `type: "verification"`, content = verdict + evidence

This makes the memory snapshot actually show the reasoning evolution.

---

### PHASE 2: Real Operator Sequencing (2-3 hours)
**Impact: High | Risk: Medium | Files: CognitiveEngine.kt, MetacognitiveMonitor.kt**

**2.1 — Implement a phase state machine**

Instead of letting the LLM choose the next operator, implement a
deterministic phase state machine:

```
Phase 1: ORIENT (once, always first)
Phase 2: DECOMPOSE (1-2 rounds, max 6 chunks)
Phase 3: SOLVE (iterate through all pending chunks)
Phase 4: HYPOTHESIZE (combine solved chunks into a testable hypothesis)
Phase 5: VERIFY (check hypothesis against evidence)
Phase 6: INTEGRATE (synthesize final answer)
```

Transitions are deterministic, not LLM-driven:
- ORIENT always → DECOMPOSE
- DECOMPOSE always → SOLVE (first chunk)
- SOLVE → SOLVE (next chunk) or HYPOTHESIZE (if all solved)
- HYPOTHESIZE → VERIFY
- VERIFY → INTEGRATE (if supported) or SOLVE (if contradicted)
- INTEGRATE → STOP

The metacognitive monitor can OVERRIDE these transitions (e.g., if stuck,
skip to INTEGRATE with partial results), but the DEFAULT path is fixed.

**2.2 — Make each operator change internal state**

Currently, operators produce text. They should produce STATE CHANGES:
- SOLVE_CHUNK: adds a BeliefNode to SemanticMemory (already done)
- VERIFY: updates the BeliefNode's confidence based on evidence
- HYPOTHESIZE: creates a new BeliefNode that references solved chunks
- REFLECT: updates the metacognitive state (stuck counter, strategy)

**2.3 — Implement the HYPOTHESIZE operator**

After all chunks are solved, HYPOTHESIZE combines them:
```
Input: all solved chunk answers
Output: a testable hypothesis that combines the answers
        + predicted consequences that can be verified
```

This is the "What if we combine what we know?" step that's currently missing.

---

### PHASE 3: Belief Verification & Contradiction Detection (2-3 hours)
**Impact: High | Risk: Medium | Files: CognitiveEngine.kt, MetacognitiveMonitor.kt, new file: BeliefVerifier.kt**

**3.1 — Implement a lightweight belief audit (SAVeR-inspired)**

After every operator produces a result, run a quick audit:
```kotlin
data class BeliefAudit(
    val hasUnsupportedClaim: Boolean,    // claim with no evidence
    val hasContradiction: Boolean,       // contradicts existing belief
    val hasCircularReasoning: Boolean,   // restates the question as answer
    val isPostHocRationalization: Boolean // narrative without causal steps
)
```

The audit is a SINGLE LLM call with a structured prompt:
```
Given the following belief and existing knowledge base,
check for: unsupported claims, contradictions, circular reasoning.
Output JSON: {"unsupported": bool, "contradiction": bool, "circular": bool, "issue": "description"}
```

If any flag is true → trigger REFLECT or re-SOLVE.

**3.2 — Implement contradiction detection between beliefs**

After SOLVE_CHUNK deposits a new belief, check it against existing beliefs:
```kotlin
fun detectContradictions(newBelief: BeliefNode, existing: List<BeliefNode>): List<BeliefNode> {
    // Quick heuristic: check for negation patterns
    // "X is true" vs "X is not true"
    // "A causes B" vs "B causes A"
    // If heuristic flags a pair → LLM verification call
}
```

**3.3 — Implement belief revision**

When a contradiction is detected:
1. Compare confidence of both beliefs
2. If new belief has higher confidence → archive old belief
3. If old belief has higher confidence → reject new belief
4. If similar confidence → flag for VERIFY

---

### PHASE 4: Curiosity & Hypothesis Testing (2-3 hours)
**Impact: Medium | Risk: Medium | Files: CognitiveEngine.kt, MetacognitiveMonitor.kt, ReasoningOperators.kt**

**4.1 — Implement a curiosity operator**

After solving a chunk, generate 2-3 alternative explanations:
```
Current belief: "Transistors can simulate neuron membrane potential"
Alternative 1: "What if memristors are better because they have inherent plasticity?"
Alternative 2: "What if analog circuits are better than digital for this?"
→ Pick the most surprising alternative → VERIFY it
```

This is the "What if...?" behavior that ChatGPT identified as missing.

**4.2 — Implement prediction-based verification**

Instead of just asking "is this true?", predict a consequence and test it:
```
Hypothesis: "A capacitor + comparator can simulate a neuron"
Prediction: "This circuit should produce spike-timing-dependent plasticity"
Test: "Does the circuit's output change based on input timing?"
```

This is the Predictive Processing model from the brain-inspired MAP
architecture (Nature, 2025).

**4.3 — Implement information-gain-based chunk selection**

Instead of solving chunks in order, select the one with highest
information gain:
```kotlin
fun selectNextChunk(chunks: List<String>, beliefs: Map<String, BeliefNode>): String {
    return chunks.maxBy { chunk ->
        // CuriosityScore = uncertainty × relevance × novelty
        val uncertainty = 1.0f - (beliefs[chunk]?.confidence ?: 0f)
        val relevance = semanticSimilarity(chunk, originalQuery)
        val novelty = 1.0f - beliefs[chunk]?.let { overlapWithExisting(it) } ?: 0f
        uncertainty * relevance * novelty
    }
}
```

---

### PHASE 5: Confidence Calibration & Knowledge Delta (1-2 hours)
**Impact: Medium | Risk: Low | Files: MetacognitiveMonitor.kt, CognitiveEngine.kt**

**5.1 — Derive confidence from evidence, not self-report**

Replace LLM-reported confidence with computed confidence:
```kotlin
fun computeConfidence(belief: BeliefNode, evidence: List<Evidence>): Float {
    var conf = 0.5f  // prior
    evidence.forEach { e ->
        when (e.type) {
            "code_execution" -> conf += 0.2f  // empirical evidence
            "web_search" -> conf += 0.15f     // external grounding
            "logical_derivation" -> conf += 0.1f  // deductive
            "analogy" -> conf += 0.05f        // weak evidence
        }
    }
    // Contradictions reduce confidence
    conf -= contradictions.size * 0.15f
    return conf.coerceIn(0.05f, 0.95f)
}
```

**5.2 — Implement KnowledgeDelta tracking**

Track the change in knowledge per iteration:
```kotlin
data class KnowledgeDelta(
    val beliefsAdded: Int,
    val beliefsRevised: Int,
    val beliefsRejected: Int,
    val averageConfidenceChange: Float,
    val contradictionsFound: Int,
    val netProgress: Float  // positive = learning, zero = stuck
)
```

If `netProgress ≈ 0` for 3 consecutive iterations → the engine is stuck.
Force INTEGRATE with partial results.

**5.3 — Display KnowledgeDelta in the observatory**

Add a new section to `LiveObservatoryUi.kt`:
```
KNOWLEDGE DELTA
  Beliefs: +3 added, 1 revised, 0 rejected
  Confidence: +0.15 avg change
  Contradictions: 0
  Net Progress: +0.42 (LEARNING)
```

---

## PART 4: WHAT TO BUILD FIRST (Priority Order)

| Priority | Phase | What | Impact | Risk | Time |
|----------|-------|------|--------|------|------|
| **P0** | 1.1 | Strip prompt echoes from thinking stream | High | Low | 30min |
| **P0** | 1.3 | Make ORIENT/DECOMPOSE/ANALOGIZE write to SemanticMemory | High | Low | 30min |
| **P1** | 2.1 | Phase state machine (deterministic operator sequencing) | High | Medium | 1hr |
| **P1** | 2.2 | Make operators change internal state | High | Medium | 1hr |
| **P2** | 3.1 | Lightweight belief audit after each operator | High | Medium | 1.5hr |
| **P2** | 3.2 | Contradiction detection between beliefs | Medium | Medium | 1hr |
| **P3** | 4.1 | Curiosity operator (alternative hypotheses) | Medium | Medium | 1.5hr |
| **P3** | 5.1 | Confidence from evidence, not self-report | Medium | Low | 1hr |
| **P4** | 4.2 | Prediction-based verification | Medium | High | 2hr |
| **P4** | 5.2 | KnowledgeDelta tracking + display | Medium | Low | 1hr |

**Total estimated time: ~12 hours for full implementation**

**Minimum viable improvement (P0 + P1): ~3 hours**
This alone would make the engine go from ORIENT → INTEGRATE to
ORIENT → DECOMPOSE → SOLVE_CHUNK × 4 → INTEGRATE, with beliefs
written to memory at each step.

---

## PART 5: WHAT NOT TO CHANGE

- **Do not modify files on the "do not modify" list** (RefinerCore.kt, MesaEngine.kt, etc.)
- **Do not change the UI** (CognitivePanel.kt's visual layout, BreathingThinkingPanel, etc.)
- **Do not change the JNI/native bridge** (NativeRecursiveRefiner)
- **Do not change the prompt marker system** (===JSON===) — it works, just needs cleanup
- **Do not add new dependencies** — keep everything in pure Kotlin

---

## PART 6: RESEARCH PAPERS THAT JUSTIFY THIS PLAN

| Concept | Paper | Year | Key Insight |
|---------|-------|------|-------------|
| Faithful reasoning verification | SAVeR (arXiv:2604.08401) | 2026 | Verify belief states before action commitment |
| Post-hoc rationalization | Anthropic "Reasoning models don't always say what they think" | 2025 | CoT is often unfaithful; structure enables verification |
| Typed CoT verification | arXiv:2510.01069 | 2025 | Faithful reasoning = well-typed program |
| Brain-inspired planning | MAP (Nature, 2025) | 2025 | Modular: Predictor + Evaluator + Orchestrator |
| Cognitive architectures | CoALA (arXiv:2309.02427) | 2024 | Decision procedures for knowledge management |
| Belief propagation | BeliefMem (arXiv:2605.05583) | 2026 | Noisy-OR evidence aggregation for confidence |
| Predictive processing | Friston; ScienceDirect | 2005-2025 | Brain reduces prediction error, not answers questions |
| Curiosity as intrinsic motivation | Oudeyer & Kaplan | 2007 | Learning progress drives exploration |
| Spreading activation | Anderson ACT-R | 1983 | Hebbian learning in semantic networks |
| LLM reasoning is latent | arXiv:2604.15726 | 2026 | Surface CoT ≠ internal computation |

---

*Blueprint v3.0 — Analysis only, no code changes.*
*Next step: Implement P0 + P1 (Phase 1.1, 1.3, 2.1, 2.2) for minimum viable improvement.*
