KaTeX font binaries are embedded as UTF-8 base64 data URIs inside ../katex.min.css so the canonical source sync remains lossless.
