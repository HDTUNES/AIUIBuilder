package com.arena.aiuibuilder

import androidx.compose.ui.text.font.FontWeight

/**
 * v10.1 — single source of truth for generated prose weights.
 * Font sizes are intentionally not changed here.
 */
object AppTypography {
    val ProseWeight: FontWeight = FontWeight.Light
    val HeadingWeight: FontWeight = FontWeight.Bold
    val ThinkingWeight: FontWeight = FontWeight.Thin
    val CodeWeight: FontWeight = FontWeight.Normal
}
