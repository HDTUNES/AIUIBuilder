package com.arena.aiuibuilder

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun WebSearchToggleSwitch(enabled: Boolean, onToggle: (Boolean) -> Unit, label: String = "🌐 Live Web Search (Top 3)") {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Router decides 100% when to fetch. Injects hard context mandatory for factual grounding.", color = Color(0xFF94A3B8), fontSize = 11.sp)
        }
        Switch(
            checked = enabled,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF38BDF8),
                checkedTrackColor = Color(0xFF1E3A8A)
            )
        )
    }
}

@Composable
fun SearchLiveFeedbackBlock(searchProcess: String, isGenerating: Boolean) {
    var expanded by remember { mutableStateOf(false) }
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = BorderStroke(1.dp, Color(0xFF0284C7)),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.weight(1f).clickable { expanded = !expanded }) {
                    val label = when {
                        isGenerating && expanded -> "🌐 Active Search Router Executing (Expanded)..."
                        isGenerating -> "🌐 Router: Mandatory Web Fetch (Tap to expand)"
                        expanded -> "🌐 Verified Factual Web Grounding"
                        else -> "🌐 Verified Web Grounding (Tap to expand)"
                    }
                    ThinkingGlareText(label, isGenerating)
                }
            }
            if (expanded || isGenerating) {
                Text(
                    text = searchProcess,
                    color = Color(0xFFBAE6FD),
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .background(Color(0xFF0B1220), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                        .heightIn(max = 180.dp)
                        .verticalScroll(rememberScrollState())
                )
            }
        }
    }
}

@Composable
fun WebSearchAnimationBadge(query: String) {
    val transition = rememberInfiniteTransition(label = "web-radar")
    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1200, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "radar-sweep"
    )
    val brush = Brush.linearGradient(
        colors = listOf(
            Color(0xFF0284C7),
            Color(0xFF7DD3FC),
            Color(0xFFFFFFFF),
            Color(0xFF7DD3FC),
            Color(0xFF0284C7)
        ),
        start = androidx.compose.ui.geometry.Offset(0f + offset * 800f, 0f),
        end = androidx.compose.ui.geometry.Offset(300f + offset * 800f, 0f)
    )
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220)),
        border = BorderStroke(1.dp, Color(0xFF0284C7)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🌐", fontSize = 16.sp)
            Text(
                text = "Router routing web search: \"${query.take(35)}\"...",
                style = androidx.compose.ui.text.TextStyle(brush = brush, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            )
        }
    }
}

@Composable
fun WebSearchResultsBar(results: List<SearchResult>) {
    if (results.isEmpty()) return
    var expandedId by remember { mutableStateOf<Int?>(null) }
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("🌐 Hard Context Injection Sources (Top ${results.size})", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        results.forEach { r ->
            val isExpanded = expandedId == r.id
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, if (isExpanded) Color(0xFF38BDF8) else Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth().clickable { expandedId = if (isExpanded) null else r.id }
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("[${r.id}]", color = Color(0xFF7DD3FC), fontWeight = FontWeight.Bold)
                        Text(r.title, color = Color(0xFFF1F5F9), fontWeight = FontWeight.Medium, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    }
                    if (isExpanded) {
                        Text(r.url, color = Color(0xFF94A3B8), fontSize = 11.sp)
                        Text(r.snippet, color = Color(0xFFCBD5E1), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}
