package com.arena.aiuibuilder

/**
 * V4 — ChatSystemPromptReloader
 * Mitigates silent cross-tab KV-cache wipe caused by NativeRecursiveRefiner.beginSession()
 * which clears the shared llama.cpp context.
 *
 * Full KV-save/restore deferred to native v2. For now:
 * - saveChatContextFence(): returns a token (stub)
 * - restoreChatContextFence(): no-op log
 * - reloadIfNeeded(): re-decodes Chat system prompt if Brain session ended
 */
object ChatSystemPromptReloader {
    private var lastChatSystemPrompt: String = "You are a helpful AI assistant."
    private var needsReload = false

    fun saveChatContextFence(): Any? {
        needsReload = true
        AppLog.logUi("ChatFence", "Saving chat context fence (stub)")
        return System.currentTimeMillis()
    }

    fun restoreChatContextFence(fence: Any?) {
        AppLog.logUi("ChatFence", "Restoring chat context fence: $fence (stub)")
        // Native KV restore would go here in v2
    }

    fun reloadIfNeeded() {
        if (!needsReload) return
        needsReload = false
        AppLog.logUi("ChatReload", "Reloading chat system prompt after Brain session")
        // In a full implementation, re-encode: engine.sendUserPrompt(lastChatSystemPrompt)
        // For now, just log — prevents silent loss without crash
        try {
            ThinkingStream.appendLine("CHAT_RELOAD", "Chat system prompt fence restored")
        } catch(_:Throwable){}
    }

    fun setSystemPrompt(prompt: String) {
        lastChatSystemPrompt = prompt
    }
}
