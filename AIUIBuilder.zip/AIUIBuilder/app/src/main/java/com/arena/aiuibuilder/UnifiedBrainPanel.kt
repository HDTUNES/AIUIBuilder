package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnifiedBrainPanel(
    engine: InferenceEngine,
    enabled: Boolean,
    vm: AppSessionViewModel,
    onStatus: (String)->Unit,
    onError: (String)->Unit
){
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(BrainMode.SYNTHESIZE) }
    var isRunning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<UnifiedBrainEngine.BrainResult?>(null) }
    val scope = rememberCoroutineScope()
    var job by remember { mutableStateOf<Job?>(null) }

    val callModel: suspend(String,Int)->String = { prompt, tokens ->
        val t0 = SystemClock.elapsedRealtime()
        try {
            ThinkingStream.appendLine("LLM_START", "prompt ${prompt.length}c ~${prompt.length/4}tok max=$tokens")
            val out = withContext(Dispatchers.IO){
                NativeRecursiveRefiner.generateGrounded(prompt, tokens, 0.45f,40,0.9f,0.05f,1.1f)
            }
            val dt = SystemClock.elapsedRealtime() - t0
            val tokOut = out.length/4
            val tps = if(dt>0) tokOut*1000f/dt else 0f
            ThinkingStream.appendLine("LLM_END", "${dt}ms ~${tokOut}tok ${"%.2f".format(tps)} tok/s")
            ObservatoriumSession.liveTokenStream = out.takeLast(240)
            ThinkingStream.append(out)
            out
        } catch(e:Throwable){
            ThinkingStream.appendLine("LLM_ERR", e.message ?: "err")
            ""
        }
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)){
        Text("Brain — Meta-Cognitive Reasoning", color=Color(0xFFE5E7EB), fontSize=20.sp, fontWeight=FontWeight.Bold)
        Text("One brain, two conditions: Self-Evolve (infinite) • Synthesize (conclude)", color=Color(0xFF94A3B8), fontSize=13.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)){
            FilterChip(selected = mode==BrainMode.SELF_EVOLVE, onClick={mode=BrainMode.SELF_EVOLVE; try{vm.setBrainMode(mode)}catch(_:Throwable){}}, label={Text("Self-Evolve")})
            FilterChip(selected = mode==BrainMode.SYNTHESIZE, onClick={mode=BrainMode.SYNTHESIZE; try{vm.setBrainMode(mode)}catch(_:Throwable){}}, label={Text("Synthesize")})
        }
        OutlinedTextField(query, {query=it}, Modifier.fillMaxWidth(), label={Text("Enter complex question")}, minLines=3)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically){
            Button(enabled = enabled && query.isNotBlank() && !isRunning, onClick = {
                isRunning=true; result=null; ThinkingStream.clear(); ThinkingStream.setExpanded(true); PipelineTimer.reset()
                job = scope.launch(Dispatchers.IO){
                    try{
                        val chatFence = try { ChatSystemPromptReloader.saveChatContextFence() } catch(_:Throwable){null}
                        try {
                            withContext(Dispatchers.IO){ NativeRecursiveRefiner.beginSession("You are a careful systematic brain-reasoner. Q: $query") }
                            val brain = UnifiedBrainEngine(context, callModel)
                            val res = brain.run(query, BrainConfig(mode=mode), onStage={s,n->}, onToken={})
                            withContext(Dispatchers.Main){ result=res; onStatus("Done ${res.iterations} iter, conf ${(res.confidence*100).toInt()}%") }
                        } finally {
                            runCatching { withContext(Dispatchers.IO){ NativeRecursiveRefiner.resetSession() } }
                            runCatching { ChatSystemPromptReloader.restoreChatContextFence(chatFence) }
                            runCatching { ChatSystemPromptReloader.reloadIfNeeded() }
                        }
                    } catch(t:Throwable){
                        withContext(Dispatchers.Main){ onError(t.message?:"$t") }
                        AppLog.appendError("Brain run failed", t)
                    } finally {
                        withContext(Dispatchers.Main){ isRunning=false }
                    }
                }
            }){ Text(if(mode==BrainMode.SELF_EVOLVE) "Evolve ∞" else "Synthesize") }

            if(isRunning){
                OutlinedButton(onClick={ job?.cancel(); isRunning=false }){ Text("Stop") }
                Button(onClick={
                    mode = BrainMode.SYNTHESIZE
                    try{ vm.setBrainMode(mode) }catch(_:Throwable){}
                    onStatus("Conclude requested — braking at next checkpoint…")
                    ThinkingStream.appendLine("USER", "Conclude requested")
                }){ Text("Conclude →") }
            }
        }

        ThinkingBlock(isActive = isRunning)

        // Pipeline timer strip V4.1
        val timerSpans by PipelineTimer.live.collectAsState()
        if(timerSpans.isNotEmpty()){
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220)), border = BorderStroke(1.dp, Color(0xFF1E293B)), modifier = Modifier.fillMaxWidth()){
                Column(Modifier.padding(10.dp)){
                    Text("Pipeline timing — last ${timerSpans.size}", color=Color(0xFF64748B), fontSize=11.sp)
                    timerSpans.takeLast(8).forEach{
                        Text("${it.stage}  ${it.ms}ms  in=${it.tokensIn}  ${if(!it.ok)"FAIL" else ""}",
                            color=if(it.ms>5000) Color(0xFFF87171) else Color(0xFF94A3B8),
                            fontSize=11.sp, fontFamily = FontFamily.Monospace)
                    }
                    val sumLine = try { PipelineTimer.summary().lines().lastOrNull() ?: "" } catch(_:Throwable){ "" }
                    if(sumLine.isNotBlank()) Text(sumLine, color=Color(0xFF475569), fontSize=10.sp)
                }
            }
        }

        // Observatory
        try {
            LiveObservatoryPanel(
                iterationNumber = ObservatoriumSession.currentIterationNumber,
                stageMap = ObservatoriumSession.stageMap,
                liveTokenStream = ObservatoriumSession.liveTokenStream
            )
        } catch(e:Throwable){
            Text("Observatory temporarily unavailable: ${e.message}", color=Color(0xFFF87171), fontSize=12.sp)
        }

        result?.let{ res ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = BorderStroke(1.dp, Color(0xFF263244)), modifier = Modifier.fillMaxWidth()){
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)){
                    Text("Reasoning + Final Answer", color=Color.White, fontWeight=FontWeight.Bold)
                    var showTrace by remember { mutableStateOf(true) }
                    Text(if(showTrace)"▼ Hide thinking trace" else "▶ Show thinking trace",
                        color=Color(0xFF7C3AED), fontSize=12.sp,
                        modifier = Modifier.clickable{ showTrace=!showTrace })
                    if(showTrace){
                        Text(res.structured.howArrived.take(2000), color=Color(0xFF94A3B8), fontSize=12.sp, fontFamily = FontFamily.Monospace)
                        if(res.adjacentInsights.isNotEmpty()){
                            Spacer(Modifier.height(4.dp))
                            Text("Peripheral insights:", color=Color(0xFFA78BFA), fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                            res.adjacentInsights.take(5).forEach{ Text("• $it", color=Color(0xFFC4B5FD), fontSize=12.sp) }
                        }
                    }
                    Divider(color=Color(0xFF1E293B))
                    Text("Step-by-step", color=Color.White, fontWeight=FontWeight.SemiBold)
                    if(res.structured.stepByStep.isNotEmpty()){
                        res.structured.stepByStep.forEach{ Text("• $it", color=Color(0xFFE5E7EB), fontSize=14.sp) }
                    } else {
                        Text("• Analyze → Model → Test → Refine", color=Color(0xFFE5E7EB), fontSize=14.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("Hypothesis / Final Answer", color=Color.White, fontWeight=FontWeight.SemiBold)
                    try {
                        LatexAwareText(res.structured.hypothesis, color=Color(0xFFE5E7EB))
                    } catch(_:Throwable){
                        Text(res.structured.hypothesis, color=Color(0xFFE5E7EB), fontSize=14.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Summary", fontWeight=FontWeight.SemiBold, color=Color.White)
                    Text(res.structured.summary, color=Color(0xFFCBD5E1), fontSize=14.sp)
                    Text("Confidence ${(res.confidence*100).toInt()}% • ${res.iterations} iterations • ${res.modelCheckpoints.size} checkpoints • ${res.adjacentInsights.size} peripheral insights",
                        color=Color(0xFF64748B), fontSize=11.sp)
                }
            }
        }
    }
}

// minimal imports to satisfy compiler hints — actual file relies on project-wide imports
import android.os.SystemClock
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
