package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    vm: AppSessionViewModel,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = ObsColors.BgPanel,
        dragHandle = {
            Box(modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), contentAlignment = Alignment.Center) {
                Box(modifier = Modifier.width(36.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(ObsColors.BorderMid))
            }
        }
    ) {
        val threads by vm.threads.collectAsState()
        val contextSize by vm.contextSize.collectAsState()
        val batchSize by vm.batchSize.collectAsState()
        val temperature by vm.temperature.collectAsState()
        val maxTokens by vm.maxTokens.collectAsState()
        val topK by vm.topK.collectAsState()
        val topP by vm.topP.collectAsState()
        val minP by vm.minP.collectAsState()
        val repeatPenalty by vm.repeatPenalty.collectAsState()
        val refinePasses by vm.refinePasses.collectAsState()
        val strictKvCache by vm.strictKvCache.collectAsState()
        val thinkingMode by vm.thinkingMode.collectAsState()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Settings", color = ObsColors.TextPrime, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)

            // ── Sampler section ─────────────────────────────────────────────
            SettingsSection("SAMPLER") {
                SettingsSliderRow("Temperature", temperature, 0.01f, 2.0f) { vm.temperature.value = it }
                SettingsSliderRow("Max Tokens", maxTokens.toFloat(), 100f, 2000f, isInt = true) { vm.maxTokens.value = it.toInt() }
                SettingsSliderRow("Top-K", topK.toFloat(), 1f, 100f, isInt = true) { vm.topK.value = it.toInt() }
                SettingsSliderRow("Top-P", topP, 0.1f, 1.0f) { vm.topP.value = it }
                SettingsSliderRow("Min-P", minP, 0.0f, 0.3f) { vm.minP.value = it }
                SettingsSliderRow("Repeat Penalty", repeatPenalty, 1.0f, 1.5f) { vm.repeatPenalty.value = it }
                SettingsSliderRow("Refine Passes", refinePasses.toFloat(), 0f, 3f, isInt = true) { vm.refinePasses.value = it.toInt() }
            }

            // ── Runtime section ─────────────────────────────────────────────
            SettingsSection("RUNTIME") {
                SettingsSliderRow("Threads", threads.toFloat(), 1f, 8f, isInt = true) { vm.threads.value = it.toInt() }
                SettingsSliderRow("Context Size", contextSize.toFloat(), 512f, 8192f, isInt = true, snap = listOf(1024f, 1536f, 2048f, 3072f, 4096f)) { vm.contextSize.value = it.toInt() }
                SettingsSliderRow("Batch Size", batchSize.toFloat(), 64f, 1024f, isInt = true, snap = listOf(128f, 256f, 384f, 512f)) { vm.batchSize.value = it.toInt() }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Strict KV Cache", color = ObsColors.TextPrime, fontSize = 13.sp)
                        Text("OFF for Granite/MoE — ON for dense only", color = ObsColors.TextDim, fontSize = 10.sp)
                    }
                    Switch(
                        checked = strictKvCache,
                        onCheckedChange = { vm.strictKvCache.value = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsColors.AccentCyan)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Thinking Mode", color = ObsColors.TextPrime, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("OFF", "AUTO", "FORCE").forEach { mode ->
                            FilterChip(
                                selected = thinkingMode == mode,
                                onClick = { vm.thinkingMode.value = mode },
                                label = { Text(mode, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ObsColors.AccentCyan.copy(alpha = 0.15f),
                                    selectedLabelColor = ObsColors.AccentCyan
                                )
                            )
                        }
                    }
                }
            }

            // ── Log viewer ───────────────────────────────────────────────────
            SettingsSection("LIVE LOG") {
                LiveLogPanel()
            }

            Box(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Card(colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard), border = BorderStroke(0.5.dp, ObsColors.Border), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
        }
    }
}

@Composable
private fun ColumnScope.SettingsSliderRow(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    isInt: Boolean = false,
    snap: List<Float>? = null,
    onChange: (Float) -> Unit
) {
    val displayValue = if (isInt) "${value.toInt()}" else "%.2f".format(value)
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = ObsColors.TextMuted, fontSize = 12.sp)
            Text(displayValue, color = ObsColors.TextPrime, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = { raw ->
                val v = if (snap != null) snap.minBy { kotlin.math.abs(it - raw) } else raw
                onChange(if (isInt) kotlin.math.round(v).toFloat() else v)
            },
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = ObsColors.TextPrime,
                activeTrackColor = ObsColors.AccentCyan,
                inactiveTrackColor = ObsColors.Border
            )
        )
    }
}