package com.arena.aiuibuilder

/**
 * JNI bridge for the strict recursive refiner.
 *
 * The implementation is appended to llama.cpp's Android ai_chat.cpp during GitHub Actions.
 * Strict behavior:
 * - grounding is evaluated once and cached
 * - each iteration erases KV/memory after grounding
 * - prompt/instruction evaluation runs with grammar OFF
 * - JSON generation runs with native llama.cpp GBNF grammar ON
 */
object NativeRecursiveRefiner {
    init {
        runCatching { System.loadLibrary("ai-chat") }
    }

    external fun setStrictKvMode(strict: Boolean)
    external fun setThinkingMode(enabled: Boolean, maxThinkingTokens: Int)

    external fun beginSession(grounding: String): Int

    external fun refineOnce(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topK: Int,
        topP: Float,
        minP: Float,
        repeatPenalty: Float
    ): String

    /**
     * Schema-free counterpart to [refineOnce]: same bounded-context behavior
     * (resets to the [beginSession] grounding checkpoint before generating, so the
     * native context never accumulates across calls), but does NOT force the
     * Refiner's fixed JSON grammar -- generates plain text instead. This is what
     * CognitiveEngine.reason() should call instead of engine.sendUserPrompt(),
     * so its 20-iteration operator loop stays bounded instead of growing the
     * shared llama.cpp context call after call. See architecture blueprint,
     * Part 5.0, for why engine.sendUserPrompt() was the wrong call to use here.
     */
    external fun generateGrounded(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topK: Int,
        topP: Float,
        minP: Float,
        repeatPenalty: Float
    ): String

    external fun getProgressChars(): Int
    external fun getProgressTokens(): Int
    external fun getProgressText(): String
    external fun getTimingSummary(): String

    external fun resetSession()
}

