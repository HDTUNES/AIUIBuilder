package com.arena.aiuibuilder

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppLog {
    private const val TAG = "AIUIBuilder"
    private const val MAX_FILE_LINES = 2000
    private var logFile: File? = null
    private val df = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun install(ctx: Context) {
        logFile = File(ctx.filesDir, "aiuibuilder_error_log.txt")
        // Flush any crash-time errors written by the uncaught exception handler
        val crashFile = File(ctx.filesDir, "crash_log.txt")
        if (crashFile.exists()) {
            runCatching {
                val crashText = crashFile.readText()
                if (crashText.isNotBlank()) {
                    writeToFile("--- CRASH LOG RECOVERED ---\n$crashText\n--- END CRASH LOG ---")
                }
                crashFile.delete()
            }
        }
    }

    // ── Existing API (unchanged — no other files call these differently) ─────
    fun append(message: String) {
        val line = "[${df.format(Date())}] $message"
        Log.d(TAG, message)
        writeToFile(line)
        pushToObservatory("INFO", "SYSTEM", message, emptyMap())
    }

    fun appendError(label: String, throwable: Throwable) {
        val full = "$label: ${throwable.message}"
        val stackTrace = throwable.stackTraceToString().take(500)
        val line = "[${df.format(Date())}] ERROR $full\n$stackTrace"
        Log.e(TAG, full, throwable)
        writeToFile(line)
        pushToObservatory("ERROR", "SYSTEM", "$full | ${throwable.javaClass.simpleName}", emptyMap())
    }

    /**
     * Log a UI lifecycle event — for tracking tab switches, composable creation,
     * and identifying where freezes happen. These are always written to file and
     * Android logcat, even if the observatory is not listening.
     */
    fun logUi(event: String, detail: String = "") {
        val line = "[${df.format(Date())}] [UI] $event${if (detail.isNotBlank()) " — $detail" else ""}"
        Log.d(TAG, line)
        writeToFile(line)
        pushToObservatory("DEBUG", "UI", "$event${if (detail.isNotBlank()) " — $detail" else ""}", emptyMap())
    }

    // ── Structured log (used by cognitive systems) ────────────────────────────
    fun logStructured(
        level: String,
        stage: String,
        iteration: Int,
        message: String,
        metrics: Map<String, Any?> = emptyMap()
    ) {
        val extStr = if (metrics.isNotEmpty()) {
            " | " + metrics.entries.joinToString(", ") { "${it.key}=${it.value}" }
        } else ""
        val line = "[${df.format(Date())}] [$level] [$stage] iter=$iteration $message$extStr"
        Log.d(TAG, line)
        writeToFile(line)
        // Convert metrics to extras map for observatory
        val extras = metrics.mapValues { it.value?.toString() ?: "" }
        pushToObservatory(level, stage, message, extras, iteration)
    }

    // ── Push to ObservatoriumSession for reactive UI ──────────────────────────
    private fun pushToObservatory(
        level: String,
        stage: String,
        message: String,
        extras: Map<String, Any>,
        iteration: Int = 0
    ) {
        val entry = StructuredLogEntry(
            timestamp = df.format(Date()),
            level = level,
            stage = stage,
            iteration = iteration,
            message = message,
            extras = extras
        )
        ObservatoriumSession.pushLog(entry)
    }

    // ── File I/O ─────────────────────────────────────────────────────────────
    private fun writeToFile(line: String) {
        runCatching {
            val f = logFile ?: return
            val existing = if (f.exists()) f.readLines() else emptyList()
            val trimmed = if (existing.size > MAX_FILE_LINES) existing.takeLast(MAX_FILE_LINES) else existing
            f.writeText((trimmed + line).joinToString("\n"))
        }
    }

    fun readAll(): String = runCatching { logFile?.readText() ?: "" }.getOrDefault("")
    fun read(context: Context): String { /* backward compat alias */
        logFile = File(context.filesDir, "aiuibuilder_error_log.txt")
        return readAll()
    }

    fun clear(context: Context) {
        runCatching { logFile?.writeText("") }
        ObservatoriumSession.clearLogs()
    }

    fun path(context: Context): String {
        logFile = File(context.filesDir, "aiuibuilder_error_log.txt")
        return logFile?.absolutePath ?: ""
    }

    // ── V4.1 additions ──────────────────────────────────────────────────────
    fun log(tag: String, message: String) {
        append("[$tag] $message")
    }

    fun appendThinking(line: String) {
        append("[THINK] $line")
        runCatching { ThinkingStream.appendLine("APPLOG", line) }
    }

    fun logStructured(
        level: String,
        stage: String,
        iteration: Int,
        extras: Map<String, Any>
    ) {
        logStructured(level, stage, iteration, "", extras)
    }
}