package com.arena.aiuibuilder

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppLog {
    private const val FILE_NAME = "aiuibuilder_error_log.txt"
    private var appContext: Context? = null
    private var installed = false

    fun install(context: Context) {
        appContext = context.applicationContext
        if (installed) return
        installed = true
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            logStructured("FATAL", "SYSTEM", 0, "Uncaught exception on thread=${thread.name} stack=${throwable.stackTraceToString()}")
            previous?.uncaughtException(thread, throwable)
        }
        logStructured("INFO", "SYSTEM", 0, "MESA AppLog successfully installed.")
    }

    fun append(message: String) {
        val ctx = appContext ?: return
        runCatching {
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            file(ctx).appendText("\n[$stamp] [INFO] [REFINER] $message\n", Charsets.UTF_8)
        }
    }

    fun appendError(label: String, throwable: Throwable) {
        val ctx = appContext ?: return
        runCatching {
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            file(ctx).appendText(
                "\n[$stamp] [ERROR] [REFINER] $label\nTrace: ${throwable.stackTraceToString()}\n", 
                Charsets.UTF_8
            )
        }
    }

    fun logStructured(
        level: String,
        stage: String,
        iteration: Int,
        message: String,
        metrics: Map<String, Any?> = emptyMap()
    ) {
        val ctx = appContext ?: return
        runCatching {
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            val metricStr = if (metrics.isNotEmpty()) {
                " · " + metrics.entries.joinToString(", ") { "${it.key}=${it.value}" }
            } else ""
            file(ctx).appendText(
                "\n[$stamp] [$level] [$stage] [iter=$iteration] $message$metricStr\n", 
                Charsets.UTF_8
            )
        }
    }

    fun read(context: Context): String {
        appContext = context.applicationContext
        val f = file(context)
        return if (f.exists()) f.readText(Charsets.UTF_8) else "No logs yet."
    }

    fun clear(context: Context) {
        appContext = context.applicationContext
        file(context).writeText("", Charsets.UTF_8)
        append("Log cleared")
    }

    fun path(context: Context): String = file(context).absolutePath

    private fun file(context: Context): File = File(context.filesDir, FILE_NAME)
}