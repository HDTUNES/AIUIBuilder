package com.arena.aiuibuilder

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppLog {
    private const val FILE_NAME = "aiuibuilder_error_log.txt"
    private var appContext: Context? = null
    private var installed = false

    fun install(context: Context) {
        appContext = context.applicationContext
        if (installed) return
        installed = true
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            append("FATAL uncaught exception on thread=${thread.name}\n${throwable.stackTraceToString()}")
            previous?.uncaughtException(thread, throwable)
        }
        append("AppLog installed")
    }

    fun append(message: String) {
        val ctx = appContext ?: return
        runCatching {
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            file(ctx).appendText("\n[$stamp] $message\n", Charsets.UTF_8)
        }
    }

    fun appendError(label: String, throwable: Throwable) {
        append("ERROR: $label\n${throwable.stackTraceToString()}")
    }

    fun read(context: Context): String {
        appContext = context.applicationContext
        val f = file(context)
        return if (f.exists()) f.readText(Charsets.UTF_8) else "No logs yet."
    }

    fun clear(context: Context) {
        appContext = context.applicationContext
        file(context).writeText("", Charsets.UTF_8)
        append("Log cleared")
    }

    fun path(context: Context): String = file(context).absolutePath

    private fun file(context: Context): File = File(context.filesDir, FILE_NAME)
}
