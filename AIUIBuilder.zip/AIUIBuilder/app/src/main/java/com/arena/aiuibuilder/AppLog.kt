package com.arena.aiuibuilder

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppLog {
    private const val TAG = "AIUIBuilder"
    private const val MAX_FILE_LINES = 1000
    private var logFile: File? = null
    private val df = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun install(ctx: Context) {
        logFile = File(ctx.filesDir, "aiuibuilder_error_log.txt")
    }

    // ── Existing API (unchanged — no other files call these differently) ─────
    fun append(message: String) {
        val line = "[${df.format(Date())}] $message"
        Log.d(TAG, message)
        writeToFile(line)
        pushToObservatory("INFO", "SYSTEM", message, emptyMap())
    }

    fun appendError(label: String, throwable: Throwable) {
        val full = "$label: ${throwable.message}"
        val line = "[${df.format(Date())}] ERROR $full"
        Log.e(TAG, full, throwable)
        writeToFile(line)
        pushToObservatory("ERROR", "SYSTEM", full, emptyMap())
    }

    // ── Structured log (used by cognitive systems) ────────────────────────────
    fun logStructured(
        level: String,
        stage: String,
        iteration: Int,
        message: String,
        metrics: Map<String, Any?> = emptyMap()
    ) {
        val extStr = if (metrics.isNotEmpty()) {
            " | " + metrics.entries.joinToString(", ") { "${it.key}=${it.value}" }
        } else ""
        val line = "[${df.format(Date())}] [$level] [$stage] iter=$iteration $message$extStr"
        Log.d(TAG, line)
        writeToFile(line)
        // Convert metrics to extras map for observatory
        val extras = metrics.mapValues { it.value?.toString() ?: "" }
        pushToObservatory(level, stage, message, extras, iteration)
    }

    // ── Push to ObservatoriumSession for reactive UI ──────────────────────────
    private fun pushToObservatory(
        level: String,
        stage: String,
        message: String,
        extras: Map<String, Any>,
        iteration: Int = 0
    ) {
        val entry = StructuredLogEntry(
            timestamp = df.format(Date()),
            level = level,
            stage = stage,
            iteration = iteration,
            message = message,
            extras = extras
        )
        ObservatoriumSession.pushLog(entry)
    }

    // ── File I/O ─────────────────────────────────────────────────────────────
    private fun writeToFile(line: String) {
        runCatching {
            val f = logFile ?: return
            val existing = if (f.exists()) f.readLines() else emptyList()
            val trimmed = if (existing.size > MAX_FILE_LINES) existing.takeLast(MAX_FILE_LINES) else existing
            f.writeText((trimmed + line).joinToString("\n"))
        }
    }

    fun readAll(): String = runCatching { logFile?.readText() ?: "" }.getOrDefault("")
    fun read(context: Context): String { /* backward compat alias */
        logFile = File(context.filesDir, "aiuibuilder_error_log.txt")
        return readAll()
    }

    fun clear(context: Context) {
        runCatching { logFile?.writeText("") }
        ObservatoriumSession.liveTerminalLogs.clear()
    }

    fun path(context: Context): String {
        logFile = File(context.filesDir, "aiuibuilder_error_log.txt")
        return logFile?.absolutePath ?: ""
    }
}