package com.arena.aiuibuilder

import android.content.Context
import android.webkit.WebView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Code Execution Engine for reality-grounding on Android.
 *
 * Uses a lightweight WebView JavaScript sandbox to execute small generated scripts.
 * This lets the system verify quantitative/logical claims, run base-case simulations,
 * and compare predictions against actual outputs.
 *
 * For 2026 Android, this is the most practical local execution path. It does NOT
 * require external servers, Python, or root.
 */

object CodeExecutionEngine {

    private const val TIMEOUT_MS = 5000L

    data class ExecutionResult(
        val success: Boolean,
        val output: String,
        val error: String?
    )

    /**
     * Execute a JavaScript snippet and return the result.
     * Runs on the main thread via a WebView created on the fly.
     * This is intentionally simple and synchronous-feeling for the caller.
     */
    suspend fun executeJavaScript(context: Context, script: String): ExecutionResult = withContext(Dispatchers.Main) {
        val resultRef = AtomicReference<ExecutionResult>()
        val latch = CountDownLatch(1)

        val webView = WebView(context.applicationContext)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = false

        val wrappedScript = buildString {
            append("(function() {")
            append("  try {")
            append("    var __result = (function(){\n")
            append(script)
            append("\n    })();")
            append("    if (typeof __result === 'object') { __result = JSON.stringify(__result); }")
            append("    else { __result = String(__result); }")
            append("    return 'MESA_EXEC_OK:' + __result;")
            append("  } catch (e) {")
            append("    return 'MESA_EXEC_ERR:' + e.message;")
            append("  }")
            append("})()")
        }

        webView.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun deliverResult(result: String) {
                resultRef.set(parseResult(result))
                latch.countDown()
            }
        }, "MesaBridge")

        webView.loadUrl("about:blank")

        // Give WebView a moment to initialize, then inject the script
        webView.postDelayed({
            webView.evaluateJavascript("MesaBridge.deliverResult($wrappedScript);") { }
        }, 150)

        val timedOut = !latch.await(TIMEOUT_MS, TimeUnit.MILLISECONDS)
        val result = resultRef.get() ?: ExecutionResult(false, "", if (timedOut) "Execution timed out" else "No result")

        webView.post { webView.destroy() }

        result
    }

    /**
     * Convenience: verify a simple arithmetic claim by generating a test script.
     */
    fun generateArithmeticTest(claim: String): String? {
        // Extract expressions like "2+2=4" or "3*5=15"
        val exprMatch = Regex("(\\d+\\s*[+\\-*/^]\\s*\\d+)\\s*=\\s*(\\d+)").find(claim)
        if (exprMatch != null) {
            val expr = exprMatch.groupValues[1].replace("^", "**")
            val expected = exprMatch.groupValues[2]
            return "return ($expr === $expected) ? 'TRUE' : 'FALSE: expected $expected, got ' + ($expr);"
        }
        return null
    }

    /**
     * Generate a JavaScript test for a generic falsifiable claim.
     * The LLM is asked to produce code; this function wraps it safely.
     */
    fun wrapTestCode(generatedCode: String): String {
        return """
            (function(){
                var console = { log: function(){} };
                ${generatedCode.trim()}
            })()
        """.trimIndent()
    }

    private fun parseResult(raw: String): ExecutionResult {
        return when {
            raw.startsWith("MESA_EXEC_OK:") -> ExecutionResult(true, raw.removePrefix("MESA_EXEC_OK:"), null)
            raw.startsWith("MESA_EXEC_ERR:") -> ExecutionResult(false, "", raw.removePrefix("MESA_EXEC_ERR:"))
            else -> ExecutionResult(false, "", "Unexpected execution format")
        }
    }
}
