package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class EmpiricalTestReport(
    val survivedChallenge: Boolean,
    val fatalObjection: String,
    val empiricalSpecificityScore: Float,
    val finalRealityMultiplier: Float
)

object ExecutionLayer {
    private val json = Json { ignoreUnknownKeys = true }

    fun evaluateSpecificityGate(claim: String): Float {
        var score = 0.50f
        if (claim.contains(Regex("\\d+"))) score += 0.15f
        if (claim.contains(Regex("%|kg|ms|ns|W|GHz|MHz|mm|nm|C|K|\\$"))) score += 0.15f
        if (claim.contains(Regex("(?i)synapse|memristor|neuromorphic|gate|plasticity|feedback|stability"))) score += 0.10f
        return score.coerceIn(0.1f, 1.0f)
    }

    fun verifyGraphConsistency(claimKey: String, contradictsId: String?): Boolean {
        if (contradictsId == null) return true
        val targetCount = CognitiveOsMemory.getEdgesCount()
        return targetCount < 100
    }

    fun executeRealityValidation(
        hypothesis: String,
        temperature: Float = 0.3f,
        topK: Int = 40,
        topP: Float = 0.9f,
        minP: Float = 0.05f,
        repeatPenalty: Float = 1.1f
    ): EmpiricalTestReport {
        val specificity = evaluateSpecificityGate(hypothesis)
        val challengePrompt = buildString {
            appendLine("You are an empirical reality scientific verifier.")
            appendLine("Hypothesis Candidate: \"${hypothesis.take(200)}\"")
            appendLine("Task: State the single strongest physical or logical objection to this candidate.")
            appendLine("You must output exactly a 9-field JSON matching your schema:")
            appendLine("- Set 'refined' to your single-sentence objection.")
            appendLine("- Set 'next_focus' to 'FAILS' if there is a fatal flaw, otherwise 'SURVIVES'.")
            appendLine("- Set 'domain_tag' to 'structural'")
            appendLine("- Set 'abstraction_level' to 'concrete'")
            appendLine("- Set 'novelty_claim' to 'Adversarial validation check.'")
            appendLine("- Set other fields to null.")
        }

        var survived = true
        var objection = "None"
        try {
            val raw = NativeRecursiveRefiner.refineOnce(challengePrompt, 250, temperature, topK, topP, minP, repeatPenalty)
            val parsed = runCatching { json.decodeFromString<StrictRefinerJson>(raw) }.getOrNull()

            if (parsed != null) {
                val verdict = parsed.next_focus.uppercase()
                objection = parsed.refined.take(150)
                survived = !verdict.contains("FAILS") && !verdict.contains("COLLAPSE")
                AppLog.append("ExecutionLayer Tester: objection=\"$objection\" verdict=$verdict survived=$survived")
            } else {
                val nextFocusMatch = Regex("\"next_focus\"\\s*:\\s*\"([^\"]+)\"").find(raw)
                val refinedMatch = Regex("\"refined\"\\s*:\\s*\"([^\"]+)\"").find(raw)
                val verdict = nextFocusMatch?.groupValues?.get(1)?.uppercase() ?: raw.uppercase()
                objection = refinedMatch?.groupValues?.get(1) ?: "Empirical challenge unparsed."
                survived = !verdict.contains("FAILS") && !verdict.contains("COLLAPSE")
                AppLog.append("ExecutionLayer Regex Fallback: objection=\"$objection\" survived=$survived")
            }
        } catch (e: Exception) {
            AppLog.append("ExecutionLayer error: ${e.message}")
        }

        val realityMultiplier = if (survived) (1.0f + (specificity * 0.2f)).coerceAtMost(1.2f) else 0.30f

        return EmpiricalTestReport(
            survivedChallenge = survived,
            fatalObjection = objection,
            empiricalSpecificityScore = specificity,
            finalRealityMultiplier = realityMultiplier
        )
    }
}