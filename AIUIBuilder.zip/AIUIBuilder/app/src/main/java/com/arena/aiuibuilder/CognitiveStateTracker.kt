package com.arena.aiuibuilder

/**
 * CognitiveStateTracker — the shared cognitive state (blueprint v8 FIX 5).
 *
 * This is the architectural core of v8: a single lightweight, mutable state object
 * that travels through an entire reasoning session. It is READ by the scheduler
 * (to decide the next operator) AND MUTATED by the operators (as they discover
 * beliefs, constraints, contradictions, etc.).
 *
 * The shift this enables:
 *   BEFORE: controller → picks operator → operator → OperatorResult → loop
 *           (operators independent, state scattered, next step hardcoded)
 *   AFTER:  CognitiveStateTracker (beliefs, constraints, uncertainty, tension)
 *           → tension() selects operator → operator mutates state
 *           → tension() changes → new operator emerges
 */
class CognitiveStateTracker(val sessionGoal: String) {

    // Core cognitive state
    val beliefs        = mutableListOf<BeliefEntry>()
    val constraints    = mutableListOf<String>()
    val openQuestions  = mutableListOf<String>()
    val predictions    = mutableListOf<PredictionEntry>()
    val contradictions = mutableListOf<String>()

    // Dynamic scalars driven by evidence, not by counters
    var uncertainty      = 0.8f   // starts high, decreases as beliefs accumulate
    var attention        = 1.0f   // decreases with energy expenditure
    var predictionError  = 0f     // updated each time a prediction is compared to reality
    var overallConfidence = 0.3f  // updated from calibrated confidence

    /**
     * Computed "tension" — how urgently the engine needs to work on something.
     * High tension = act now. Low tension = ready to integrate.
     */
    fun tension(): Float {
        val contradictionTension = (contradictions.size * 0.2f).coerceAtMost(0.4f)
        val uncertaintyTension   = uncertainty * 0.3f
        val openQuestionTension  = (openQuestions.size * 0.1f).coerceAtMost(0.3f)
        val peTension            = predictionError * 0.2f
        return (contradictionTension + uncertaintyTension + openQuestionTension + peTension)
            .coerceIn(0f, 1f)
    }

    /** Reduce uncertainty when a belief is added with high confidence. */
    fun addBelief(content: String, confidence: Float, source: String) {
        beliefs.add(BeliefEntry(content, confidence, source))
        uncertainty = (uncertainty - confidence * 0.15f).coerceAtLeast(0.05f)
        overallConfidence = beliefs.map { it.confidence }.average().toFloat()
    }

    fun addConstraint(c: String) { if (c.isNotBlank() && c !in constraints) constraints.add(c) }
    fun addOpenQuestion(q: String) { if (q.isNotBlank() && q !in openQuestions) openQuestions.add(q) }
    fun resolveQuestion(q: String) { openQuestions.remove(q) }
    fun addContradiction(c: String) { if (c.isNotBlank()) contradictions.add(c) }

    fun addPrediction(prediction: String, basis: String, atIter: Int) {
        if (prediction.isNotBlank()) predictions.add(PredictionEntry(prediction, basis, atIter))
    }

    /**
     * Render the active state as an explicit prompt section, so the model sees
     * binding constraints, established beliefs, open questions, and contradictions
     * as first-class drivers — not as opaque background memory.
     */
    fun toPromptSection(): String = buildString {
        if (constraints.isNotEmpty()) {
            appendLine("━━ ACTIVE CONSTRAINTS ━━")
            constraints.takeLast(5).forEach { appendLine("  ⚡ $it") }
            appendLine()
        }
        if (beliefs.isNotEmpty()) {
            appendLine("━━ ESTABLISHED BELIEFS ━━")
            beliefs.sortedByDescending { it.confidence }.take(5)
                .forEach { appendLine("  ✓ [${(it.confidence * 100).toInt()}%] ${it.content.take(100)}") }
            appendLine()
        }
        if (openQuestions.isNotEmpty()) {
            appendLine("━━ OPEN QUESTIONS ━━")
            openQuestions.take(3).forEach { appendLine("  ? $it") }
            appendLine()
        }
        if (contradictions.isNotEmpty()) {
            appendLine("━━ CONTRADICTIONS TO RESOLVE ━━")
            contradictions.take(2).forEach { appendLine("  ✗ $it") }
            appendLine()
        }
    }
}

data class BeliefEntry(val content: String, val confidence: Float, val source: String)
data class PredictionEntry(val prediction: String, val basis: String, val madeAtIter: Int)
