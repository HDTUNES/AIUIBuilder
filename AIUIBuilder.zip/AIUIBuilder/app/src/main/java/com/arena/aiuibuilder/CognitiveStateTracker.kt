package com.arena.aiuibuilder

/**
 * Shared mutable state for one cognitive reasoning session.
 *
 * This is the minimal v8 architectural bridge from a controller-driven pipeline to
 * emergent cognition: operators mutate beliefs, constraints, questions,
 * predictions, contradictions, and uncertainty; the scheduler then selects the
 * next operator from this state tension instead of only from fixed counters.
 */
class CognitiveStateTracker(val sessionGoal: String) {

    // Core cognitive state
    val beliefs = mutableListOf<BeliefEntry>()
    val constraints = mutableListOf<String>()
    val openQuestions = mutableListOf<String>()
    val predictions = mutableListOf<PredictionEntry>()
    val contradictions = mutableListOf<String>()

    // Dynamic scalars driven by evidence, not by counters
    var uncertainty = 0.8f
    var attention = 1.0f
    var predictionError = 0f
    var overallConfidence = 0.3f

    /**
     * Computed tension: how urgently cognition needs another operation.
     * High tension means act; low tension means synthesize/integrate.
     */
    fun tension(): Float {
        val contradictionTension = (contradictions.size * 0.2f).coerceAtMost(0.4f)
        val uncertaintyTension = uncertainty * 0.3f
        val openQuestionTension = (openQuestions.size * 0.1f).coerceAtMost(0.3f)
        val peTension = predictionError * 0.2f
        return (contradictionTension + uncertaintyTension + openQuestionTension + peTension)
            .coerceIn(0f, 1f)
    }

    fun addBelief(content: String, confidence: Float, source: String) {
        beliefs.add(BeliefEntry(content, confidence, source))
        uncertainty = (uncertainty - confidence * 0.15f).coerceAtLeast(0.05f)
        overallConfidence = beliefs.map { it.confidence }.average().toFloat()
    }

    fun addConstraint(c: String) {
        if (c.isNotBlank() && c !in constraints) constraints.add(c)
    }

    fun addPrediction(prediction: String, basis: String, madeAtIter: Int) {
        if (prediction.isNotBlank()) predictions.add(PredictionEntry(prediction, basis, madeAtIter))
    }

    fun addOpenQuestion(q: String) {
        if (q.isNotBlank() && q !in openQuestions) openQuestions.add(q)
    }

    fun resolveQuestion(q: String) { openQuestions.remove(q) }
    fun addContradiction(c: String) { if (c.isNotBlank()) contradictions.add(c) }

    fun toPromptSection(): String = buildString {
        if (constraints.isNotEmpty()) {
            appendLine("━━ ACTIVE CONSTRAINTS ━━")
            constraints.takeLast(5).forEach { appendLine("  ⚡ $it") }
            appendLine()
        }
        if (beliefs.isNotEmpty()) {
            appendLine("━━ ESTABLISHED BELIEFS ━━")
            beliefs.sortedByDescending { it.confidence }.take(5)
                .forEach { appendLine("  ✓ [${(it.confidence * 100).toInt()}%] ${it.content.take(100)}") }
            appendLine()
        }
        if (openQuestions.isNotEmpty()) {
            appendLine("━━ OPEN QUESTIONS ━━")
            openQuestions.take(3).forEach { appendLine("  ? $it") }
            appendLine()
        }
        if (contradictions.isNotEmpty()) {
            appendLine("━━ CONTRADICTIONS TO RESOLVE ━━")
            contradictions.take(2).forEach { appendLine("  ✗ $it") }
            appendLine()
        }
    }
}

data class BeliefEntry(val content: String, val confidence: Float, val source: String)
data class PredictionEntry(val prediction: String, val basis: String, val madeAtIter: Int)
