package com.arena.aiuibuilder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ConversationSidebar(
    open: Boolean,
    tab: String,
    activeId: String?,
    historyVersion: Int,
    onClose: () -> Unit,
    onSelect: (ConversationRecord) -> Unit,
    onNew: () -> Unit,
    listState: LazyListState
) {
    val context = LocalContext.current
    var records by remember(tab, historyVersion, open) { mutableStateOf(emptyList<ConversationRecord>()) }
    var query by remember(tab) { mutableStateOf("") }
    LaunchedEffect(tab, historyVersion, open) {
        if (open) records = ConversationHistoryStore.listForTab(context, tab)
    }
    val filtered = if (query.isBlank()) records else records.filter { it.title.contains(query, ignoreCase = true) }
    val scrimAlpha by animateFloatAsState(if (open) 0.5f else 0f, tween(250), label = "history_scrim")

    Box(modifier = Modifier.fillMaxSize()) {
        if (scrimAlpha > 0f) {
            Box(
                modifier = Modifier.fillMaxSize()
                    .background(Color.Black.copy(alpha = scrimAlpha))
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() }
            )
        }
        AnimatedVisibility(
            visible = open,
            enter = slideInHorizontally(tween(280)) { it },
            exit = slideOutHorizontally(tween(220)) { it },
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Column(
                modifier = Modifier.fillMaxHeight().width(300.dp)
                    .background(ObsColors.BgPanel)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { },
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    if (tab == "chat") "Chat History" else "Cognitive Core History",
                    color = ObsColors.TextPrime,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(16.dp)
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search", color = ObsColors.TextDim) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    colors = makeTextFieldColors(ObsColors.BorderMid, ObsColors.InputBorder, ObsColors.TextPrime, ObsColors.TextPrime, ObsColors.TextPrime)
                )
                Text(
                    "+ New " + (if (tab == "chat") "Chat" else "Session"),
                    color = ObsColors.AccentGreen,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).clickable { onNew(); onClose() }
                )
                LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
                    items(filtered, key = { it.id }) { record ->
                        ConversationRow(
                            record = record,
                            isActive = record.id == activeId,
                            onClick = { onSelect(record); onClose() },
                            onRename = { newTitle -> ConversationHistoryStore.rename(context, record.id, newTitle); records = ConversationHistoryStore.listForTab(context, tab) },
                            onDelete = { ConversationHistoryStore.delete(context, record.id); records = ConversationHistoryStore.listForTab(context, tab) },
                            onTogglePin = { ConversationHistoryStore.setPinned(context, record.id, !record.pinned); records = ConversationHistoryStore.listForTab(context, tab) }
                        )
                    }
                }
            }
        }
    }
}

private val rowDateFormat = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.getDefault())

@Composable
private fun ConversationRow(
    record: ConversationRecord,
    isActive: Boolean,
    onClick: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onTogglePin: () -> Unit
) {
    var renaming by remember(record.id) { mutableStateOf(false) }
    var draft by remember(record.id, record.title) { mutableStateOf(record.title) }
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(if (isActive) ObsColors.BgHover else Color.Transparent)
            .clickable(enabled = !renaming) { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (renaming) {
                BasicTextField(value = draft, onValueChange = { draft = it }, textStyle = androidx.compose.ui.text.TextStyle(color = ObsColors.TextPrime, fontSize = 13.sp))
            } else {
                Text(record.title, color = ObsColors.TextPrime, fontSize = 13.sp, maxLines = 1)
            }
            Text(rowDateFormat.format(Date(record.updatedAtMs)), color = ObsColors.TextDim, fontSize = 10.sp)
        }
        if (record.pinned) Text("📌", fontSize = 11.sp, modifier = Modifier.padding(end = 6.dp))
        Text(if (renaming) "✓" else "✎", color = ObsColors.TextMuted, fontSize = 12.sp, modifier = Modifier.padding(end = 10.dp).clickable { if (renaming) onRename(draft); renaming = !renaming })
        Text("📌", color = if (record.pinned) ObsColors.AccentAmber else ObsColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(end = 10.dp).clickable { onTogglePin() })
        Text("🗑", color = ObsColors.AccentRed, fontSize = 12.sp, modifier = Modifier.clickable { onDelete() })
    }
}
