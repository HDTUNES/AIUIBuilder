package com.arena.aiuibuilder

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * CognitiveEngine — human-brain-like reasoning orchestrator with bounded working memory.
 *
 * Key design invariants:
 *   1. The LLM always sees a prompt under ~1000 tokens, no matter how long the session runs.
 *   2. Long-term memory lives on disk and is retrieved only when relevant.
 *   3. Memories fade by interference (new memories weaken old ones), not wall-clock time.
 *   4. Repeated use strengthens a memory, just like neural reinforcement.
 *   5. High-value insights are externalized to disk when working memory is near capacity.
 */

class CognitiveEngine(
    private val context: Context,
    private val callModel: suspend (prompt: String, maxTokens: Int) -> String,
    private val onDiag: (StageDiagnostics) -> Unit = {}
) {
    private var goalStack = ArrayDeque<String>()
    private val solvedChunks = mutableMapOf<String, String>()
    private val pendingChunks = mutableListOf<String>()
    private val reasoningTrace = mutableListOf<String>()
    private var currentDomain = "structural"

    // v8 FIX 3: binding constraints accumulated across SOLVE_CHUNK steps. Each chunk's
    // decisions become explicit constraints that the next chunk MUST respect, enforcing
    // a causal chain (c1 chose CMOS → c2's materials must be CMOS-compatible → ...).
    private val sessionConstraints = mutableListOf<String>()

    // v8 FIX 7: outcome of the most recent verification (null = never ran). Feeds the
    // calibrated-confidence formula so VERIFY actually moves the confidence number.
    private var lastVerificationOutcome: Boolean? = null

    // v8 FIX 5: the shared cognitive state for the current session. Built fresh in
    // reason(); read by the scheduler and mutated by the operators.
    private var cogState: CognitiveStateTracker? = null

    // v8 FIX 5: the set of operator names the scheduler/archive may legitimately select.
    private val validOperatorSet = setOf(
        "ORIENT", "DECOMPOSE", "FIRST_PRINCIPLES", "ANALOGIZE", "SOLVE_CHUNK",
        "VERIFY", "EXECUTE", "PREDICT", "CURIOSITY", "HYPOTHESIZE",
        "INTEGRATE", "REFLECT", "SELF_EVALUATE", "ABSTRACT"
    )

    // Focus tracking: the "mental spotlight" — which concept is currently in attention
    private var currentFocusId: String = ""
    private var currentFocusLabel: String = "none"

    // Meta-learning: track outcomes per session for strategy archive
    private val sessionOutcomes = mutableListOf<OperatorOutcome>()
    private var sessionProblemType = "general"

    // Cognitive energy: a resource that depletes with each operation and restores
    // on interesting discoveries. When energy runs out, the engine integrates what
    // it has. This naturally limits endless recursion without hard-coded rules.
    private var cognitiveEnergy = 100f
    private var sessionCalibratedConfidence = 0f
    private var sessionStartMs = 0L
    private var confirmedPredictions = 0

    private val MAX_TOKENS_SMALL = 180
    private val MAX_TOKENS_MEDIUM = 320
    private val MAX_TOKENS_LARGE = 480

    /**
     * Maps each Cognitive operator to one of the 9 Pipeline Observatory stages.
     * Several operators share a stage where that's the honest fit (e.g. DECOMPOSE,
     * FIRST_PRINCIPLES, ANALOGIZE, and SOLVE_CHUNK are all forms of generating a
     * candidate idea, so they all map to HYPOTHESIS_GENERATION) -- this is not a
     * forced 1:1 mapping, it's whichever stage each operator's actual job matches.
     */
    private fun mapOperatorToStage(operator: String): PipelineStage = when (operator) {
        "ORIENT" -> PipelineStage.GOAL_SELECTION
        "DECOMPOSE", "FIRST_PRINCIPLES", "ANALOGIZE", "SOLVE_CHUNK", "CURIOSITY", "PREDICT" -> PipelineStage.HYPOTHESIS_GENERATION
        "EXECUTE" -> PipelineStage.CODE_EXECUTION
        "VERIFY" -> PipelineStage.VERIFICATION_TESTING
        "REFLECT" -> PipelineStage.REPAIR_RETRY
        "INTEGRATE", "SAVE_NOTE" -> PipelineStage.PERSISTENCE_SNAPSHOT
        "RETRIEVE_NOTE" -> PipelineStage.ARCHIVE_REVIEW
        else -> PipelineStage.MEMORY_RETRIEVAL
    }

    suspend fun reason(query: String): CognitiveResult = withContext(Dispatchers.IO) {
        sessionStartMs = System.currentTimeMillis()
        onDiag(StageDiagnostics(stage = PipelineStage.SYSTEM_PROMPT_ASSEMBLY, status = StageStatus.ACTIVE, startedAtMs = sessionStartMs, inputSummary = query.take(80)))
        SemanticMemory.initSession(context, query)
        ExternalMemory.load(context)
        WorkingMemory.load(SemanticMemory.retrieveRelevant(query, 5))
        ProceduralMemory.initDefaults()
        EpisodicMemory.record(query, "START", "", "", 0f, false)
        onDiag(StageDiagnostics(
            stage = PipelineStage.SYSTEM_PROMPT_ASSEMBLY,
            status = StageStatus.COMPLETED,
            startedAtMs = sessionStartMs,
            completedAtMs = System.currentTimeMillis(),
            outputSummary = "Working memory assembled from ${SemanticMemory.getAllActive().size} active nodes."
        ))
        MetacognitiveMonitor.reset()

        // ── ABSTRACTION RECALL: Check if current problem matches any abstraction ──
        val queryWords = query.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        val matchingAbstractions = SemanticMemory.getAllActive()
            .filter { it.nodeType == "abstraction" }
            .filter { abs ->
                val absWords = abs.content.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
                absWords.intersect(queryWords).size.toFloat() / absWords.union(queryWords).size > 0.15f
            }
            .sortedByDescending { it.confidence }
            .take(2)

        if (matchingAbstractions.isNotEmpty()) {
            matchingAbstractions.forEach { abs ->
                val absNodeId = "abs_recall_${System.currentTimeMillis()}"
                SemanticMemory.addNode(
                    id = absNodeId,
                    label = "Applicable abstraction: ${abs.label.take(40)}",
                    content = "This problem may fit pattern: ${abs.content.take(150)}",
                    type = "abstraction_recall",
                    importance = 0.8f,
                    confidence = abs.confidence
                )
                AppLog.logStructured("INFO", "ABS-RECALL", 0,
                    "Matched abstraction: ${abs.label.take(50)}",
                    mapOf("confidence" to "%.2f".format(abs.confidence)))
            }
        }

        // ── EPISODIC RECALL: "I've solved something similar before" ──
        val similarPast = EpisodicMemory.replaySimilar(query, 3)
        if (similarPast.isNotEmpty()) {
            val pastSummary = similarPast.joinToString("; ") { trace ->
                "${trace.operator}(${trace.output.take(30)})"
            }
            val recallNodeId = "recall_${System.currentTimeMillis()}"
            SemanticMemory.addNode(
                id = recallNodeId,
                label = "Past experience: ${similarPast.size} similar sessions",
                content = "Previously used: $pastSummary. Avg success: ${similarPast.count { it.success }.toFloat() / similarPast.size}",
                type = "episodic_recall",
                importance = 0.6f,
                confidence = 0.7f
            )
            AppLog.logStructured("INFO", "RECALL", 0,
                "Recalled ${similarPast.size} similar past sessions",
                mapOf("operators" to pastSummary.take(80)))
        }

        goalStack.clear()
        goalStack.addLast(query)
        solvedChunks.clear()
        pendingChunks.clear()
        reasoningTrace.clear()
        decompositionRounds = 0
        cognitiveEnergy = 100f
        sessionCalibratedConfidence = 0f
        confirmedPredictions = 0
        sessionOutcomes.clear()
        sessionProblemType = "general"

        // v8 FIX 3 / FIX 5 / FIX 7: reset per-session cognitive state.
        sessionConstraints.clear()
        lastVerificationOutcome = null
        val cog = CognitiveStateTracker(sessionGoal = query)
        cogState = cog

        // Reduce activation of old nodes so current session nodes rank higher.
        SemanticMemory.getAllActive().forEach { node ->
            val nodeTs = node.id.substringAfterLast("_").toLongOrNull() ?: 0L
            if (nodeTs < sessionStartMs - 5000L) {
                node.activation *= 0.3f
                node.importance = (node.importance * 0.7f).coerceAtMost(0.6f)
            }
        }

        // Consult the unified strategy archive before starting (blueprint 5.4).
        // If the Refiner has discovered strategies that work well for similar goals,
        // use that to bias the initial operator choice instead of always starting at ORIENT.
        val goalWords = query.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        val suggestedStrategies = UnifiedStrategyArchive.selectForGoal(goalWords)
        val initialOperator = if (suggestedStrategies.isNotEmpty()) {
            // If a strategy from EITHER tab has high success for this kind of goal,
            // let the metacognitive monitor know via the first operator hint.
            // Keep ORIENT as default but bias toward what's worked before.
            val bestSuggestion = suggestedStrategies.first()
            if (bestSuggestion.successRate > 0.6f) {
                // Map strategy tags to an operator hint
                bestSuggestion.tags.firstOrNull { it in setOf("decompose", "first_principles", "analogize", "verify", "solve_chunk") }
                    ?.let { tag ->
                        when (tag) {
                            "decompose" -> "DECOMPOSE"
                            "first_principles" -> "FIRST_PRINCIPLES"
                            "analogize" -> "ANALOGIZE"
                            "verify" -> "VERIFY"
                            "solve_chunk" -> "SOLVE_CHUNK"
                            else -> "ORIENT"
                        }
                    } ?: "ORIENT"
            } else "ORIENT"
        } else "ORIENT"

        var operator = initialOperator
        var lastResult = OperatorResult(operator, "")
        var iterations = 0

        while (iterations < 20) {
            iterations += 1
            val goal = goalStack.lastOrNull() ?: query

            // Memory-management phase: save notes if needed, retrieve disk notes if needed.
            val memRetrievalStart = System.currentTimeMillis()
            onDiag(StageDiagnostics(stage = PipelineStage.MEMORY_RETRIEVAL, status = StageStatus.ACTIVE, startedAtMs = memRetrievalStart, inputSummary = goal.take(80)))
            val memoryLoad = WorkingMemory.loadFactor()
            val retrievedCount = SemanticMemory.getAllActive().size
            if (MetacognitiveMonitor.shouldExternalize(memoryLoad, lastResult.confidence, lastResult.surprise)) {
                ExternalMemory.writeNote(
                    context,
                    topic = goal.take(40),
                    summary = lastResult.output.take(200),
                    confidence = lastResult.confidence,
                    links = lastResult.subgoals
                )
                WorkingMemory.load(SemanticMemory.retrieveRelevant(goal, 5))
            }
            if (MetacognitiveMonitor.shouldRetrieveDiskNotes(goal, retrievedCount, ExternalMemory.allNotes().isNotEmpty())) {
                val notes = ExternalMemory.retrieveRelevant(goal, 3)
                notes.forEach { note ->
                    SemanticMemory.addNode("ext_${note.id}", note.topic, note.summary, "external_note", confidence = note.confidence)
                }
                WorkingMemory.load(SemanticMemory.retrieveRelevant(goal, 5))
            }
            onDiag(StageDiagnostics(
                stage = PipelineStage.MEMORY_RETRIEVAL,
                status = StageStatus.COMPLETED,
                startedAtMs = memRetrievalStart,
                completedAtMs = System.currentTimeMillis(),
                outputSummary = "Active memory: $retrievedCount nodes, load ${"%.0f".format(memoryLoad * 100)}%",
                readNodes = listOf("$retrievedCount active nodes")
            ))

            val stageForThisOperator = mapOperatorToStage(operator)
            val stageStartMs = System.currentTimeMillis()
            onDiag(StageDiagnostics(stage = stageForThisOperator, status = StageStatus.ACTIVE, startedAtMs = stageStartMs, inputSummary = goal.take(80)))

            lastResult = when (operator) {
                "ORIENT" -> runOrient(goal)
                "DECOMPOSE" -> runDecompose(goal)
                "FIRST_PRINCIPLES" -> runFirstPrinciples(goal)
                "ANALOGIZE" -> runAnalogize(goal)
                "SOLVE_CHUNK" -> runSolveChunk(goal)
                "ABSTRACT" -> runAbstraction(query)
                "SELF_EVALUATE" -> runSelfEvaluate(query)
                "PREDICT" -> runPredict(query)
                "CURIOSITY" -> runCuriosity(query)
                "VERIFY" -> runVerify(goal)
                "EXECUTE" -> runExecute(goal)
                "INTEGRATE" -> runIntegrate(query)
                "REFLECT" -> runReflect(goal)
                "SAVE_NOTE" -> {
                    ExternalMemory.writeNote(context, goal.take(40), lastResult.output.take(200), lastResult.confidence, lastResult.subgoals)
                    OperatorResult("SAVE_NOTE", "Externalized note to disk.", confidence = 0.9f, surprise = 0.0f)
                }
                "RETRIEVE_NOTE" -> {
                    val notes = ExternalMemory.retrieveRelevant(goal, 3)
                    notes.forEach { note ->
                        SemanticMemory.addNode("ext_${note.id}", note.topic, note.summary, "external_note", confidence = note.confidence)
                    }
                    WorkingMemory.load(SemanticMemory.retrieveRelevant(goal, 5))
                    OperatorResult("RETRIEVE_NOTE", "Retrieved ${notes.size} notes from disk.", confidence = 0.8f, surprise = 0.2f)
                }
                else -> runOrient(goal)
            }

            onDiag(StageDiagnostics(
                stage = stageForThisOperator,
                status = StageStatus.COMPLETED,
                startedAtMs = stageStartMs,
                completedAtMs = System.currentTimeMillis(),
                outputSummary = "[$operator] ${lastResult.output.take(160)}",
                outputSizeChars = lastResult.output.length,
                confidenceDeltas = mapOf(operator to lastResult.confidence)
            ))

            // ── COGNITIVE ENERGY ──
            // Each operator costs energy. Interesting discoveries restore it.
            val energyCost = when (operator) {
                "ORIENT" -> 5f
                "DECOMPOSE" -> 10f
                "SOLVE_CHUNK" -> 15f
                "VERIFY" -> 20f
                "HYPOTHESIZE" -> 15f
                "CURIOSITY" -> 10f
                "PREDICT" -> 12f
                "REPAIR" -> 18f
                "FIRST_PRINCIPLES" -> 12f
                "ANALOGIZE" -> 10f
                "INTEGRATE" -> 5f
                else -> 8f
            }
            cognitiveEnergy -= energyCost

            // Energy restoration on interesting discoveries
            if (lastResult.surprise > 0.5f) cognitiveEnergy += 10f  // surprising finding
            if (lastResult.confidence > 0.85f) cognitiveEnergy += 5f  // high confidence
            cognitiveEnergy = cognitiveEnergy.coerceIn(0f, 100f)

            // Energy depletion penalties
            if (operator == lastResult.operator && iterations > 3) cognitiveEnergy -= 5f  // stuck
            if (lastResult.confidence < 0.3f) cognitiveEnergy -= 3f  // low quality

            // Compute confidence before this operator (average of active beliefs)
            val beliefsBefore = SemanticMemory.getAllActive()
                .filter { it.nodeType in setOf("fact", "hypothesis", "principle") }
            val avgConfBefore = if (beliefsBefore.isNotEmpty())
                beliefsBefore.map { it.confidence }.average().toFloat() else 0.5f

            // Record operator outcome for meta-learning
            sessionOutcomes.add(OperatorOutcome(
                operator = operator,
                problemType = sessionProblemType,
                confidence = lastResult.confidence,
                surprise = lastResult.surprise,
                success = lastResult.confidence > 0.6f,
                energyCost = energyCost,
                confidenceBefore = avgConfBefore,
                confidenceAfter = avgConfBefore,  // will be updated after belief updates
                contribution = 0f  // will be computed at session end
            ))

            AppLog.logStructured("INFO", "ENERGY", iterations,
                "Energy: ${"%.0f".format(cognitiveEnergy)} (cost: ${"%.0f".format(energyCost)})",
                mapOf("operator" to operator, "surprise" to "%.2f".format(lastResult.surprise)))

            // If energy depleted, force integration
            if (cognitiveEnergy <= 0f) {
                AppLog.logStructured("WARN", "ENERGY", iterations,
                    "Cognitive energy depleted. Forcing INTEGRATE.")
                lastResult = runIntegrate(query)
                break
            }

            // Belief audit: check for faithfulness violations
            val audit = auditBelief(lastResult.output, operator)
            if (audit.hasIssues) {
                AppLog.logStructured("WARN", "AUDIT", iterations,
                    "Belief audit issues: ${audit.issues.joinToString("; ")}",
                    mapOf("operator" to operator))
            }

            // ── ALWAYS-ON CURIOSITY ──
            // After each operator, ask "What am I missing?" if the result is surprising.
            // This makes curiosity a continuous process, not just a phase.
            if (lastResult.surprise > 0.4f && iterations > 2 && iterations <= 16 &&
                operator !in setOf("CURIOSITY", "INTEGRATE", "PREDICT")) {
                val altPrompt = buildString {
                    appendLine("You just concluded: ${lastResult.output.take(150)}")
                    appendLine("Question: Could there be another explanation? What assumption might be wrong?")
                    appendLine("Give ONE alternative in 1-2 sentences. Be specific.")
                }
                val altRaw = callModel(altPrompt, 80)
                if (altRaw.isNotBlank() && altRaw.length > 20) {
                    val altNodeId = "alt_${System.currentTimeMillis()}"
                    SemanticMemory.addNode(
                        id = altNodeId,
                        label = "Alternative: ${altRaw.take(30)}",
                        content = altRaw.take(200),
                        type = "hypothesis",
                        importance = 0.4f,
                        confidence = 0.3f
                    )
                    AppLog.logStructured("INFO", "CURIOSITY", iterations,
                        "Generated alternative: ${altRaw.take(60)}")
                }
            }

            // v8 FIX 6: strip any residual prompt/formatting contamination from the
            // output before it enters the reasoning trace (the user-visible thinking
            // stream) or episodic memory.
            val cleanOutput = cleanThinkingStream(lastResult.output)
            reasoningTrace.add("[${iterations}] $operator -> ${cleanOutput.take(80)}")
            EpisodicMemory.record(goal, operator, "", cleanOutput, lastResult.surprise, lastResult.confidence > 0.7f)

            // v8 FIX 7: auto-trigger cross-chunk verification once all chunks are solved.
            // The old phase machine never fired VERIFICATION_TESTING because beliefs were
            // never flagged "unverified". Here we run a consistency cross-check explicitly
            // after the last chunk, and record its outcome for the confidence formula.
            if (operator == "SOLVE_CHUNK" && pendingChunks.isEmpty() && solvedChunks.size >= 2) {
                cogState?.let { cs ->
                    AppLog.logStructured("INFO", "AUTO-VERIFY", iterations,
                        "All ${solvedChunks.size} chunks solved — running cross-chunk verification")
                    val verifyResult = runChunkConsistencyVerify(cs)
                    lastVerificationOutcome =
                        !verifyResult.output.contains("contradiction", ignoreCase = true)
                    reasoningTrace.add("[${iterations}] VERIFY -> ${verifyResult.output.take(80)}")
                }
            }

            // Record this operator's outcome in the unified strategy archive (blueprint 5.4).
            // This lets the Refiner learn from what the Cognitive engine discovers, and vice versa.
            val operatorArmId = "cognitive_op_${operator.lowercase()}"
            UnifiedStrategyArchive.register(
                StrategyArm(
                    id = operatorArmId,
                    source = "cognitive",
                    description = "Operator: $operator",
                    tags = setOf(operator.lowercase()) + goalWords
                )
            )
            UnifiedStrategyArchive.recordOutcome(operatorArmId, lastResult.confidence > 0.7f)

            // Update long-term memory and working memory with the new thought.
            if (operator in setOf("ORIENT", "SOLVE_CHUNK", "FIRST_PRINCIPLES", "ANALOGIZE", "VERIFY", "EXECUTE")) {
                val nodeId = "n_${System.currentTimeMillis()}_$iterations"
                val node = SemanticMemory.addNode(nodeId, "${operator} result", lastResult.output, "claim")
                WorkingMemory.add(node)

                // ── ACTIVATION NETWORK DYNAMICS ──
                // Activate the new node with PE-gated strength:
                // Surprise (prediction error) amplifies activation — the brain pays
                // more attention to things that violated expectations (Pearce-Hall, 1980).
                // Small PE (0.2-0.4): moderate activation boost
                // Large PE (>0.4): strong activation boost (the brain "lights up")
                val peBoost = if (lastResult.surprise > 0.4f) lastResult.surprise * 1.5f
                    else if (lastResult.surprise > 0.2f) lastResult.surprise * 1.0f
                    else 0f
                val activationStrength = (lastResult.confidence + peBoost).coerceAtMost(1.0f)
                SemanticMemory.activateNode(nodeId, strength = activationStrength)
                // Competitive inhibition: suppress unrelated nodes
                SemanticMemory.inhibitUnrelated(nodeId)

                // Log PE-gated activation
                if (peBoost > 0.1f) {
                    AppLog.logStructured("INFO", "PE-ACTIVATE", iterations,
                        "PE-gated activation: ${"%.2f".format(activationStrength)} (surprise=${"%.2f".format(lastResult.surprise)}, boost=${"%.2f".format(peBoost)})",
                        mapOf("node" to nodeId.take(20)))
                }

                // ── FOCUS SHIFT TRACKING ──
                val newFocus = SemanticMemory.getFocusNode()
                if (newFocus != null && newFocus.id != currentFocusId) {
                    AppLog.logStructured("INFO", "FOCUS", iterations,
                        "Focus shifted: ${currentFocusLabel.take(30)} → ${newFocus.label.take(30)}",
                        mapOf("activation" to "%.2f".format(newFocus.activation)))
                    currentFocusId = newFocus.id
                    currentFocusLabel = newFocus.label
                }

                // Contradiction detection: check new belief against existing ones
                val contradictions = MetacognitiveMonitor.detectContradictions(
                    lastResult.output, SemanticMemory.getAllActive().filter { it.id != nodeId }
                )
                if (contradictions.isNotEmpty()) {
                    AppLog.logStructured("WARN", "CONTRADICTION", iterations,
                        "Potential contradiction detected with ${contradictions.size} existing beliefs",
                        mapOf("operator" to operator, "contradicting_ids" to contradictions.take(3).joinToString(",")))
                    // Reduce confidence AND activation of contradicting beliefs
                    contradictions.forEach { cId ->
                        SemanticMemory.getNode(cId)?.let {
                            it.confidence *= 0.8f
                            it.activation *= 0.7f  // suppress contradicting beliefs
                        }
                    }
                }

                // ── CONFIDENCE CALIBRATION ──
                // Compute calibrated confidence from multiple signals
                val calibratedConf = computeCalibratedConfidence(
                    llmConfidence = lastResult.confidence,
                    contradictionCount = contradictions.size,
                    hasVerification = operator == "VERIFY",
                    verificationPassed = if (operator == "VERIFY")
                        lastResult.output.contains("SUPPORTED") else null,
                    operatorAgreement = if (sessionOutcomes.size > 1) {
                        val recentConfs = sessionOutcomes.takeLast(3).map { it.confidence }
                        1f - ((recentConfs.max() ?: 0f) - (recentConfs.min() ?: 0f))  // agreement = low variance
                    } else 0.5f
                )
                sessionCalibratedConfidence = calibratedConf
                // Use calibrated confidence for the node
                val confDelta = calibratedConf - lastResult.confidence
                if (kotlin.math.abs(confDelta) > 0.05f) {
                    AppLog.logStructured("INFO", "CALIBRATE", iterations,
                        "Confidence calibrated: ${"%.2f".format(lastResult.confidence)} → ${"%.2f".format(calibratedConf)} (delta=${"%.2f".format(confDelta)})",
                        mapOf("operator" to operator, "contradictions" to contradictions.size.toString()))
                }
                // Update node confidence with calibrated value
                SemanticMemory.getNode(nodeId)?.let { it.confidence = calibratedConf }

                // Compute actual prediction error: compare stored predictions with verification outcome.
                val predictionNodes = SemanticMemory.getAllActive()
                    .filter { it.nodeType == "prediction" && it.activation > 0.3f }

                if (predictionNodes.isNotEmpty() && operator == "VERIFY") {
                    var confirmedCount = 0
                    val totalPredictions = predictionNodes.size

                    predictionNodes.forEach { predNode ->
                        val predKeywords = predNode.content.lowercase()
                            .split(Regex("[\\s,;.]+"))
                            .filter { it.length > 4 }
                            .toSet()
                        val verifyText = lastResult.output.lowercase()
                        val matchCount = predKeywords.count { it in verifyText }
                        val matchRatio = matchCount.toFloat() / predKeywords.size.coerceAtLeast(1)

                        val predError = 1f - matchRatio
                        if (predError < 0.5f) confirmedCount += 1

                        if (predError > 0.5f) {
                            predNode.activation *= 0.5f
                            AppLog.logStructured("INFO", "PREDICTION_ERROR", iterations,
                                "Large PE (${"%.2f".format(predError)}): prediction '${predNode.label.take(30)}' was wrong")
                        } else {
                            predNode.confidence = (predNode.confidence * 1.1f).coerceAtMost(0.95f)
                            SemanticMemory.activateNode(predNode.id, strength = 0.9f)
                            AppLog.logStructured("INFO", "PREDICTION_ERROR", iterations,
                                "Small PE (${"%.2f".format(predError)}): prediction '${predNode.label.take(30)}' confirmed")
                        }
                    }

                    confirmedPredictions = confirmedCount

                    AppLog.logStructured("INFO", "PE_SUMMARY", iterations,
                        "Prediction accuracy: $confirmedCount/$totalPredictions predictions confirmed")
                }

                // ── PE-GATED MEMORY UPDATING ──
                // Small PE (0.2-0.4): edit existing related memories (reconsolidation)
                // Large PE (>0.4): the new memory is "surprising enough" to stand on its own
                // This matches the hippocampal LC mechanism (ScienceDirect, 2025)
                if (lastResult.surprise > 0.2f && lastResult.surprise <= 0.4f) {
                    // Small PE → reconsolidate related memories
                    SemanticMemory.getAllActive()
                        .filter { it.id != nodeId && it.nodeType == operator.lowercase() }
                        .take(2)
                        .forEach { related ->
                            SemanticMemory.reconsolidate(related.id,
                                "Updated by ${operator}: ${lastResult.output.take(80)}",
                                lastResult.surprise * 0.1f)
                        }
                } else if (lastResult.surprise > 0.4f) {
                    // Large PE → the new memory is already stored as a new node
                    // Just boost its activation further (already done above)
                    AppLog.logStructured("INFO", "PE-UPDATE", iterations,
                        "Large PE (${ "%.2f".format(lastResult.surprise)}): new memory formed",
                        mapOf("operator" to operator))
                }
            }

            // ── DECAY ACTIVATIONS ──
            // After each operator, all activations decay slightly.
            // This simulates natural forgetting and prevents stale activations
            // from dominating the focus of attention.
            SemanticMemory.decayAllActivations(0.05f)

            // ── RELOAD WORKING MEMORY ──
            // After activation changes, reload working memory with the new
            // competition-based selection (highest activation wins).
            WorkingMemory.load(SemanticMemory.retrieveRelevant(goal, 5))

            // REFLECT and INTEGRATE also create memory nodes, with explicit importance
            // scoring at write time (blueprint Part 3.5 / Park et al. Generative Agents).
            // A profound insight the model has high confidence in but doesn't revisit
            // should not be under-weighted relative to a mundane frequently-referenced fact.
            if (operator in setOf("REFLECT", "INTEGRATE")) {
                val nodeId = "n_${System.currentTimeMillis()}_$iterations"
                // Importance from model output when available, otherwise derive from confidence
                val explicitImportance = lastResult.structured["importance"]?.toFloatOrNull()
                    ?: if (lastResult.confidence > 0.8f) 0.9f else 0.7f
                val node = SemanticMemory.addNode(
                    id = nodeId,
                    label = "${operator} result",
                    content = lastResult.output,
                    type = if (operator == "INTEGRATE") "solution" else "insight",
                    importance = explicitImportance,
                    confidence = lastResult.confidence
                )
                WorkingMemory.add(node)
            }

            // ── PHASE STATE MACHINE ──
            // Deterministic operator sequencing. The metacognitive monitor can
            // override (e.g., if stuck), but the default path is fixed:
            //   ORIENT → DECOMPOSE → SOLVE (all chunks) → HYPOTHESIZE → VERIFY → INTEGRATE
            //
            // This replaces the old system where the LLM chose its own next operator.

            var signal = MetacognitiveMonitor.decideNext(
                goalStackDepth = goalStack.size,
                lastOperator = operator,
                lastOutput = lastResult.output,
                lastSurprise = lastResult.surprise,
                confidence = lastResult.confidence,
                chunkCount = pendingChunks.size + solvedChunks.size,
                solvedChunks = solvedChunks.size
            )

            // ── DYNAMIC EXECUTIVE SCHEDULER ──
            // Instead of predefined phases, ask "What limits progress now?"
            // and select the operator that addresses the bottleneck.
            operator = when {
                // Budget exhausted → integrate what we have
                signal == StrategySignal.STOP -> "INTEGRATE"

                // Metacognitive override (stuck, high surprise, etc.)
                signal in setOf(
                    StrategySignal.REFLECT,
                    StrategySignal.SAVE_NOTE,
                    StrategySignal.RETRIEVE_NOTE,
                    StrategySignal.VERIFY,
                    StrategySignal.FIRST_PRINCIPLES,
                    StrategySignal.ANALOGIZE,
                    StrategySignal.DECOMPOSE,
                    StrategySignal.INTEGRATE
                ) -> mapSignalToOperator(signal, lastResult)

                // Pending chunks → solve them (DFS enforcement — always)
                pendingChunks.isNotEmpty() -> "SOLVE_CHUNK"

                // v8 FIX 5: tension-driven, emergent operator selection.
                // The next operator EMERGES from the cognitive state (contradictions,
                // open questions, uncertainty, prediction error) instead of being chosen
                // by a fixed priority tree. The archive may override ONLY when it is
                // genuinely confident (sampleSize >= 3, successRate > 0.75) and early
                // in the session — and when it does, it is ACTUALLY used (FIX 8).
                else -> run schedule@{
                    val activeState = cogState
                    val stateBasedOp = if (activeState != null)
                        selectNextOperatorFromState(activeState, iterations, pendingChunks, solvedChunks)
                    else
                        detectBottleneck(operator, iterations, lastResult.confidence, lastResult.surprise)

                    // Check StrategyArchive for a high-confidence override.
                    val goalWordsLocal = query.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
                    val archiveStrategies = UnifiedStrategyArchive.selectForGoal(goalWordsLocal)
                    val bestStrategy = archiveStrategies.firstOrNull()

                    if (bestStrategy != null && bestStrategy.successRate > 0.75f &&
                        bestStrategy.sampleSize >= 3 && iterations <= 2) {
                        val suggestedOp = bestStrategy.description.uppercase().trim()
                        if (suggestedOp in validOperatorSet && suggestedOp != stateBasedOp) {
                            AppLog.logStructured("INFO", "ARCHIVE_OVERRIDE", iterations,
                                "Archive overrides $stateBasedOp → $suggestedOp " +
                                    "(${bestStrategy.sampleSize} sessions, " +
                                    "${"%.0f".format(bestStrategy.successRate * 100)}% success)")
                            return@schedule suggestedOp  // ACTUALLY USE IT when archive is confident
                        }
                    }

                    AppLog.logStructured("INFO", "SCHEDULER", iterations,
                        "Tension=${"%.2f".format(activeState?.tension() ?: 0f)} → $stateBasedOp " +
                            "(beliefs=${activeState?.beliefs?.size ?: 0}, chunks=${pendingChunks.size}, " +
                            "contradictions=${activeState?.contradictions?.size ?: 0})",
                        mapOf("operator" to operator, "selected" to stateBasedOp))

                    stateBasedOp
                }
            }

            if (operator == "SELF_EVALUATE") {
                lastResult = runSelfEvaluate(query)
                // After evaluation, integrate
                lastResult = runIntegrate(query)
                break
            }

            if (operator == "INTEGRATE") {
                // Run self-evaluation before integrating
                val evalResult = runSelfEvaluate(query)
                AppLog.logStructured("INFO", "PRE-INTEGRATE", iterations,
                    "Self-eval before integrate: ${evalResult.output.take(60)}")
                lastResult = runIntegrate(query)
                break
            }

            if (operator == "HYPOTHESIZE") {
                lastResult = runHypothesize(query)
                // After hypothesizing, verify or integrate
                operator = if (hasUnverifiedBeliefs()) "VERIFY" else "INTEGRATE"
                if (operator == "INTEGRATE") {
                    lastResult = runIntegrate(query)
                    break
                }
            }
        }

        // ── EPISODIC SESSION RECORDING ──
        // Record the full reasoning path for future "I solved something similar" recall
        val mistakes = sessionOutcomes.filter { !it.success }.map { "${it.operator}: conf=${"%.2f".format(it.confidence)}" }
        val corrections = sessionOutcomes.filter { it.success && sessionOutcomes.any { o -> !o.success && o.operator == it.operator } }
            .map { "${it.operator}: corrected to conf=${"%.2f".format(it.confidence)}" }
        EpisodicMemory.recordSession(
            goal = query,
            operatorSequence = sessionOutcomes.map { it.operator },
            mistakes = mistakes,
            corrections = corrections,
            finalConfidence = sessionOutcomes.lastOrNull()?.confidence ?: 0f,
            problemType = sessionProblemType,
            success = sessionOutcomes.count { it.success } > sessionOutcomes.size / 2
        )

        // ── CONCEPT FORMATION: Extract abstractions from recent sessions ──
        val abstractionResult = runAbstraction(query)
        if (abstractionResult.output.contains("Abstraction")) {
            AppLog.logStructured("INFO", "CONCEPT-FORM", 0,
                "Concept formation: ${abstractionResult.output.take(60)}")
        }

        // ── META-LEARNING: Record session outcomes to strategy archive ──
        val avgConfidence = sessionOutcomes.map { it.confidence }.average().toFloat()
        val avgSurprise = sessionOutcomes.map { it.surprise }.average().toFloat()
        val operatorSequence = sessionOutcomes.map { it.operator }
        val uniqueOperators = operatorSequence.distinct()

        // ── CAUSAL CREDIT ASSIGNMENT ──
        // Compute per-operator contribution: how much did each operator improve beliefs?
        val currentAvgConf = SemanticMemory.getAllActive()
            .filter { it.nodeType in setOf("fact", "hypothesis", "principle") }
            .map { it.confidence }.average().toFloat()

        // Walk through outcomes and compute contributions
        val updatedOutcomes = sessionOutcomes.mapIndexed { idx, outcome ->
            val confAfter = when {
                idx < sessionOutcomes.size - 1 ->
                    // Use actual next operator's reported confidence, not its confidenceBefore.
                    sessionOutcomes[idx + 1].confidence
                else -> lastResult.confidence
            }
            outcome.copy(
                confidenceAfter = confAfter,
                contribution = (confAfter - outcome.confidenceBefore).coerceIn(-0.5f, 0.5f)
            )
        }
        sessionOutcomes.clear()
        sessionOutcomes.addAll(updatedOutcomes)

        // Log per-operator contributions
        val contributions = sessionOutcomes.groupBy { it.operator }
            .mapValues { (_, outcomes) -> outcomes.map { it.contribution }.sum() }
            .toList()
            .sortedByDescending { it.second }

        contributions.forEach { (op, contrib) ->
            AppLog.logStructured("INFO", "CREDIT", 0,
                "Operator $op: contribution ${"%+.3f".format(contrib)}",
                mapOf("operator" to op, "contribution" to "%.3f".format(contrib)))
        }

        // Get self-evaluation score if available
        val evalNode = SemanticMemory.getAllActive().find { it.nodeType == "evaluation" }
        val evalScore = evalNode?.confidence ?: avgConfidence
        val sessionSuccess = evalScore > 0.6f  // use eval score, not just confidence

        AppLog.logStructured("INFO", "META-LEARN", 0,
            "Session eval: ${"%.2f".format(evalScore)} (from ${if (evalNode != null) "self-evaluation" else "confidence"})",
            mapOf("improvement" to "%.2f".format(evalScore - avgConfidence)))

        // Register each operator used as a strategy arm
        uniqueOperators.forEach { op ->
            val armId = "cognitive_${sessionProblemType}_${op.lowercase()}"
            UnifiedStrategyArchive.register(StrategyArm(
                id = armId,
                source = "cognitive",
                description = "$op for $sessionProblemType problems",
                tags = setOf(sessionProblemType, op.lowercase())
            ))
            // Weight the outcome by this operator's contribution
            val opContribution = contributions.find { it.first == op }?.second ?: 0f
            val weightedSuccess = sessionSuccess && opContribution >= 0f  // only reinforce operators that contributed
            UnifiedStrategyArchive.recordOutcome(armId, weightedSuccess)
        }

        // Register the full operator sequence as a compound strategy
        if (operatorSequence.size >= 3) {
            val seqId = "seq_${sessionProblemType}_${System.currentTimeMillis()}"
            UnifiedStrategyArchive.register(StrategyArm(
                id = seqId,
                source = "cognitive",
                description = "Sequence: ${operatorSequence.joinToString(" → ")}",
                tags = setOf(sessionProblemType) + uniqueOperators.map { it.lowercase() }.toSet()
            ))
            UnifiedStrategyArchive.recordOutcome(seqId, sessionSuccess)
        }

        AppLog.logStructured("INFO", "META-LEARN", 0,
            "Session recorded: $sessionProblemType, ${uniqueOperators.size} operators, conf=${"%.2f".format(avgConfidence)}",
            mapOf("sequence" to operatorSequence.joinToString(","), "success" to sessionSuccess.toString()))

        // ── MEMORY LIFECYCLE ──
        // Consolidate high-activation memories into generalized patterns
        SemanticMemory.consolidate()
        // Forget low-activation, rarely-accessed memories
        SemanticMemory.forget()

        SemanticMemory.save(context)
        ExternalMemory.save(context)
        consolidateSkills()
        // LLM-based consolidation for deeper skill extraction (blueprint Part 4.5).
        // Runs the crude skill extraction first (fast), then tries the deeper LLM path.
        consolidateWithLLM()

        // ── v8 FIX 4: SINGLE AUTHORITATIVE CONFIDENCE ──
        // Three confidence values used to coexist and never reconcile (INTEGRATE's
        // self-report ~0.95, the calibrated formula ~0.33, and the last operator's
        // value which might be CURIOSITY=0.5). Compute ONE value now, at session end,
        // using INTEGRATE's parsed confidence as the primary input — not the last
        // operator's, which may be a low-signal exploratory step.
        val integrateConf = lastResult.structured["confidence"]?.toFloatOrNull()
            ?: sessionOutcomes
                .filter { it.operator in setOf("SOLVE_CHUNK", "VERIFY", "INTEGRATE") }
                .map { it.confidence }
                .average()
                .takeIf { !it.isNaN() }?.toFloat()
            ?: lastResult.confidence

        // Count contradictions surfaced during the session (from the shared state).
        val sessionContradictions = cogState?.contradictions?.size ?: 0

        val authoritativeConfidence = computeCalibratedConfidence(
            llmConfidence = integrateConf,                    // INTEGRATE's value, not lastResult
            contradictionCount = sessionContradictions,
            hasVerification = lastVerificationOutcome != null,
            verificationPassed = lastVerificationOutcome,
            operatorAgreement = if (sessionOutcomes.size > 1) {
                val recentConfs = sessionOutcomes.takeLast(4)
                    .filter { it.operator != "CURIOSITY" }    // CURIOSITY is always ~0.5 — exclude it
                    .map { it.confidence }
                if (recentConfs.size < 2) 0.5f
                else {
                    val mean = recentConfs.average().toFloat()
                    1f - recentConfs.map { kotlin.math.abs(it - mean) }.average().toFloat()
                }
            } else 0.5f
        )

        AppLog.logStructured("INFO", "CONFIDENCE", 0,
            "Authoritative confidence ${"%.2f".format(authoritativeConfidence)} " +
                "(integrate=${"%.2f".format(integrateConf)}, verified=$lastVerificationOutcome, " +
                "contradictions=$sessionContradictions)")

        CognitiveResult(
            finalAnswer = lastResult.output,
            trace = reasoningTrace,
            confidence = authoritativeConfidence,   // the ONE authoritative value
            memorySnapshot = run {
                val cutoff = sessionStartMs
                val sessionNodes = SemanticMemory.getAllActive()
                    .filter { node -> node.id.contains("_") &&
                        node.id.substringAfterLast("_").toLongOrNull()?.let { t -> t >= cutoff } == true }
                    .sortedByDescending { it.activation }
                val fallbackNodes = SemanticMemory.getAllActive()
                    .filter { it !in sessionNodes }
                    .sortedByDescending { it.activation }
                (sessionNodes + fallbackNodes).take(5)
            },
            structuredAnswer = lastResult.structured
        )
    }

    private fun mapSignalToOperator(signal: StrategySignal, lastResult: OperatorResult): String {
        return when (signal) {
            StrategySignal.CONTINUE -> {
                // If chunks are pending, ALWAYS solve them — ignore LLM's suggestion.
                if (pendingChunks.isNotEmpty()) "SOLVE_CHUNK"
                // Otherwise, follow the LLM's suggestion if it's a valid operator.
                // DECOMPOSE is allowed here because decompositionRounds and
                // pendingChunks.size guards in runDecompose() prevent infinite loops.
                else lastResult.structured["next_operator"]?.takeIf {
                    it in setOf("DECOMPOSE", "FIRST_PRINCIPLES", "ANALOGIZE",
                        "SOLVE_CHUNK", "VERIFY", "EXECUTE", "INTEGRATE",
                        "REFLECT", "SAVE_NOTE", "RETRIEVE_NOTE")
                } ?: "DECOMPOSE"
            }
            StrategySignal.DECOMPOSE -> "DECOMPOSE"
            StrategySignal.FIRST_PRINCIPLES -> "FIRST_PRINCIPLES"
            StrategySignal.ANALOGIZE -> "ANALOGIZE"
            StrategySignal.VERIFY -> "VERIFY"
            StrategySignal.REFLECT -> "REFLECT"
            StrategySignal.SAVE_NOTE -> "SAVE_NOTE"
            StrategySignal.RETRIEVE_NOTE -> "RETRIEVE_NOTE"
            StrategySignal.INTEGRATE -> "INTEGRATE"
            StrategySignal.STOP -> "STOP"
        }
    }

    /**
     * Check if there are beliefs in SemanticMemory that haven't been verified.
     * Used by the phase state machine to decide whether to HYPOTHESIZE/VERIFY.
     */
    private fun hasUnverifiedBeliefs(): Boolean {
        val beliefs = SemanticMemory.getAllActive()
        val verified = beliefs.filter { it.nodeType == "verification" }
        val hypotheses = beliefs.filter { it.nodeType in setOf("fact", "principle", "analogy", "hypothesis") }
        return hypotheses.size > verified.size
    }

    /**
     * Lightweight belief audit (SAVeR-inspired).
     * After an operator produces output, check for common faithfulness violations:
     * - Unsupported claims (claims with no evidence)
     * - Circular reasoning (restating the question as answer)
     * - Prompt echoes (formatting instructions in reasoning)
     */
    private fun auditBelief(output: String, operator: String): BeliefAudit {
        val issues = mutableListOf<String>()

        // Check for prompt echoes
        if (output.contains("===JSON===") || output.contains("Do not output") ||
            output.contains("Do not add")) {
            issues.add("Prompt echo detected in output")
        }

        // Check for circular reasoning (output just restates the question)
        val outputWords = output.lowercase().split(Regex("\\s+")).toSet()
        val questionWords = goalStack.lastOrNull()?.lowercase()?.split(Regex("\\s+"))?.toSet() ?: emptySet()
        val overlap = if (questionWords.isNotEmpty()) {
            outputWords.intersect(questionWords).size.toFloat() / questionWords.size
        } else 0f
        if (overlap > 0.8f && output.length < 200) {
            issues.add("Possible circular reasoning (high word overlap with question)")
        }

        // Check for empty/placeholder output
        if (output.isBlank() || output.length < 20) {
            issues.add("Output too short or empty")
        }

        return BeliefAudit(
            hasIssues = issues.isNotEmpty(),
            issues = issues
        )
    }

    /**
     * Detect the current bottleneck — "What limits progress now?"
     * This replaces the predefined phase state machine with dynamic
     * bottleneck-driven operator selection.
     *
     * Research: Meta-network (Nature 2025), RLDE-AFL (arXiv 2025)
     */
    private fun detectBottleneck(
        currentOperator: String,
        iterations: Int,
        lastConfidence: Float,
        lastSurprise: Float
    ): String {
        // Check each possible bottleneck in priority order
        val activeBeliefs = SemanticMemory.getAllActive()
            .filter { it.nodeType in setOf(
                "fact", "hypothesis", "principle",
                "claim",
                "orientation",
                "plan",
                "verification", "analogy",
                "abstraction", "prediction"
            ) }

        // 1. Problem not understood?
        if (iterations <= 1 && activeBeliefs.size < 2) return "ORIENT"

        // 2. Problem too big?
        if (activeBeliefs.size < 3 && pendingChunks.isEmpty() && iterations <= 4) return "DECOMPOSE"

        // 3. Unsolved chunks?
        if (pendingChunks.isNotEmpty()) return "SOLVE_CHUNK"

        // 4. Not enough knowledge — but only trigger CURIOSITY if we actually have SOME beliefs.
        val beliefCount = activeBeliefs.size
        if (beliefCount in 1..3 && iterations <= 10) return "CURIOSITY"
        if (beliefCount == 0 && iterations <= 10) return "FIRST_PRINCIPLES"

        // 5. Can we predict outcomes?
        val hasPredictions = activeBeliefs.any { it.nodeType == "prediction" }
        if (!hasPredictions && iterations <= 12) return "PREDICT"

        // 6. Do we have a testable hypothesis?
        val hasHypothesis = activeBeliefs.any { it.nodeType == "hypothesis" }
        if (hasHypothesis && !activeBeliefs.any { it.nodeType == "verification" }) return "VERIFY"

        // 7. Can we extract abstractions?
        val sessionCount = EpisodicMemory.all().count { it.operator == "SESSION" }
        if (sessionCount >= 2 && !activeBeliefs.any { it.nodeType == "abstraction" }) return "ABSTRACT"

        // 8. Default: integrate
        return "INTEGRATE"
    }

    /**
     * Multi-signal confidence calibration.
     * Instead of trusting the LLM's self-reported confidence, compute from:
     * - LLM self-report (30% weight)
     * - Retrieval quality / working memory load (20%)
     * - Contradiction count (penalty)
     * - Prediction success (15%)
     * - Verification outcome (15%)
     * - Operator agreement (10%)
     *
     * This produces a much more robust confidence than LLM self-report alone.
     * Research: CoALA (2024), BeliefMem (2026)
     */
    private fun computeCalibratedConfidence(
        llmConfidence: Float,
        contradictionCount: Int,
        hasVerification: Boolean,
        verificationPassed: Boolean?,
        operatorAgreement: Float = 0.5f
    ): Float {
        var conf = llmConfidence * 0.3f  // LLM gets 30% weight
        // v8 FIX 4: do NOT penalize low memory load (old formula made a sparse-but-correct
        // session look low-confidence). Any memory at all is a small boost; no penalty.
        val memoryRichness = if (WorkingMemory.size() > 0) 0.1f else 0f
        conf += memoryRichness
        conf -= contradictionCount * 0.1f  // contradictions penalize
        if (hasVerification && verificationPassed == true) conf += 0.15f  // verification boosts
        else if (hasVerification && verificationPassed == false) conf -= 0.15f
        conf += operatorAgreement * 0.1f  // operator agreement boosts
        return conf.coerceIn(0.05f, 0.95f)
    }

    /**
     * v8 FIX 3: extract binding constraints from a solved chunk's answer — decisions
     * that must bind future chunks. A small LLM can ignore "PRIOR DISCOVERIES" but
     * cannot ignore "⚡ BINDING CONSTRAINTS — your answer MUST respect these."
     */
    private fun extractConstraints(answer: String, sourceChunk: String): List<String> {
        if (answer.length < 20 || answer.contains("===JSON===")) return emptyList()

        val constraints = mutableListOf<String>()

        // Pattern 1: "must/should/requires/needs X"
        Regex("(?i)(must|should|requires?|needs?|will use|is necessary|has to)\\s+([^.;,]{10,80})[.,;]")
            .findAll(answer).take(2).forEach { constraints.add(it.value.trim()) }

        // Pattern 2: "therefore/thus/so X"
        Regex("(?i)(therefore|thus|so),?\\s+([^.;]{10,80})[.]")
            .findAll(answer).take(1).forEach { constraints.add(it.value.trim()) }

        // Pattern 3: Explicit choices ("using/employing/we use/chose/selected X")
        Regex("(?i)(using|employing|we (use|chose|selected)|based on)\\s+([A-Z][^.;,]{5,60})[.,;]")
            .findAll(answer).take(2).forEach { constraints.add(it.value.trim()) }

        // Label them with their source.
        return constraints.map { "From [${sourceChunk.take(30)}]: $it" }.take(3)
    }

    /**
     * v8 FIX 5: tension-driven operator selection. Instead of a fixed priority tree,
     * the next operator EMERGES from the cognitive state (contradictions, open
     * questions, uncertainty, prediction error). Falls back to detectBottleneck for
     * edge cases the tension model doesn't cover.
     */
    private fun selectNextOperatorFromState(
        state: CognitiveStateTracker,
        iterations: Int,
        pendingChunks: List<String>,
        solvedChunks: Map<String, String>
    ): String {
        val tension = state.tension()

        return when {
            // 1. Contradictions create maximum tension → verify first.
            state.contradictions.isNotEmpty() && iterations < 15 -> "VERIFY"

            // 2. Open questions / pending chunks → solve them.
            pendingChunks.isNotEmpty() -> "SOLVE_CHUNK"

            // 3. Very high uncertainty with no beliefs → first principles.
            tension > 0.7f && state.beliefs.isEmpty() -> "FIRST_PRINCIPLES"

            // 4. High prediction error → hypothesize.
            state.predictionError > 0.5f -> "HYPOTHESIZE"

            // 5. Some beliefs but uncertainty still high → explore with CURIOSITY.
            tension > 0.4f && state.beliefs.isNotEmpty() && state.openQuestions.isEmpty() -> "CURIOSITY"

            // 6. Low tension, enough beliefs → we're done, evaluate then integrate.
            tension < 0.2f && state.beliefs.size >= 3 -> "SELF_EVALUATE"

            // 7. Fallback to detectBottleneck for edge cases.
            else -> detectBottleneck(
                currentOperator = "UNKNOWN",
                iterations = iterations,
                lastConfidence = state.overallConfidence,
                lastSurprise = state.predictionError
            )
        }
    }

    /**
     * v8 FIX 7: cross-chunk consistency verification. Runs automatically once all
     * chunks are solved (so VERIFICATION_TESTING actually fires) and checks the
     * derived beliefs against each other and against the binding constraints.
     */
    private suspend fun runChunkConsistencyVerify(state: CognitiveStateTracker): OperatorResult {
        if (state.beliefs.size < 2) return OperatorResult(
            "VERIFY", "Only 1 belief — no cross-check needed", confidence = 0.7f
        )
        val beliefsText = state.beliefs.joinToString("\n") {
            "• [${(it.confidence * 100).toInt()}%] ${it.content.take(100)}"
        }
        val constraintsText = state.constraints.take(5).joinToString("\n") { "• $it" }
        val prompt = buildPrompt(
            "Cross-check consistency of derived beliefs",
            """
            |Check these beliefs for internal consistency and constraint violations.
            |
            |BELIEFS:
            |$beliefsText
            |
            |CONSTRAINTS THAT MUST HOLD:
            |$constraintsText
            |
            |Are there any contradictions? Do all beliefs respect all constraints?
            |Output JSON: {"consistent": true/false, "contradictions": ["..."], "verdict": "..."}
            """.trimMargin(),
            state = state
        )
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_SMALL)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))
        val isConsistent = structured["consistent"]?.equals("true", ignoreCase = true) ?: true
        val contradictions = structured["contradictions"] ?: ""
        if (!isConsistent && contradictions.isNotBlank()) {
            state.addContradiction(contradictions.take(100))
        }

        // Persist verification to SemanticMemory so hasUnverifiedBeliefs() sees it.
        val verifyNodeId = "verify_${System.currentTimeMillis()}"
        SemanticMemory.addNode(
            id = verifyNodeId,
            label = "Cross-check: ${if (isConsistent) "consistent" else "contradiction"}",
            content = (structured["verdict"] ?: "Cross-check completed.").take(150),
            type = "verification",
            importance = if (isConsistent) 0.8f else 0.5f,
            confidence = if (isConsistent) 0.85f else 0.6f
        )

        return OperatorResult(
            operator = "VERIFY",
            output = structured["verdict"] ?: "Cross-check completed.",
            structured = structured,
            confidence = if (isConsistent) 0.85f else 0.6f
        )
    }

    // Build a tiny prompt using only working memory + current goal.
    //
    // v8 FIX 2: No JSON instruction is embedded here anymore. JSON extraction happens
    // in a SEPARATE second call (see callModelExpectingJson). This eliminates the echo
    // problem: the model never sees "write ===JSON===" as part of its reasoning context,
    // so small LLMs stop regurgitating formatting instructions into the thinking stream.
    //
    // v8 FIX 5: An optional CognitiveStateTracker can be injected. Its toPromptSection()
    // surfaces binding constraints, established beliefs, open questions, and contradictions
    // as explicit, first-class drivers rather than opaque background memory.
    private fun buildPrompt(
        goal: String,
        operatorPrompt: String,
        expectsJson: Boolean = true,
        state: CognitiveStateTracker? = null
    ): String {
        val stateSection = state?.toPromptSection() ?: ""
        return """
            |Current goal: $goal
            |
            |$stateSection
            |Active working memory (only relevant items):
            |${WorkingMemory.toPromptString()}
            |
            |$operatorPrompt
            |
            |Think through this carefully and give your best answer:
        """.trimMargin()
    }

    /**
     * Wraps callModel with a single corrective retry for when JSON extraction comes
     * back completely empty -- i.e. the model never produced anything ReasoningOperators
     * could find at all, not even a malformed attempt. This was the dominant failure
     * mode behind the "Decomposed into 0 chunks" / "null" reasoning-trace bug: a model
     * reasoning richly in free text but never emitting anything extractJson() could
     * locate. The buildPrompt() marker instruction above fixes most of this on its own;
     * this retry is the safety net for whatever it doesn't catch.
     *
     * Returns the ORIGINAL raw text (not the retry's) when the retry also fails, so the
     * full free-form thinking is still preserved for display even when structured
     * extraction never succeeds -- losing the model's reasoning text would be worse than
     * losing the structured fields.
     */
    //
    // v8 FIX 2: Two-stage model call — separate "thinking" from "formatting".
    // Stage 1 contains NO formatting instruction, so the model reasons freely without
    // echoing "Do NOT provide", "===JSON===", etc. into its thinking. Stage 2 is a
    // minimal extraction call that only sees the model's own prior thinking as context,
    // so it's too short for instruction echoing to occur.
    private suspend fun callModelExpectingJson(prompt: String, maxTokens: Int): String {
        // Stage 1: Free thinking — NO formatting instruction, NO ===JSON=== marker.
        val thinking = callModel(prompt, maxTokens)

        // Did the model spontaneously produce JSON? (Some models do this naturally.)
        val spontaneousJson = ReasoningOperators.extractJson(thinking)
        val hasJson = spontaneousJson.trimStart().firstOrNull().let { it == '{' || it == '[' }
        if (hasJson) {
            // Model produced JSON on its own — use it with the ===JSON=== marker so
            // extractJson() finds it cleanly on the next pass.
            return "$thinking\n===JSON===\n$spontaneousJson"
        }

        AppLog.append("CognitiveEngine: no JSON in stage-1 thinking (${thinking.length} chars) -- running stage-2 extraction.")

        // Stage 2: Extraction — give the model its own thinking as context, ask ONLY
        // for the JSON, nothing else. This call is SHORT, so the model doesn't echo.
        val extractionPrompt = """
            |Based on the following reasoning, extract a structured JSON answer.
            |
            |REASONING:
            |${thinking.takeLast(800)}
            |
            |Now output ONLY the JSON object/array described in the task. Nothing else:
        """.trimMargin()
        val extracted = runCatching {
            callModel(extractionPrompt, (maxTokens / 2).coerceAtLeast(80))
        }.getOrDefault("")

        val extractedJson = ReasoningOperators.extractJson(extracted)
        val extractedHasJson = extractedJson.trimStart().firstOrNull().let { it == '{' || it == '[' }

        // Splice the extracted JSON onto the end of the original free-form thinking so
        // both the rich reasoning text AND a parseable JSON tail survive for display
        // and for extractJson() to find on the next call. If extraction failed, return
        // raw thinking (best-effort structure beats losing the model's reasoning text).
        return if (extractedHasJson) "$thinking\n===JSON===\n$extractedJson" else thinking
    }

    /**
     * v8 FIX 6: Strip prompt/formatting contamination from text before it enters the
     * cumulative thinking trace or is stored as a memory "fact". Even after FIX 2
     * eliminates most echoing, residual instruction fragments from operator prompts
     * (e.g. "Output a JSON object with fields...", "BINDING CONSTRAINTS (your answer...)")
     * can still appear. This is the engine-side equivalent of CognitivePanel's
     * stripPromptEchoes().
     */
    private fun cleanThinkingStream(raw: String): String {
        return raw
            .replace(Regex("===JSON===.*", RegexOption.DOT_MATCHES_ALL), "")
            .replace(Regex("(?i)output (only |just )?(the )?json.*"), "")
            .replace(Regex("(?i)(critical )?rules?:.*?\\n(\\d+\\.|•)[^\\n]+"), "")
            .replace(Regex("(?i)binding constraints \\(your answer.*?\\)\\s*"), "")
            .replace(Regex("(?i)prior discoveries.*?\\n"), "")
            .replace(Regex("(?i)(do not|don't) (add|provide|output|include)[^.\\n]*[.\\n]"), "")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private suspend fun runOrient(goal: String): OperatorResult {
        val prompt = buildPrompt(goal, ReasoningOperators.buildOrientPrompt(goal, WorkingMemory.toPromptString()))
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val topic = structured["topic"] ?: goal.take(40)
        val confusion = structured["confusion_level"] ?: "medium"
        val nextOp = structured["next_operator"] ?: "DECOMPOSE"
        val surprise = when (confusion) { "high" -> 0.6f; "medium" -> 0.3f; else -> 0.1f }

        // Write orientation to SemanticMemory so it persists across operators
        val orientNodeId = "orient_${System.currentTimeMillis()}"
        val orientNode = SemanticMemory.addNode(
            id = orientNodeId,
            label = "Topic: $topic",
            content = "Confusion: $confusion. Unknowns: ${structured["unknowns"] ?: "none"}. Next: $nextOp",
            type = "orientation",
            importance = 0.7f,
            confidence = 0.8f
        )
        WorkingMemory.add(orientNode)
        SemanticMemory.activateNode(orientNodeId, 0.9f)  // orientation is strongly active

        // Extract problem type for meta-learning
        sessionProblemType = topic.lowercase().split(Regex("\\s+")).take(3).joinToString("_")
        sessionOutcomes.clear()

        // v8 FIX 5: seed the shared cognitive state with the open questions and the
        // confusion level, so tension starts from the model's actual orientation.
        cogState?.let { cs ->
            (structured["unknowns"] ?: "").split(Regex("[;,]"))
                .map { it.trim() }.filter { it.length > 3 }
                .forEach { cs.addOpenQuestion(it) }
            cs.uncertainty = when (structured["confusion_level"]) {
                "high" -> 0.8f; "medium" -> 0.5f; else -> 0.3f
            }
        }

        return OperatorResult(
            operator = "ORIENT",
            output = "Topic: $topic. Confusion: $confusion. Next: $nextOp",
            structured = structured,
            confidence = 0.8f,
            surprise = surprise
        )
    }

    private var decompositionRounds = 0
    private val MAX_DECOMPOSITION_ROUNDS = 2

    private suspend fun runDecompose(goal: String): OperatorResult {
        // Guard: if we already have enough pending chunks, refuse to decompose further.
        // The engine must solve what it has before generating more questions.
        if (pendingChunks.size >= 6) {
            AppLog.logStructured("WARN", "DECOMPOSE", 0,
                "Refusing further decomposition: ${pendingChunks.size} chunks already queued.")
            return OperatorResult(
                operator = "DECOMPOSE",
                output = "Enough chunks queued (${pendingChunks.size}). Moving to SOLVE.",
                structured = mapOf("chunk_count" to pendingChunks.size.toString()),
                confidence = 0.8f, surprise = 0.1f, subgoals = pendingChunks.toList()
            )
        }

        decompositionRounds++
        if (decompositionRounds > MAX_DECOMPOSITION_ROUNDS) {
            AppLog.logStructured("WARN", "DECOMPOSE", 0,
                "Max decomposition rounds ($MAX_DECOMPOSITION_ROUNDS) reached. Forcing solve phase.")
            return OperatorResult(
                operator = "DECOMPOSE",
                output = "Max decomposition rounds reached. Working with ${pendingChunks.size} existing chunks.",
                structured = mapOf("chunk_count" to pendingChunks.size.toString()),
                confidence = 0.7f, surprise = 0.1f, subgoals = pendingChunks.toList()
            )
        }

        val orient = OperatorResult("ORIENT", "", mapOf("topic" to goal, "unknowns" to ""))
        val prompt = buildPrompt(goal, ReasoningOperators.buildDecomposePrompt(goal, orient))
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_LARGE)
        val chunks = ReasoningOperators.parseJsonArray(ReasoningOperators.extractJson(raw))

        // FIX: Do NOT clear pendingChunks. Add new chunks only if not already present.
        val existing = pendingChunks.toSet()
        var added = 0
        chunks.forEach { chunk ->
            chunk["question"]?.let { q ->
                if (q !in existing && pendingChunks.size < 8) {
                    pendingChunks.add(q)
                    added++
                }
            }
        }

        AppLog.logStructured("INFO", "DECOMPOSE", 0,
            "Decomposition round $decompositionRounds: added $added new chunks, total ${pendingChunks.size}")

        // Write decomposition plan to SemanticMemory
        val planNodeId = "plan_${System.currentTimeMillis()}"
        val planNode = SemanticMemory.addNode(
            id = planNodeId,
            label = "Decomposition: ${pendingChunks.size} chunks",
            content = pendingChunks.joinToString("; "),
            type = "plan",
            importance = 0.6f,
            confidence = 0.75f
        )
        WorkingMemory.add(planNode)
        SemanticMemory.activateNode(planNodeId, 0.7f)

        return OperatorResult(
            operator = "DECOMPOSE",
            output = "Decomposed: $added new chunks added. Queue: ${pendingChunks.size} total.",
            structured = mapOf("chunk_count" to pendingChunks.size.toString()),
            confidence = 0.75f,
            surprise = 0.2f,
            subgoals = pendingChunks.toList()
        )
    }

    private suspend fun runFirstPrinciples(goal: String): OperatorResult {
        val prompt = buildPrompt(goal, ReasoningOperators.buildFirstPrinciplesPrompt(goal))
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val nodeId = "fp_${System.currentTimeMillis()}"
        val content = "${structured["base_problem"]} → ${structured["causal_chain"]} → ${structured["core_principle"]}"
        val node = SemanticMemory.addNode(nodeId, "First-principles chain", content, "principle")
        SemanticMemory.addEdge("n_root", nodeId, "DEPENDS_ON")
        WorkingMemory.add(node)

        return OperatorResult(
            operator = "FIRST_PRINCIPLES",
            output = "Base problem: ${structured["base_problem"]}. Core principle: ${structured["core_principle"]}. Rebuild: ${structured["rebuild_step"]}",
            structured = structured,
            confidence = 0.7f,
            surprise = 0.4f
        )
    }

    private suspend fun runAnalogize(goal: String): OperatorResult {
        val domains = listOf("biological", "physical", "computational", "economic", "structural").filter { it != currentDomain }
        val target = domains.random()
        val prompt = buildPrompt(goal, ReasoningOperators.buildAnalogizePrompt(goal, currentDomain, target))
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        currentDomain = target
        val output = "Analogy: ${structured["source_concept"]} ↔ ${structured["target_concept"]}. Insight: ${structured["insight"]}. Limit: ${structured["limit"]}"

        return OperatorResult(
            operator = "ANALOGIZE",
            output = output,
            structured = structured,
            confidence = 0.65f,
            surprise = 0.5f
        )
    }

    private suspend fun runSolveChunk(goal: String): OperatorResult {
        val chunk = pendingChunks.removeFirstOrNull() ?: goal
        val prior = solvedChunks.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
        // v8 FIX 3: pass the accumulated binding constraints + inject the cognitive
        // state section so the model treats prior decisions as binding, not optional.
        val prompt = buildPrompt(
            chunk,
            ReasoningOperators.buildSolveChunkPrompt(
                chunkQuestion = chunk,
                priorChunks = prior,
                memory = WorkingMemory.toPromptString(),
                constraints = sessionConstraints
            ),
            state = cogState
        )
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val answer = structured["answer"]
        // Validation: if the model generated more questions instead of an answer,
        // treat it as a low-confidence hypothesis from the raw text.
        val isQuestionLoop = answer.isNullOrBlank() ||
            answer.contains("?") && answer.length < 60 && !answer.contains("because") && !answer.contains("is ")
        val finalAnswer = if (isQuestionLoop) {
            // Extract a best-effort answer from the raw reasoning text
            val salvage = raw.replace(Regex("""\?[^.]*"""), ".").take(300).trim()
            if (salvage.isNotBlank()) salvage else "Hypothesis: ${chunk.take(100)} requires further investigation."
        } else answer

        solvedChunks[chunk] = finalAnswer

        // v8 FIX 6: sanitize before storing as a memory "fact" so prompt/formatting
        // contamination (e.g. "Do NOT provide...", "===JSON===") never enters memory.
        val sanitizedAnswer = finalAnswer
            .replace(Regex("(?i)(do not|don't) (add|provide|output|include).*?[.\\n]"), "")
            .replace(Regex("===JSON===.*", RegexOption.DOT_MATCHES_ALL), "")
            .replace(Regex("(?i)output (only|just) (the )?json.*"), "")
            .trim()
            .ifBlank { "Investigation pending: ${chunk.take(60)}" }

        // Deposit into SemanticMemory so subsequent operators can see this answer
        val nodeId = "solved_${System.currentTimeMillis()}"
        val conf = when (structured["confidence"]) {
            "high" -> 0.9f; "medium" -> 0.7f; "low" -> 0.5f; else -> 0.7f
        }
        val node = SemanticMemory.addNode(
            id = nodeId,
            label = "Solved: ${chunk.take(40)}",
            content = sanitizedAnswer,
            type = "fact",
            importance = conf,
            confidence = conf
        )
        WorkingMemory.add(node)

        // v8 FIX 3: extract binding constraints from this chunk's answer and from the
        // model's explicitly-stated new_constraints, then accumulate them for the next chunk.
        val newConstraints = extractConstraints(sanitizedAnswer, chunk)
        sessionConstraints.addAll(newConstraints)
        val newConstraintsFromModel = structured["new_constraints"]?.let { nc ->
            ReasoningOperators.parseJsonArray(ReasoningOperators.extractJson(nc))
                .mapNotNull { it["step"] ?: it["text"] ?: it.values.firstOrNull() }
        } ?: emptyList()
        sessionConstraints.addAll(newConstraintsFromModel.map { "Model-stated: $it" }.take(2))
        val allNewConstraints = newConstraints + newConstraintsFromModel.map { "Model-stated: $it" }.take(2)
        if (allNewConstraints.isNotEmpty()) {
            AppLog.logStructured("INFO", "CONSTRAINTS", 0,
                "Extracted ${allNewConstraints.size} constraints from solved chunk",
                mapOf("constraints" to allNewConstraints.joinToString("; ").take(120)))
        }

        // v8 FIX 5: update the shared cognitive state.
        cogState?.let { cs ->
            cs.addBelief(sanitizedAnswer.take(150), conf, "SOLVE_CHUNK[${chunk.take(30)}]")
            cs.resolveQuestion(chunk)
            allNewConstraints.forEach { cs.addConstraint(it) }
        }
        SemanticMemory.activateNode(nodeId, conf)
        SemanticMemory.inhibitUnrelated(nodeId)

        if (isQuestionLoop) {
            AppLog.logStructured("WARN", "SOLVE_CHUNK", 0,
                "Model generated questions instead of answer. Salvaged from raw text.",
                mapOf("chunk" to chunk.take(60)))
        }

        // Reconsolidate: update related existing beliefs with new knowledge
        SemanticMemory.getAllActive()
            .filter { it.id != nodeId && it.nodeType in setOf("fact", "principle", "hypothesis") }
            .take(3)
            .forEach { related ->
                SemanticMemory.reconsolidate(related.id, "Related to solved: ${chunk.take(40)} — ${finalAnswer.take(60)}", 0.02f)
            }

        AppLog.logStructured("INFO", "SOLVE_CHUNK", 0,
            "Chunk solved: ${chunk.take(50)}",
            mapOf("confidence" to "%.2f".format(conf), "pending" to pendingChunks.size.toString()))

        return OperatorResult(
            operator = "SOLVE_CHUNK",
            output = sanitizedAnswer,
            structured = structured + mapOf("answer" to sanitizedAnswer),
            confidence = if (isQuestionLoop) 0.4f else conf,
            surprise = if (structured["needs_code_test"] == "true") 0.4f else 0.15f,
            subgoals = pendingChunks.toList()
        )
    }

    private suspend fun runVerify(claim: String): OperatorResult {
        val evidence = WebSearchClient.search(claim, 2).let { WebSearchClient.formatGrounding(it) }
        val prompt = buildPrompt(claim, ReasoningOperators.buildVerifyPrompt(claim, evidence))
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_SMALL)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val verdict = structured["verdict"] ?: "UNCERTAIN"
        val confidence = structured["confidence"]?.toFloatOrNull() ?: 0.6f

        // v8 FIX 5 / FIX 7: feed verification outcome into the shared cognitive state
        // and record it so the calibrated-confidence formula can use it.
        val verifyPassed = verdict == "SUPPORTED"
        lastVerificationOutcome = verifyPassed
        cogState?.let { cs ->
            if (verdict == "CONTRADICTED") {
                cs.addContradiction("Claim '${claim.take(60)}' was contradicted")
            }
            // A successful verification reduces uncertainty.
            if (verifyPassed) cs.uncertainty = (cs.uncertainty - 0.15f).coerceAtLeast(0.05f)
        }

        // Write verification result to SemanticMemory
        val verifyNodeId = "verify_${System.currentTimeMillis()}"
        val verifyNode = SemanticMemory.addNode(
            id = verifyNodeId,
            label = "Verify: $verdict",
            content = "Claim: ${claim.take(80)}. Verdict: $verdict. ${structured["objection"] ?: ""}",
            type = "verification",
            importance = if (verdict == "SUPPORTED") 0.8f else 0.5f,
            confidence = confidence
        )
        WorkingMemory.add(verifyNode)

        return OperatorResult(
            operator = "VERIFY",
            output = "Verdict: $verdict. ${structured["objection"] ?: ""}",
            structured = structured,
            confidence = confidence,
            surprise = if (verdict == "SUPPORTED") 0.1f else 0.5f
        )
    }

    private suspend fun runExecute(claim: String): OperatorResult {
        val prompt = buildPrompt(claim, ReasoningOperators.buildExecutePrompt(claim), expectsJson = false)
        val code = callModel(prompt, MAX_TOKENS_MEDIUM)
        val result = CodeExecutionEngine.executeJavaScript(context, ReasoningOperators.wrapTestCode(code))

        if (result.success) {
            // NEW (blueprint 5.3): deposit the verified finding into long-term memory
            // immediately, the same way a human jots down a result they just confirmed
            // so they don't have to re-derive it later.
            val nodeId = "verified_${System.currentTimeMillis()}"
            SemanticMemory.addNode(
                id = nodeId,
                label = "Verified: ${claim.take(40)}",
                content = "Code execution confirmed: ${result.output.take(150)}",
                type = "fact",
                importance = 0.9f,     // verified facts are worth remembering strongly
                confidence = 0.95f     // empirically checked, not just asserted
            )
            WorkingMemory.add(SemanticMemory.getNode(nodeId)!!)
            ExternalMemory.writeNote(
                context,
                topic = "Verified: ${claim.take(40)}",
                summary = result.output.take(200),
                confidence = 0.95f,
                links = listOf(claim.take(60))
            )
        }

        return OperatorResult(
            operator = "EXECUTE",
            output = if (result.success) "Verified: ${result.output}" else "Execution failed: ${result.error}",
            structured = mapOf("raw_code" to code, "exec_output" to result.output),
            confidence = if (result.success) 0.95f else 0.3f,
            surprise = if (result.success) 0.1f else 0.6f
        )
    }

    private suspend fun runReflect(goal: String): OperatorResult {
        val history = reasoningTrace.takeLast(5).joinToString("\n")
        val prompt = buildPrompt(goal, ReasoningOperators.buildReflectPrompt(goal, history))
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_SMALL)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        return OperatorResult(
            operator = "REFLECT",
            output = "Diagnosis: ${structured["diagnosis"]}. New angle: ${structured["new_angle"]}",
            structured = structured,
            confidence = 0.6f,
            surprise = 0.5f
        )
    }

    private suspend fun runIntegrate(query: String): OperatorResult {
        val chunks = solvedChunks.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
        // Capped, not the full trace -- a long session's trace could otherwise eat into
        // the dynamic output budget below. The most recent steps are the most relevant
        // to "how did I arrive at the final answer" anyway.
        val reasoningPath = reasoningTrace.takeLast(12).joinToString("\n")

        // Dynamic context length (the user explicitly asked for this): a question that
        // took many sub-problems and many distinct concepts to work through deserves a
        // longer, more detailed final answer than one that resolved in a couple of
        // steps. Base budget covers a short answer; each solved chunk and each
        // first-principles/analogy step earns more room, capped well inside the
        // native context ceiling (raise the Settings panel's context-size slider if
        // you regularly hit the cap with very deep sessions).
        val conceptualDepth = reasoningTrace.count { it.contains("FIRST_PRINCIPLES") || it.contains("ANALOGIZE") }
        val dynamicBudget = (900 + (solvedChunks.size + pendingChunks.size) * 120 + conceptualDepth * 80)
            .coerceIn(900, 1600)

        // For INTEGRATE, only inject the top 3 most activated nodes to keep prompt short.
        // This leaves more token budget for the answer.
        val prevSize = WorkingMemory.size()
        WorkingMemory.trimToTop(3)
        AppLog.logStructured("INFO", "INTEGRATE", 0,
            "Trimmed working memory for integration: $prevSize → ${WorkingMemory.size()}")

        val prompt = buildPrompt(query, ReasoningOperators.buildIntegratePrompt(query, chunks, query, reasoningPath))
        val raw = callModelExpectingJson(prompt, dynamicBudget)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val confidence = structured["confidence"]?.toFloatOrNull() ?: 0.75f

        // Build a well-formatted flat string too, for any caller that only reads
        // .output -- definition first, then steps with headings, analogy last. The
        // richer structured map (below) is what the UI should prefer to render.
        val stepsList = structured["step_by_step"]?.let { ReasoningOperators.parseJsonArray(ReasoningOperators.extractJson(it)) } ?: emptyList()
        val formattedAnswer = buildString {
            structured["definition"]?.let { appendLine(it); appendLine() }
            stepsList.forEachIndexed { i, step ->
                val heading = step["heading"] ?: "Step ${i + 1}"
                appendLine("${i + 1}. $heading")
                appendLine(step["body"] ?: "")
                appendLine()
            }
            structured["analogy"]?.let { appendLine("Analogy: $it") }
        }.ifBlank {
            // JSON was empty or truncated. Try to salvage key fields before falling back to raw.
            val savedDef = structured["definition"]
                ?: ReasoningOperators.salvageField(raw, "definition") ?: ""
            val savedHowGot = structured["how_i_got_here"]
                ?: ReasoningOperators.salvageField(raw, "how_i_got_here") ?: ""
            val savedAnalogy = structured["analogy"]
                ?: ReasoningOperators.salvageField(raw, "analogy") ?: ""
            val savedInsight = structured["key_insight"]
                ?: ReasoningOperators.salvageField(raw, "key_insight") ?: ""

            when {
                savedDef.isNotBlank() -> buildString {
                    appendLine(savedDef)
                    if (savedAnalogy.isNotBlank()) appendLine("\nAnalogy: $savedAnalogy")
                    if (savedInsight.isNotBlank()) appendLine("\nKey insight: $savedInsight")
                    if (savedHowGot.isNotBlank()) appendLine("\nReasoning path: $savedHowGot")
                }
                else -> raw
                    .replace(Regex("===JSON==="), "")
                    .replace(Regex("(?i)\\(This is a strict formatting instruction\\.\\)"), "")
                    .replace(Regex("(?i)do not (add|put|output|include).*?\\."), "")
                    .replace(Regex("(?s)\\{[^\\{\\}]*\"how_i_got_here\".*"), "")
                    .trim()
            }
        }

        return OperatorResult(
            operator = "INTEGRATE",
            output = formattedAnswer,
            structured = structured + mapOf("how_i_got_here" to (structured["how_i_got_here"] ?: "")),
            confidence = confidence,
            surprise = 0.0f
        )
    }

    /**
     * CURIOSITY — generate alternative explanations for current beliefs.
     * This is the "What if...?" operator that explores alternatives.
     * After solving a chunk, this generates competing hypotheses and
     * picks the most promising one to explore further.
     */
    private suspend fun runCuriosity(query: String): OperatorResult {
        // Pick the most uncertain belief to challenge
        val beliefs = SemanticMemory.getAllActive()
            .filter { it.nodeType in setOf(
                "fact", "hypothesis", "principle", "claim", "orientation", "analogy"
            ) }
            .filter { it.confidence < 0.85f }
            .sortedBy { it.confidence }
        val target = beliefs.firstOrNull()
            ?: return OperatorResult(
                "CURIOSITY",
                "Waiting for solve phase to build beliefs worth challenging.",
                confidence = 0.5f,
                surprise = 0.0f
            )

        val prompt = ReasoningOperators.buildCuriosityPrompt(
            belief = target.label,
            currentExplanation = target.content.take(200),
            query = query
        )
        val raw = callModelExpectingJson(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val bestAlt = structured["best_alternative"]?.toIntOrNull() ?: 0
        val curiosityScore = structured["curiosity_score"]?.toFloatOrNull() ?: 0.5f

        // Write the best alternative as a new belief to explore
        val altNodeId = "curiosity_${System.currentTimeMillis()}"
        val altNode = SemanticMemory.addNode(
            id = altNodeId,
            label = "Alternative: ${target.label.take(30)}",
            content = "Alternative to '${target.label}': ${structured["alternatives"]?.take(200) ?: "explore further"}",
            type = "hypothesis",
            importance = curiosityScore,
            confidence = 0.4f  // low confidence — it's a new idea
        )
        WorkingMemory.add(altNode)

        AppLog.logStructured("INFO", "CURIOSITY", 0,
            "Generated alternatives for: ${target.label.take(50)}",
            mapOf("curiosity_score" to "%.2f".format(curiosityScore)))

        return OperatorResult(
            operator = "CURIOSITY",
            output = "Challenged '${target.label.take(50)}' — generated alternatives (score: ${"%.2f".format(curiosityScore)})",
            structured = structured,
            confidence = 0.4f,
            surprise = curiosityScore
        )
    }

    /**
     * PREDICT — generate competing hypotheses and simulate their consequences.
     * This implements internal simulation: the engine imagines multiple futures
     * and selects the most promising one before committing.
     *
     * Research: SiRA (arXiv 2026): simulative reasoning achieves 124% higher
     * completion than reactive policy. Global Workspace Theory (Shanahan 2005).
     */
    private suspend fun runPredict(query: String): OperatorResult {
        val beliefs = SemanticMemory.getAllActive()
            .filter { it.nodeType in setOf("fact", "hypothesis", "principle") && it.confidence > 0.5f }
            .sortedByDescending { it.activation }
            .take(5)
        val beliefSummary = beliefs.joinToString("\n") { "- ${it.label}: ${it.content.take(100)} (conf=${"%.2f".format(it.confidence)})" }

        val prompt = buildString {
            appendLine("You are MESA. Generate 2-3 COMPETING hypotheses and simulate their consequences.")
            appendLine()
            appendLine("QUESTION: $query")
            appendLine()
            appendLine("CURRENT BELIEFS:")
            appendLine(beliefSummary)
            appendLine()
            appendLine("Task: produce a JSON object with exactly these fields:")
            appendLine("  \"hypotheses\": a JSON array of 2-3 objects, each with:")
            appendLine("    \"hypothesis\": the hypothesis (1 sentence)")
            appendLine("    \"predicted_consequences\": what we'd observe if this is true (1-2 sentences)")
            appendLine("    \"simulated_outcome\": imagine testing this — what happens? (1 sentence)")
            appendLine("    \"confidence\": 0.0 to 1.0")
            appendLine("  \"selected_hypothesis\": index (0-based) of the most promising hypothesis")
            appendLine("  \"selection_reason\": why this hypothesis was selected")
            appendLine("  \"key_assumption\": the most important underlying assumption")
            appendLine("Output ONLY the JSON object.")
        }

        val raw = callModelExpectingJson(prompt, MAX_TOKENS_LARGE)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val keyAssumption = structured["key_assumption"] ?: "No key assumption identified"
        val selectedIndex = structured["selected_hypothesis"]?.toIntOrNull() ?: 0
        val selectionReason = structured["selection_reason"] ?: "Default selection"

        // Write predictions to memory
        val predNodeId = "predictions_${System.currentTimeMillis()}"
        SemanticMemory.addNode(
            id = predNodeId,
            label = "Simulated predictions for: ${query.take(30)}",
            content = "Selected hypothesis $selectedIndex: $selectionReason. Key assumption: $keyAssumption",
            type = "prediction",
            importance = 0.7f,
            confidence = 0.6f
        )
        SemanticMemory.activateNode(predNodeId, 0.7f)

        // Write the selected hypothesis as a belief
        val hypNodeId = "sim_hypothesis_${System.currentTimeMillis()}"
        SemanticMemory.addNode(
            id = hypNodeId,
            label = "Simulated hypothesis: ${query.take(30)}",
            content = "Selected via simulation: $selectionReason",
            type = "hypothesis",
            importance = 0.7f,
            confidence = 0.6f
        )

        AppLog.logStructured("INFO", "SIMULATE", 0,
            "Simulated 2-3 hypotheses, selected $selectedIndex",
            mapOf("reason" to selectionReason.take(60), "assumption" to keyAssumption.take(60)))

        return OperatorResult(
            operator = "PREDICT",
            output = "Simulated hypotheses. Selected: $selectionReason. Assumption: $keyAssumption",
            structured = structured,
            confidence = 0.6f,
            surprise = 0.3f
        )
    }

    /**
     * HYPOTHESIZE — combine solved chunks into a testable hypothesis.
     * This is the "What if we combine what we know?" step.
     * After solving individual chunks, this operator synthesizes them
     * into a coherent hypothesis that can be verified.
     */
    private suspend fun runHypothesize(query: String): OperatorResult {
        val solvedSummary = solvedChunks.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
        val beliefs = SemanticMemory.getAllActive()
            .filter { it.nodeType in setOf("fact", "principle", "analogy") }
            .take(5)
        val beliefSummary = beliefs.joinToString("\n") { "- ${it.label}: ${it.content.take(100)}" }

        val prompt = buildString {
            appendLine("You are MESA. You have solved several sub-problems. Now combine them into a testable hypothesis.")
            appendLine()
            appendLine("ORIGINAL QUESTION: $query")
            appendLine()
            appendLine("SOLVED SUB-PROBLEMS:")
            appendLine(solvedSummary)
            appendLine()
            appendLine("ACCUMULATED BELIEFS:")
            appendLine(beliefSummary)
            appendLine()
            appendLine("Task: produce a JSON object with exactly these fields:")
            appendLine("  \"hypothesis\": a single, clear, testable statement that combines the solved sub-problems")
            appendLine("  \"predicted_consequences\": 1-2 specific predictions that would be true if the hypothesis is correct")
            appendLine("  \"potential_counterexamples\": 1-2 things that would disprove the hypothesis")
            appendLine("  \"confidence\": 0.0 to 1.0")
            appendLine("  \"key_insight\": the single most important takeaway (1 sentence)")
            appendLine("Output ONLY the JSON object.")
        }

        val raw = callModelExpectingJson(prompt, MAX_TOKENS_LARGE)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val hypothesis = structured["hypothesis"] ?: "Combined insight from ${solvedChunks.size} solved sub-problems."
        val consequences = structured["predicted_consequences"] ?: ""
        val counterexamples = structured["potential_counterexamples"] ?: ""
        val conf = structured["confidence"]?.toFloatOrNull() ?: 0.6f

        // Write hypothesis to SemanticMemory
        val hypNodeId = "hypothesis_${System.currentTimeMillis()}"
        val hypNode = SemanticMemory.addNode(
            id = hypNodeId,
            label = "Hypothesis: ${hypothesis.take(40)}",
            content = hypothesis,
            type = "hypothesis",
            importance = 0.8f,
            confidence = conf
        )
        WorkingMemory.add(hypNode)
        SemanticMemory.activateNode(hypNodeId, conf + 0.1f)  // hypotheses get a boost

        // Write predicted consequences as testable beliefs
        if (consequences.isNotBlank()) {
            val consNodeId = "prediction_${System.currentTimeMillis()}"
            SemanticMemory.addNode(
                id = consNodeId,
                label = "Prediction: ${consequences.take(40)}",
                content = "If hypothesis is correct: $consequences",
                type = "prediction",
                importance = 0.7f,
                confidence = conf * 0.8f
            )
        }

        AppLog.logStructured("INFO", "HYPOTHESIZE", 0,
            "Hypothesis formed from ${solvedChunks.size} solved chunks",
            mapOf("confidence" to "%.2f".format(conf), "hypothesis" to hypothesis.take(80)))

        return OperatorResult(
            operator = "HYPOTHESIZE",
            output = "Hypothesis: $hypothesis",
            structured = structured,
            confidence = conf,
            surprise = 0.3f
        )
    }

    /**
     * ABSTRACT — extract reusable abstractions from multiple sessions.
     * This is the concept formation engine: after solving several problems,
     * discover the pattern that connects them.
     *
     * Example:
     *   Session 1: How neurons work → decompose into components → simulate
     *   Session 2: How CPUs work → decompose into components → simulate
     *   Session 3: How ant colonies work → decompose into components → simulate
     *   Abstraction: "Many small units with local interactions produce global behavior"
     *
     * Research: Schema learning (Springer 2025), Discovery Engine (arXiv 2025)
     */
    private suspend fun runAbstraction(query: String): OperatorResult {
        // Gather recent session traces
        val recentTraces = EpisodicMemory.all()
            .filter { it.operator == "SESSION" && it.success }
            .takeLast(5)

        if (recentTraces.size < 2) {
            return OperatorResult(
                operator = "ABSTRACT",
                output = "Not enough sessions for abstraction (need 2+, have ${recentTraces.size}).",
                confidence = 0.3f, surprise = 0.1f
            )
        }

        val traceSummary = recentTraces.joinToString("\n\n") { trace ->
            "Problem: ${trace.goal.take(80)}\nPath: ${trace.output.take(120)}\nConfidence: ${"%.2f".format(trace.finalConfidence)}"
        }

        // Check existing abstractions to avoid duplicates
        val existingAbstractions = SemanticMemory.getAllActive()
            .filter { it.nodeType == "abstraction" }
            .map { it.content.take(50).lowercase() }
            .toSet()

        val prompt = buildString {
            appendLine("You are a scientist looking for deep patterns across multiple solved problems.")
            appendLine()
            appendLine("RECENT SESSIONS:")
            appendLine(traceSummary)
            appendLine()
            appendLine("EXISTING ABSTRACTIONS (do not repeat these):")
            existingAbstractions.forEach { appendLine("- $it") }
            if (existingAbstractions.isEmpty()) appendLine("(none yet)")
            appendLine()
            appendLine("Task: Find ONE reusable abstraction that captures what these sessions have in common.")
            appendLine("The abstraction should be:")
            appendLine("- General enough to apply to future problems")
            appendLine("- Specific enough to guide reasoning")
            appendLine("- Novel (not just restating the problem)")
            appendLine()
            appendLine("produce a JSON object with exactly these fields:")
            appendLine("  \"abstraction\": the reusable pattern (1-2 sentences)")
            appendLine("  \"level\": \"specific\" | \"intermediate\" | \"abstract\"")
            appendLine("  \"applicability\": when this abstraction applies (1 sentence)")
            appendLine("  \"reasoning_strategy\": how to use this abstraction (1-2 sentences)")
            appendLine("  \"confidence\": 0.0 to 1.0")
            appendLine("Output ONLY the JSON object.")
        }

        val raw = callModelExpectingJson(prompt, MAX_TOKENS_LARGE)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val abstraction = structured["abstraction"] ?: return OperatorResult(
            operator = "ABSTRACT",
            output = "No abstraction found.",
            confidence = 0.3f, surprise = 0.1f
        )
        if (abstraction.isBlank()) return OperatorResult(
            operator = "ABSTRACT",
            output = "No abstraction found.",
            confidence = 0.3f, surprise = 0.1f
        )

        val level = structured["level"] ?: "intermediate"
        val applicability = structured["applicability"] ?: ""
        val strategy = structured["reasoning_strategy"] ?: ""
        val conf = structured["confidence"]?.toFloatOrNull() ?: 0.6f

        // Store abstraction as a highly-valued belief node
        val absNodeId = "abstraction_${System.currentTimeMillis()}"
        val absNode = SemanticMemory.addNode(
            id = absNodeId,
            label = "Abstraction ($level): ${abstraction.take(40)}",
            content = abstraction,
            type = "abstraction",
            importance = 0.95f,  // abstractions are highly valuable
            confidence = conf
        )
        SemanticMemory.activateNode(absNodeId, 0.9f)

        // Link abstraction to the sessions that generated it
        recentTraces.forEach { trace ->
            SemanticMemory.addEdge(absNodeId, "n_root", "DERIVED_FROM", 0.5f)
        }

        // Store the reasoning strategy as a procedural skill
        if (strategy.isNotBlank()) {
            ProceduralMemory.addSkill(ProceduralSkill(
                id = "abs_skill_${System.currentTimeMillis()}",
                name = "Abstract: ${abstraction.take(30)}",
                condition = applicability,
                steps = strategy.split(Regex("[.;]")).filter { it.isNotBlank() }.map { it.trim() }
            ))
        }

        AppLog.logStructured("INFO", "ABSTRACT", 0,
            "New abstraction ($level): ${abstraction.take(60)}",
            mapOf("applicability" to applicability.take(40), "confidence" to "%.2f".format(conf)))

        return OperatorResult(
            operator = "ABSTRACT",
            output = "Abstraction ($level): $abstraction. Strategy: $strategy",
            structured = structured,
            confidence = conf,
            surprise = 0.4f
        )
    }

    /**
     * SELF_EVALUATE — objectively score the reasoning session on 5 dimensions.
     * This is the "Did I actually get better?" check.
     * Without this, the StrategyArchive fills with noise because the engine
     * can't distinguish genuinely good sessions from confidently wrong ones.
     *
     * Research: LLM-as-judge (Evidently 2025), Process Reward Models (arXiv 2025)
     */
    private suspend fun runSelfEvaluate(query: String): OperatorResult {
        val solvedSummary = solvedChunks.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
        val traceSummary = reasoningTrace.takeLast(10).joinToString("\n")
        val beliefs = SemanticMemory.getAllActive()
            .filter { it.nodeType in setOf("fact", "hypothesis", "principle", "verification") }
            .take(5)
        val beliefSummary = beliefs.joinToString("\n") { "- ${it.label}: ${it.content.take(80)} (conf=${"%.2f".format(it.confidence)})" }

        val prompt = buildString {
            appendLine("You are an independent evaluator. Score this reasoning session on 5 dimensions (0-10 each).")
            appendLine()
            appendLine("QUESTION: $query")
            appendLine()
            appendLine("REASONING TRACE:")
            appendLine(traceSummary)
            appendLine()
            appendLine("SOLVED CHUNKS:")
            appendLine(solvedSummary)
            appendLine()
            appendLine("BELIEFS FORMED:")
            appendLine(beliefSummary)
            appendLine()
            appendLine("Task: produce a JSON object with exactly these fields:")
            appendLine("  \"correctness\": 0-10 (is the final answer factually accurate?)")
            appendLine("  \"completeness\": 0-10 (does it address all aspects of the question?)")
            appendLine("  \"consistency\": 0-10 (are there contradictions in the reasoning?)")
            appendLine("  \"novelty\": 0-10 (did the reasoning discover non-obvious insights?)")
            appendLine("  \"efficiency\": 0-10 (was the reasoning path efficient?)")
            appendLine("  \"overall\": 0-10 (weighted average)")
            appendLine("  \"strengths\": one specific strength (1 sentence)")
            appendLine("  \"weaknesses\": one specific weakness (1 sentence)")
            appendLine("Output ONLY the JSON object.")
        }

        val raw = callModelExpectingJson(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val correctness = structured["correctness"]?.toFloatOrNull() ?: 5f
        val completeness = structured["completeness"]?.toFloatOrNull() ?: 5f
        val consistency = structured["consistency"]?.toFloatOrNull() ?: 5f
        val novelty = structured["novelty"]?.toFloatOrNull() ?: 5f
        val efficiency = structured["efficiency"]?.toFloatOrNull() ?: 5f
        val overall = structured["overall"]?.toFloatOrNull() ?: (correctness + completeness + consistency + novelty + efficiency) / 5f
        val strengths = structured["strengths"] ?: "Not specified"
        val weaknesses = structured["weaknesses"] ?: "Not specified"

        // Store evaluation as a belief node
        val evalNodeId = "evaluation_${System.currentTimeMillis()}"
        SemanticMemory.addNode(
            id = evalNodeId,
            label = "Self-eval: ${"%.1f".format(overall)}/10",
            content = "C=${"%.0f".format(correctness)} Co=${"%.0f".format(completeness)} " +
                "Con=${"%.0f".format(consistency)} N=${"%.0f".format(novelty)} E=${"%.0f".format(efficiency)}. " +
                "Strength: $strengths. Weakness: $weaknesses",
            type = "evaluation",
            importance = 0.9f,
            confidence = overall / 10f
        )

        // Compare with past evaluations to detect improvement
        val pastEvals = SemanticMemory.getAllActive()
            .filter { it.nodeType == "evaluation" && it.id != evalNodeId }
            .sortedByDescending { it.confidence }
        val avgPast = if (pastEvals.isNotEmpty()) pastEvals.map { it.confidence }.average().toFloat() else 0.5f
        val improvement = (overall / 10f) - avgPast

        AppLog.logStructured("INFO", "SELF-EVAL", 0,
            "Self-evaluation: ${"%.1f".format(overall)}/10 (delta: ${"%+.1f".format(improvement * 10)})",
            mapOf(
                "correctness" to "%.0f".format(correctness),
                "completeness" to "%.0f".format(completeness),
                "consistency" to "%.0f".format(consistency),
                "novelty" to "%.0f".format(novelty),
                "efficiency" to "%.0f".format(efficiency),
                "strengths" to strengths.take(40),
                "weaknesses" to weaknesses.take(40)
            ))

        return OperatorResult(
            operator = "SELF_EVALUATE",
            output = "Score: ${"%.1f".format(overall)}/10. Strength: $strengths. Weakness: $weaknesses",
            structured = structured + mapOf(
                "overall_score" to overall.toString(),
                "improvement" to improvement.toString()
            ),
            confidence = overall / 10f,
            surprise = if (kotlin.math.abs(improvement) > 0.1f) 0.5f else 0.1f
        )
    }

    /**
     * REPAIR — fix a belief that was found to be inconsistent or incorrect.
     * When simulation or verification reveals a mismatch, this operator
     * generates a corrected version of the belief.
     */
    private suspend fun runRepair(query: String, brokenBelief: SemanticNode): OperatorResult {
        val prompt = buildString {
            appendLine("You are MESA. A belief was found to be inconsistent or incorrect.")
            appendLine()
            appendLine("QUESTION: $query")
            appendLine()
            appendLine("BROKEN BELIEF:")
            appendLine("  Label: ${brokenBelief.label}")
            appendLine("  Content: ${brokenBelief.content}")
            appendLine("  Confidence: ${brokenBelief.confidence}")
            appendLine()
            appendLine("Task: produce a JSON object with exactly these fields:")
            appendLine("  \"corrected_belief\": the fixed version of this belief (1-2 sentences)")
            appendLine("  \"what_was_wrong\": what specifically was incorrect")
            appendLine("  \"new_confidence\": 0.0 to 1.0")
            appendLine("Output ONLY the JSON object.")
        }

        val raw = callModelExpectingJson(prompt, MAX_TOKENS_SMALL)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val corrected = structured["corrected_belief"] ?: brokenBelief.content
        val whatWasWrong = structured["what_was_wrong"] ?: "unknown"
        val newConf = structured["new_confidence"]?.toFloatOrNull() ?: (brokenBelief.confidence * 0.7f)

        // Reconsolidate the broken belief with the correction
        SemanticMemory.reconsolidate(brokenBelief.id, corrected, -0.1f)
        brokenBelief.confidence = newConf
        brokenBelief.activation *= 0.8f  // reduce activation of repaired belief

        // Write the repair to memory
        val repairNodeId = "repair_${System.currentTimeMillis()}"
        SemanticMemory.addNode(
            id = repairNodeId,
            label = "Repair: ${whatWasWrong.take(30)}",
            content = "Corrected '${brokenBelief.label.take(30)}': $corrected",
            type = "repair",
            importance = 0.6f,
            confidence = newConf
        )

        AppLog.logStructured("INFO", "REPAIR", 0,
            "Repaired belief: ${brokenBelief.label.take(40)}",
            mapOf("what_was_wrong" to whatWasWrong.take(60), "new_confidence" to "%.2f".format(newConf)))

        return OperatorResult(
            operator = "REPAIR",
            output = "Repaired '${brokenBelief.label.take(30)}': $corrected",
            structured = structured,
            confidence = newConf,
            surprise = 0.4f
        )
    }

    private fun consolidateSkills() {
        val successfulTraces = EpisodicMemory.all().filter { it.success }
        if (successfulTraces.size >= 3) {
            val best = successfulTraces.maxByOrNull { it.surprise } ?: return
            ProceduralMemory.extractSkillFromTrace(best)

            // Register the extracted skill into the shared strategy archive (blueprint 5.4).
            // This makes Cognitive-discovered strategies available to the Refiner too.
            val skillName = "skill_${best.operator}_${System.currentTimeMillis()}"
            val goalWords = best.goal.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
            UnifiedStrategyArchive.register(
                StrategyArm(
                    id = "cognitive_$skillName",
                    source = "cognitive",
                    description = "Extracted skill for ${best.goal.take(30)}",
                    tags = goalWords + setOf(best.operator.lowercase())
                )
            )
        }
    }

    /**
     * Consolidation with LLM (blueprint Part 4.5): replays high-surprise episodic
     * traces through an LLM call to extract a generalizable procedural skill, rather
     * than the crude "skill = operator name + literal goal text" that extractSkillFromTrace
     * currently produces. This closes the Complementary Learning Systems loop: episodic
     * experience → semantic generalization.
     */
    private suspend fun consolidateWithLLM() {
        val traces = EpisodicMemory.replayHighSurprise(3).filter { it.success }
        if (traces.size < 2) return

        val traceSummary = traces.joinToString("\n") { t ->
            "Operator: ${t.operator} | Goal: ${t.goal.take(60)} | Output: ${t.output.take(80)} | Surprise: ${"%.2f".format(t.surprise)}"
        }

        val prompt = buildString {
            appendLine("You are MESA. Analyze the following successful reasoning traces and extract a GENERALIZABLE procedural skill.")
            appendLine("The skill should describe WHEN to apply it (the pattern/condition) and WHAT steps to follow.")
            appendLine()
            appendLine("SUCCESSFUL TRACES:")
            appendLine(traceSummary)
            appendLine()
            appendLine("Task: produce a JSON object with exactly these fields:")
            appendLine("  \"skill_name\": a short descriptive name (3-6 words)")
            appendLine("  \"condition\": when this skill should be applied (the general pattern, not the specific goal)")
            appendLine("  \"steps\": a JSON array of 2-4 step strings, each describing a general action")
            appendLine("  \"domain_hint\": what domain this skill is most useful in")
            appendLine("Output ONLY the JSON object.")
        }

        val raw = callModelExpectingJson(prompt, 180)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val name = structured["skill_name"] ?: "generalized_skill_${System.currentTimeMillis()}"
        val condition = structured["condition"] ?: traces.first().goal.take(80)
        val steps = structured["steps"]?.let { stepsStr ->
            // Try to parse as JSON array, fall back to splitting by commas
            ReasoningOperators.parseJsonArray(stepsStr).let { arr ->
                if (arr.isNotEmpty()) arr.map { it["step"] ?: it["text"] ?: it.values.firstOrNull() ?: "unknown step" }
                else stepsStr.split(",").map { it.trim().removeSurrounding("\"") }
            }
        } ?: listOf(traces.first().operator)

        val skill = ProceduralSkill(
            id = "skill_llm_${System.currentTimeMillis()}",
            name = name,
            condition = condition,
            steps = steps
        )
        ProceduralMemory.addSkill(skill)

        // Register into unified archive
        val goalWords = condition.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        UnifiedStrategyArchive.register(
            StrategyArm(
                id = "cognitive_${skill.id}",
                source = "cognitive",
                description = "LLM-extracted: $name",
                tags = goalWords + setOf("consolidated")
            )
        )

        AppLog.logStructured("INFO", "CONSOLIDATION", SemanticMemory.getCurrentIter(),
            "LLM consolidation produced skill", mapOf("name" to name, "steps" to steps.size.toString()))
    }
}

/**
 * Lightweight belief audit result (SAVeR-inspired).
 * Tracks faithfulness violations detected in operator output.
 */
data class BeliefAudit(
    val hasIssues: Boolean = false,
    val issues: List<String> = emptyList()
)

/**
 * Tracks the outcome of a single operator invocation for meta-learning.
 * Stored in UnifiedStrategyArchive so the engine learns which operators
 * work best for which problem types over repeated sessions.
 */
data class OperatorOutcome(
    val operator: String,
    val problemType: String,
    val confidence: Float,
    val surprise: Float,
    val success: Boolean,
    val energyCost: Float,
    val timestamp: Long = System.currentTimeMillis(),
    // Causal credit assignment: track confidence before and after this operator
    val confidenceBefore: Float = 0f,  // confidence of beliefs before this operator
    val confidenceAfter: Float = 0f,   // confidence of beliefs after this operator
    val contribution: Float = 0f       // delta = after - before (positive = improvement)
)

data class CognitiveResult(
    val finalAnswer: String,
    val trace: List<String>,
    val confidence: Float,
    val memorySnapshot: List<SemanticNode>,
    val structuredAnswer: Map<String, String> = emptyMap()
)