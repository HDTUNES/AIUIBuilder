package com.arena.aiuibuilder

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * CognitiveEngine — human-brain-like reasoning orchestrator with bounded working memory.
 *
 * Key design invariants:
 *   1. The LLM always sees a prompt under ~1000 tokens, no matter how long the session runs.
 *   2. Long-term memory lives on disk and is retrieved only when relevant.
 *   3. Memories fade by interference (new memories weaken old ones), not wall-clock time.
 *   4. Repeated use strengthens a memory, just like neural reinforcement.
 *   5. High-value insights are externalized to disk when working memory is near capacity.
 */

class CognitiveEngine(
    private val context: Context,
    private val callModel: suspend (prompt: String, maxTokens: Int) -> String
) {
    private var goalStack = ArrayDeque<String>()
    private val solvedChunks = mutableMapOf<String, String>()
    private val pendingChunks = mutableListOf<String>()
    private val reasoningTrace = mutableListOf<String>()
    private var currentDomain = "structural"

    private val MAX_TOKENS_SMALL = 180
    private val MAX_TOKENS_MEDIUM = 320
    private val MAX_TOKENS_LARGE = 480

    suspend fun reason(query: String): CognitiveResult = withContext(Dispatchers.IO) {
        SemanticMemory.initSession(context, query)
        ExternalMemory.load(context)
        WorkingMemory.load(SemanticMemory.retrieveRelevant(query, 5))
        ProceduralMemory.initDefaults()
        EpisodicMemory.record(query, "START", "", "", 0f, false)
        MetacognitiveMonitor.reset()

        goalStack.clear()
        goalStack.addLast(query)
        solvedChunks.clear()
        pendingChunks.clear()
        reasoningTrace.clear()

        var operator = "ORIENT"
        var lastResult = OperatorResult(operator, "")
        var iterations = 0

        while (iterations < 20) {
            iterations += 1
            val goal = goalStack.lastOrNull() ?: query

            // Memory-management phase: save notes if needed, retrieve disk notes if needed.
            val memoryLoad = WorkingMemory.loadFactor()
            val retrievedCount = SemanticMemory.getAllActive().size
            if (MetacognitiveMonitor.shouldExternalize(memoryLoad, lastResult.confidence, lastResult.surprise)) {
                ExternalMemory.writeNote(
                    context,
                    topic = goal.take(40),
                    summary = lastResult.output.take(200),
                    confidence = lastResult.confidence,
                    links = lastResult.subgoals
                )
                WorkingMemory.load(SemanticMemory.retrieveRelevant(goal, 5))
            }
            if (MetacognitiveMonitor.shouldRetrieveDiskNotes(goal, retrievedCount, ExternalMemory.allNotes().isNotEmpty())) {
                val notes = ExternalMemory.retrieveRelevant(goal, 3)
                notes.forEach { note ->
                    SemanticMemory.addNode("ext_${note.id}", note.topic, note.summary, "external_note", confidence = note.confidence)
                }
                WorkingMemory.load(SemanticMemory.retrieveRelevant(goal, 5))
            }

            lastResult = when (operator) {
                "ORIENT" -> runOrient(goal)
                "DECOMPOSE" -> runDecompose(goal)
                "FIRST_PRINCIPLES" -> runFirstPrinciples(goal)
                "ANALOGIZE" -> runAnalogize(goal)
                "SOLVE_CHUNK" -> runSolveChunk(goal)
                "VERIFY" -> runVerify(goal)
                "EXECUTE" -> runExecute(goal)
                "INTEGRATE" -> runIntegrate(query)
                "REFLECT" -> runReflect(goal)
                "SAVE_NOTE" -> {
                    ExternalMemory.writeNote(context, goal.take(40), lastResult.output.take(200), lastResult.confidence, lastResult.subgoals)
                    OperatorResult("SAVE_NOTE", "Externalized note to disk.", confidence = 0.9f, surprise = 0.0f)
                }
                "RETRIEVE_NOTE" -> {
                    val notes = ExternalMemory.retrieveRelevant(goal, 3)
                    notes.forEach { note ->
                        SemanticMemory.addNode("ext_${note.id}", note.topic, note.summary, "external_note", confidence = note.confidence)
                    }
                    WorkingMemory.load(SemanticMemory.retrieveRelevant(goal, 5))
                    OperatorResult("RETRIEVE_NOTE", "Retrieved ${notes.size} notes from disk.", confidence = 0.8f, surprise = 0.2f)
                }
                else -> runOrient(goal)
            }

            reasoningTrace.add("[${iterations}] $operator -> ${lastResult.output.take(80)}")
            EpisodicMemory.record(goal, operator, "", lastResult.output, lastResult.surprise, lastResult.confidence > 0.7f)

            // Update long-term memory and working memory with the new thought.
            if (operator in setOf("ORIENT", "SOLVE_CHUNK", "FIRST_PRINCIPLES", "ANALOGIZE", "VERIFY", "EXECUTE")) {
                val nodeId = "n_${System.currentTimeMillis()}_$iterations"
                val node = SemanticMemory.addNode(nodeId, "${operator} result", lastResult.output, "claim")
                WorkingMemory.add(node)
            }

            // Metacognitive decision.
            val signal = MetacognitiveMonitor.decideNext(
                goalStackDepth = goalStack.size,
                lastOperator = operator,
                lastOutput = lastResult.output,
                lastSurprise = lastResult.surprise,
                confidence = lastResult.confidence,
                chunkCount = pendingChunks.size + solvedChunks.size,
                solvedChunks = solvedChunks.size
            )

            operator = mapSignalToOperator(signal, lastResult)

            if (signal == StrategySignal.STOP || operator == "INTEGRATE") {
                if (operator == "INTEGRATE") {
                    lastResult = runIntegrate(query)
                }
                break
            }
        }

        SemanticMemory.save(context)
        ExternalMemory.save(context)
        consolidateSkills()

        CognitiveResult(
            finalAnswer = lastResult.output,
            trace = reasoningTrace,
            confidence = lastResult.confidence,
            memorySnapshot = SemanticMemory.getAllActive().take(5)
        )
    }

    private fun mapSignalToOperator(signal: StrategySignal, lastResult: OperatorResult): String {
        return when (signal) {
            StrategySignal.CONTINUE -> lastResult.structured["next_operator"] ?: "SOLVE_CHUNK"
            StrategySignal.DECOMPOSE -> "DECOMPOSE"
            StrategySignal.FIRST_PRINCIPLES -> "FIRST_PRINCIPLES"
            StrategySignal.ANALOGIZE -> "ANALOGIZE"
            StrategySignal.VERIFY -> "VERIFY"
            StrategySignal.REFLECT -> "REFLECT"
            StrategySignal.SAVE_NOTE -> "SAVE_NOTE"
            StrategySignal.RETRIEVE_NOTE -> "RETRIEVE_NOTE"
            StrategySignal.INTEGRATE -> "INTEGRATE"
            StrategySignal.STOP -> "STOP"
        }
    }

    // Build a tiny prompt using only working memory + current goal.
    private fun buildPrompt(goal: String, operatorPrompt: String): String {
        return """
            |Current goal: $goal
            |
            |Active working memory (only relevant items):
            |${WorkingMemory.toPromptString()}
            |
            |$operatorPrompt
        """.trimMargin()
    }

    private suspend fun runOrient(goal: String): OperatorResult {
        val prompt = buildPrompt(goal, ReasoningOperators.buildOrientPrompt(goal, WorkingMemory.toPromptString()))
        val raw = callModel(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val topic = structured["topic"] ?: goal.take(40)
        val confusion = structured["confusion_level"] ?: "medium"
        val nextOp = structured["next_operator"] ?: "DECOMPOSE"
        val surprise = when (confusion) { "high" -> 0.6f; "medium" -> 0.3f; else -> 0.1f }

        return OperatorResult(
            operator = "ORIENT",
            output = "Topic: $topic. Confusion: $confusion. Next: $nextOp",
            structured = structured,
            confidence = 0.8f,
            surprise = surprise
        )
    }

    private suspend fun runDecompose(goal: String): OperatorResult {
        val orient = OperatorResult("ORIENT", "", mapOf("topic" to goal, "unknowns" to ""))
        val prompt = buildPrompt(goal, ReasoningOperators.buildDecomposePrompt(goal, orient))
        val raw = callModel(prompt, MAX_TOKENS_LARGE)
        val chunks = ReasoningOperators.parseJsonArray(ReasoningOperators.extractJson(raw))

        pendingChunks.clear()
        chunks.forEach { chunk ->
            chunk["question"]?.let { pendingChunks.add(it) }
        }

        return OperatorResult(
            operator = "DECOMPOSE",
            output = "Decomposed into ${pendingChunks.size} chunks: ${pendingChunks.joinToString("; ")}",
            structured = mapOf("chunk_count" to pendingChunks.size.toString()),
            confidence = 0.75f,
            surprise = 0.2f,
            subgoals = pendingChunks.toList()
        )
    }

    private suspend fun runFirstPrinciples(goal: String): OperatorResult {
        val prompt = buildPrompt(goal, ReasoningOperators.buildFirstPrinciplesPrompt(goal))
        val raw = callModel(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val nodeId = "fp_${System.currentTimeMillis()}"
        val content = "${structured["base_problem"]} → ${structured["causal_chain"]} → ${structured["core_principle"]}"
        val node = SemanticMemory.addNode(nodeId, "First-principles chain", content, "principle")
        SemanticMemory.addEdge("n_root", nodeId, "DEPENDS_ON")
        WorkingMemory.add(node)

        return OperatorResult(
            operator = "FIRST_PRINCIPLES",
            output = "Base problem: ${structured["base_problem"]}. Core principle: ${structured["core_principle"]}. Rebuild: ${structured["rebuild_step"]}",
            structured = structured,
            confidence = 0.7f,
            surprise = 0.4f
        )
    }

    private suspend fun runAnalogize(goal: String): OperatorResult {
        val domains = listOf("biological", "physical", "computational", "economic", "structural").filter { it != currentDomain }
        val target = domains.random()
        val prompt = buildPrompt(goal, ReasoningOperators.buildAnalogizePrompt(goal, currentDomain, target))
        val raw = callModel(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        currentDomain = target
        val output = "Analogy: ${structured["source_concept"]} ↔ ${structured["target_concept"]}. Insight: ${structured["insight"]}. Limit: ${structured["limit"]}"

        return OperatorResult(
            operator = "ANALOGIZE",
            output = output,
            structured = structured,
            confidence = 0.65f,
            surprise = 0.5f
        )
    }

    private suspend fun runSolveChunk(goal: String): OperatorResult {
        val chunk = pendingChunks.removeFirstOrNull() ?: goal
        val prior = solvedChunks.entries.joinToString("\n") { "${it.key}: ${it.value}" }
        val prompt = buildPrompt(chunk, ReasoningOperators.buildSolveChunkPrompt(chunk, prior, WorkingMemory.toPromptString()))
        val raw = callModel(prompt, MAX_TOKENS_MEDIUM)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val answer = structured["answer"] ?: raw.take(200)
        solvedChunks[chunk] = answer

        val confidence = when (structured["confidence"]) {
            "high" -> 0.9f; "medium" -> 0.7f; "low" -> 0.5f; else -> 0.7f
        }

        return OperatorResult(
            operator = "SOLVE_CHUNK",
            output = answer,
            structured = structured,
            confidence = confidence,
            surprise = if (structured["needs_code_test"] == "true") 0.4f else 0.15f
        )
    }

    private suspend fun runVerify(claim: String): OperatorResult {
        val evidence = WebSearchClient.search(claim, 2).let { WebSearchClient.formatGrounding(it) }
        val prompt = buildPrompt(claim, ReasoningOperators.buildVerifyPrompt(claim, evidence))
        val raw = callModel(prompt, MAX_TOKENS_SMALL)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val verdict = structured["verdict"] ?: "UNCERTAIN"
        val confidence = structured["confidence"]?.toFloatOrNull() ?: 0.6f

        return OperatorResult(
            operator = "VERIFY",
            output = "Verdict: $verdict. ${structured["objection"] ?: ""}",
            structured = structured,
            confidence = confidence,
            surprise = if (verdict == "SUPPORTED") 0.1f else 0.5f
        )
    }

    private suspend fun runExecute(claim: String): OperatorResult {
        val prompt = buildPrompt(claim, ReasoningOperators.buildExecutePrompt(claim))
        val code = callModel(prompt, MAX_TOKENS_MEDIUM)
        val result = CodeExecutionEngine.executeJavaScript(context, ReasoningOperators.wrapTestCode(code))

        val supported = result.success && (result.output.contains("TRUE") || result.output.contains("true"))
        val confidence = if (result.success) 0.9f else 0.4f

        return OperatorResult(
            operator = "EXECUTE",
            output = "Code execution: ${result.output}. Error: ${result.error ?: "none"}",
            structured = mapOf("raw_code" to code, "exec_output" to result.output),
            confidence = confidence,
            surprise = if (supported) 0.1f else 0.6f
        )
    }

    private suspend fun runReflect(goal: String): OperatorResult {
        val history = reasoningTrace.takeLast(5).joinToString("\n")
        val prompt = buildPrompt(goal, ReasoningOperators.buildReflectPrompt(goal, history))
        val raw = callModel(prompt, MAX_TOKENS_SMALL)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        return OperatorResult(
            operator = "REFLECT",
            output = "Diagnosis: ${structured["diagnosis"]}. New angle: ${structured["new_angle"]}",
            structured = structured,
            confidence = 0.6f,
            surprise = 0.5f
        )
    }

    private suspend fun runIntegrate(query: String): OperatorResult {
        val chunks = solvedChunks.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
        val prompt = buildPrompt(query, ReasoningOperators.buildIntegratePrompt(query, chunks, query))
        val raw = callModel(prompt, MAX_TOKENS_LARGE)
        val structured = ReasoningOperators.parseJsonObject(ReasoningOperators.extractJson(raw))

        val confidence = structured["confidence"]?.toFloatOrNull() ?: 0.75f

        return OperatorResult(
            operator = "INTEGRATE",
            output = structured["answer"] ?: raw,
            structured = structured,
            confidence = confidence,
            surprise = 0.0f
        )
    }

    private fun consolidateSkills() {
        val successfulTraces = EpisodicMemory.all().filter { it.success }
        if (successfulTraces.size >= 3) {
            val best = successfulTraces.maxByOrNull { it.surprise } ?: return
            ProceduralMemory.extractSkillFromTrace(best)
        }
    }
}

data class CognitiveResult(
    val finalAnswer: String,
    val trace: List<String>,
    val confidence: Float,
    val memorySnapshot: List<SemanticNode>
)
