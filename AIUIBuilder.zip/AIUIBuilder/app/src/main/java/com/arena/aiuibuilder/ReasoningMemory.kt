package com.arena.aiuibuilder

data class ReasoningMemoryEntry(val operator:String, val premise:String, val output:String, val deltaConf:Float, val why:String, val ts:Long=System.currentTimeMillis())
object ReasoningMemory {
  private val ring = ArrayDeque<ReasoningMemoryEntry>(64)
  @Synchronized fun record(e:ReasoningMemoryEntry){ if(ring.size>=64) ring.removeFirst(); ring.addLast(e) }
  @Synchronized fun snapshot():List<ReasoningMemoryEntry> = ring.toList()
  @Synchronized fun clear(){ ring.clear() }
}
