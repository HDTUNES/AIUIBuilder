package com.arena.aiuibuilder

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import kotlin.math.ln
import kotlin.math.pow

// =============================================================================
// SOTA COGNITIVE OPERATING SYSTEM PRIMITIVES
// Tripartite Separation: Knowledge (Beliefs), Attention (Activation), Objectives (Goals)
// =============================================================================

@Serializable
data class BeliefNode(
    val id: String,
    val claim: String,
    var importance: Float = 0.85f,
    var confidence: Float = 0.90f, // Step 5: Continuous confidence tracking
    val createdIter: Int = 1,
    var lastTouchIter: Int = 1,
    var touchCount: Int = 1,
    var status: String = "ACTIVE" // ACTIVE, ARCHIVED_EVIDENCE, CONSOLIDATED
)

@Serializable
data class BeliefEdge(
    val sourceId: String,
    val targetId: String,
    val relation: String // SUPPORTS, CONTRADICTS, DEPENDS_ON, EVIDENCE_CHILD
)

@Serializable
data class GoalNode(
    val goalId: String,
    val title: String,
    var status: String = "EXPLORING", // EXPLORING, RESOLVED, STUCK
    var settledFactsAddedInWindow: Int = 0, // Step 1 & 6: Branch convergence pacing
    val openQuestions: MutableList<String> = mutableListOf()
)

@Serializable
data class CognitiveStateSnapshot(
    val step: Int = 0,
    val activeGoal: GoalNode = GoalNode("root", "Master Objective"),
    val nodes: Map<String, BeliefNode> = emptyMap(),
    val edges: List<BeliefEdge> = emptyList()
)

object CognitiveOsMemory {
    private val json = Json { ignoreUnknownKeys = false; prettyPrint = true }
    private const val STORE_FILE = "cognitive_os_blackboard.json"

    private var currentStep: Int = 0
    private var rootGoal = GoalNode("g1", "Universal Objective Exploration", openQuestions = mutableListOf("What is the optimal structural architecture?"))
    private val activeNodes = mutableMapOf<String, BeliefNode>()
    private val beliefEdges = mutableListOf<BeliefEdge>()

    fun loadSnapshot(context: Context): Boolean {
        val f = File(context.filesDir, STORE_FILE)
        if (!f.exists() || !f.canRead()) return false
        return runCatching {
            val snap = json.decodeFromString<CognitiveStateSnapshot>(f.readText())
            currentStep = snap.step
            rootGoal = snap.activeGoal
            activeNodes.clear()
            activeNodes.putAll(snap.nodes)
            beliefEdges.clear()
            beliefEdges.addAll(snap.edges)
            AppLog.append("CognitiveOs: Loaded persistent disk snapshot step=$currentStep nodes=${activeNodes.size}")
            true
        }.getOrDefault(false)
    }

    fun initSession(context: Context, initialGrounding: String) {
        if (loadSnapshot(context) && activeNodes.isNotEmpty()) {
            AppLog.append("CognitiveOs: Resuming session from persistent disk storage at step $currentStep")
            return
        }
        currentStep = 1
        activeNodes.clear()
        beliefEdges.clear()
        rootGoal = GoalNode("g1", "Explore: ${initialGrounding.take(40)}...", openQuestions = mutableListOf("How can we structurally verify feasibility?"))
        val rootNode = BeliefNode("n001", initialGrounding.trim(), importance = 1.0f, confidence = 1.0f, createdIter = 1, lastTouchIter = 1)
        activeNodes["n001"] = rootNode
    }

    /**
     * Step 3: SOTA Retrieval Math (Base-Level ACT-R Activation + PageRank Centrality Shield).
     * Protects foundational axioms against recency amnesia.
     */
    fun computeRetrievalScore(node: BeliefNode, currentIter: Int, decayRate: Float = 0.95f, lambdaCentrality: Float = 0.30f): Float {
        if (node.status != "ACTIVE") return -1f

        // 1. ACT-R Power Law Decay
        val delta = kotlin.math.max(0, currentIter - node.lastTouchIter)
        val actR = node.importance * decayRate.pow(delta).toFloat()

        // 2. Structural Graph Centrality (count downstream claims supported)
        val descendantCount = beliefEdges.count { it.targetId == node.id && it.relation == "SUPPORTS" }
        val centralityShield = lambdaCentrality * ln(1.0f + descendantCount)

        return actR + centralityShield
    }

    /**
     * Step 4: Top-K Working Set Assembly.
     * Strictly slices highest activation nodes to guarantee injected prompt stays ~400 tokens flat forever.
     */
    fun assembleWorkingSetPrompt(currentIter: Int, maxCharsBudget: Int = 1350): String {
        if (activeNodes.isEmpty()) return "No cognitive state available."

        val scored = activeNodes.values.filter { it.status == "ACTIVE" }.map { node ->
            node to computeRetrievalScore(node, currentIter)
        }.sortedByDescending { it.second }

        val sb = StringBuilder()
        sb.appendLine("[CURRENT COGNITIVE REALITY (Step $currentIter)]")
        sb.appendLine("Active Objective Branch: ${rootGoal.title} (${rootGoal.status})")
        if (rootGoal.openQuestions.isNotEmpty()) {
            sb.appendLine("Bounded Open Question: \"${rootGoal.openQuestions.first()}\"")
        }
        sb.appendLine("\n[Ranked Active Belief Graph (Top-K Sliced Working Set)]:")

        var charsUsed = sb.length
        for ((node, score) in scored) {
            val entry = "[${node.id}] ${node.claim} (Conf: ${"%.2f".format(node.confidence)}, Act: ${"%.2f".format(score)})"
            if (charsUsed + entry.length + 2 > maxCharsBudget && node.id != "n001") continue
            sb.appendLine(entry)
            charsUsed += entry.length + 2
        }

        val causalLinks = beliefEdges.takeLast(5)
        if (causalLinks.isNotEmpty()) {
            sb.appendLine("\n[Recent Causal Chains]:")
            causalLinks.forEach { edge ->
                sb.appendLine("${edge.sourceId} --[${edge.relation}]--> ${edge.targetId}")
            }
        }

        return sb.toString().trim()
    }

    /**
     * Step 8: Write-Time Deduplication Check.
     * Prevents belief graph bloat from restatements.
     */
    private fun isNearDuplicate(claim: String): Boolean {
        val qWords = claim.lowercase().split(" ").filter { it.length > 3 }.toSet()
        if (qWords.isEmpty()) return false
        return activeNodes.values.any { n ->
            if (n.status != "ACTIVE") return@any false
            val nWords = n.claim.lowercase().split(" ").filter { it.length > 3 }.toSet()
            val intersection = qWords.intersect(nWords).size
            val union = qWords.union(nWords).size
            val jaccard = if (union > 0) intersection.toFloat() / union.toFloat() else 0f
            jaccard > 0.75f
        }
    }

    /**
     * Step 7: Empirical Verifier Gate (Local Traversal + Empirical Scrape Heuristic).
     */
    private fun verifyEmpiricalHeuristic(claim: String): Boolean {
        val empiricalIndicators = claim.contains(Regex("\\d+")) || claim.contains("%") || claim.contains("kg") || claim.contains("W")
        return empiricalIndicators
    }

    /**
     * Step 2 & Step 5: Register Graph Delta & Update Confidence.
     */
    fun registerDeltaUpdate(
        newClaim: String,
        supportsId: String? = null,
        contradictsId: String? = null,
        closedQuestion: String? = null,
        newQuestion: String? = null
    ): String {
        currentStep += 1

        // Step 8: Deduplication check
        if (isNearDuplicate(newClaim)) {
            AppLog.append("CognitiveOs: Skipped duplicate restatement at step $currentStep")
            return "duplicate"
        }

        val newId = "n" + currentStep.toString().padStart(3, '0')
        var initialConf = 0.90f
        if (verifyEmpiricalHeuristic(newClaim)) initialConf = 0.85f // slightly more uncertain until empirically verified

        val newNode = BeliefNode(newId, newClaim.trim(), importance = 0.85f, confidence = initialConf, createdIter = currentStep, lastTouchIter = currentStep)
        activeNodes[newId] = newNode

        // Truth maintenance causal graph reinforcement
        if (supportsId != null && activeNodes.containsKey(supportsId)) {
            beliefEdges.add(BeliefEdge(newId, supportsId, "SUPPORTS"))
            activeNodes[supportsId]?.let {
                it.touchCount += 1
                it.lastTouchIter = currentStep
                it.confidence = kotlin.math.min(1.0f, it.confidence + 0.03f) // Step 5 reinforcement
            }
        }

        // Gap 3: Free Instant Graph Consistency Verifier Check
        if (contradictsId != null && activeNodes.containsKey(contradictsId)) {
            val settledNode = activeNodes[contradictsId]
            if (settledNode != null && settledNode.confidence > 0.88f && settledNode.importance > 0.85f) {
                AppLog.append("CognitiveOs Verifier Gate: Blocked contradiction against settled verified node [${settledNode.id}]")
                return "blocked_contradiction"
            }
            beliefEdges.add(BeliefEdge(newId, contradictsId, "CONTRADICTS"))
            activeNodes[contradictsId]?.let {
                it.confidence = kotlin.math.max(0.1f, it.confidence - 0.25f) // Step 5 penalty
                it.lastTouchIter = currentStep
            }
        }

        // Step 1: Objectives question bounding (Invariant: close 1, open max 1)
        if (closedQuestion != null) rootGoal.openQuestions.remove(closedQuestion)
        if (newQuestion != null && rootGoal.openQuestions.size < 3) rootGoal.openQuestions.add(0, newQuestion)

        rootGoal.settledFactsAddedInWindow += 1

        // Step 6: Scheduled Consolidation / Sleep Pass
        if (currentStep % 8 == 0) {
            runConsolidationSleepPass()
        }

        return newId
    }

    /**
     * Step 6: Consolidation Pass (Sleep Step).
     * Compresses evicted low-activation nodes into 1 Meta-Node and archives raw underlying items.
     */
    private fun runConsolidationSleepPass() {
        val lowActivationNodes = activeNodes.values.filter {
            it.status == "ACTIVE" && computeRetrievalScore(it, currentStep) < 0.22f && it.id != "n001"
        }
        if (lowActivationNodes.size >= 2) {
            val metaId = "meta_" + currentStep
            val combinedPrinciple = "Consolidated Meta-Node (Iter ${lowActivationNodes.minOf { it.createdIter }}..$currentStep): " +
                lowActivationNodes.take(3).joinToString(" • ") { it.claim.take(35) }

            val metaNode = BeliefNode(metaId, combinedPrinciple, importance = 0.92f, confidence = 0.95f, createdIter = currentStep, lastTouchIter = currentStep)
            activeNodes[metaId] = metaNode

            lowActivationNodes.forEach { n ->
                n.status = "ARCHIVED_EVIDENCE"
                beliefEdges.add(BeliefEdge(n.id, metaId, "EVIDENCE_CHILD"))
            }
            AppLog.append("CognitiveOs Sleep Pass: Consolidated ${lowActivationNodes.size} low-activation items into $metaId")
        }

        // Step 1: Branch convergence pacing check
        if (rootGoal.settledFactsAddedInWindow < 2 && currentStep > 12) {
            rootGoal.status = "BRANCH_CONVERGED_PIVOTING"
            AppLog.append("CognitiveOs Goal Tree: Branch pacing converged. Pivoting objective.")
            rootGoal.settledFactsAddedInWindow = 0
        }
    }

    fun getActiveNodesCount(): Int = activeNodes.values.count { it.status == "ACTIVE" }
    fun getEdgesCount(): Int = beliefEdges.size
    fun getCurrentStep(): Int = currentStep

    fun saveSnapshot(context: Context) {
        runCatching {
            val snap = CognitiveStateSnapshot(currentStep, rootGoal, activeNodes, beliefEdges)
            File(context.filesDir, STORE_FILE).writeText(json.encodeToString(snap))
        }
    }
}