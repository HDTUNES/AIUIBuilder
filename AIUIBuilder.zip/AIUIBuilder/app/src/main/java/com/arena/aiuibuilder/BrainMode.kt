package com.arena.aiuibuilder

enum class BrainMode(val label: String, val desc: String) {
    SELF_EVOLVE(
        "Self-Evolve",
        "Infinite recursive reasoning. Watch how far the model can go. Manual stop."
    ),
    SYNTHESIZE(
        "Synthesize",
        "Confidence-gated stop. Metacognition + verify + reality test → structured final answer."
    )
}

data class BrainConfig(
    val mode: BrainMode = BrainMode.SYNTHESIZE,
    val maxIterations: Int = if (mode == BrainMode.SELF_EVOLVE) Int.MAX_VALUE else 18,
    val stopConfidence: Float = 0.82f,
    val enableCodeExec: Boolean = true,
    val enablePeripheralScan: Boolean = true,
    val enableInvariantCheck: Boolean = true,
    val finalAnswerTokens: Int = 0 // 0 = dynamic
)

data class ModelCheckpoint(
    val version: Int,
    val summary: String,
    val invariants: List<String>,
    val timestamp: Long = System.currentTimeMillis()
)
