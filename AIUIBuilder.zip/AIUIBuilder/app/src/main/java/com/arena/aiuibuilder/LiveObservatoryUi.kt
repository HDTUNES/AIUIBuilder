package com.arena.aiuibuilder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ─────────────────────────────────────────────────────────────────────────────
// Professional Dark Theme — ObsColors (Pure black + gray + white accents)
// ─────────────────────────────────────────────────────────────────────────────
object ObsColors {
    // Backgrounds — pure black, no violet/blue tints
    val BgDeep     = Color(0xFF000000)   // pure black
    val BgPanel    = Color(0xFF111111)   // near black
    val BgCard     = Color(0xFF1A1A1A)   // dark gray card
    val BgHover    = Color(0xFF222222)   // hover state

    // Borders — gray scale
    val Border     = Color(0xFF2A2A2A)   // subtle border
    val BorderMid  = Color(0xFF3A3A3A)   // medium border

    // Text — white scale
    val TextPrime  = Color(0xFFFFFFFF)   // pure white (primary text)
    val TextMuted  = Color(0xFFB0B0B0)   // muted gray
    val TextDim    = Color(0xFF666666)   // dim gray (secondary)

    // State accents — green/amber/red only, used sparingly
    val AccentGreen= Color(0xFF00C853)   // success / loaded / ready
    val AccentAmber= Color(0xFFFFB300)   // warning / thinking
    val AccentRed  = Color(0xFFFF5252)   // error / stop
    val AccentCyan = Color(0xFF00BCD4)   // info / active (kept for observatory)

    // Shimmer — grayscale for GPU shimmer
    val Shimmer1   = Color(0xFFE0E0E0)   // light shimmer
    val Shimmer2   = Color(0xFF909090)   // dark shimmer

    // Input field
    val InputBg    = Color(0xFF141414)   // dark input background
    val InputBorder= Color(0xFF2E2E2E)   // input border
}

// ─────────────────────────────────────────────────────────────────────────────
// Stage metadata: label, description, icon char
// ─────────────────────────────────────────────────────────────────────────────
data class StageSpec(
    val stage: PipelineStage,
    val label: String,
    val description: String
)

private val ALL_STAGE_SPECS = listOf(
    StageSpec(PipelineStage.SYSTEM_PROMPT_ASSEMBLY, "SYSTEM PROMPT", "Build & assemble the system prompt"),
    StageSpec(PipelineStage.MEMORY_RETRIEVAL,       "MEMORY RETRIEVAL", "Query belief graph for context"),
    StageSpec(PipelineStage.GOAL_SELECTION,         "GOAL SELECTION", "Pick cell via adversarial UCB"),
    StageSpec(PipelineStage.ARCHIVE_REVIEW,         "ARCHIVE REVIEW", "Review archived patterns"),
    StageSpec(PipelineStage.HYPOTHESIS_GENERATION,  "HYPOTHESIS GEN", "Generate reasoning & JSON output"),
    StageSpec(PipelineStage.CODE_EXECUTION,         "CODE EXEC", "Adversarial LLM self-critique of hypothesis"),
    StageSpec(PipelineStage.VERIFICATION_TESTING,   "VERIFY TEST", "Empirical validation & Jaccard"),
    StageSpec(PipelineStage.REPAIR_RETRY,           "REPAIR RETRY", "Self-repair & fallback rescue"),
    StageSpec(PipelineStage.PERSISTENCE_SNAPSHOT,   "PERSISTENCE", "Commit to belief graph & memory")
)

private val stageSpecMap = ALL_STAGE_SPECS.associateBy { it.stage }

// ─────────────────────────────────────────────────────────────────────────────
// Shimmer modifier for GPU shimmer on active stages
// ─────────────────────────────────────────────────────────────────────────────
private fun Modifier.activeShimmer(shimmerOffset: Float, baseColor: Color): Modifier {
    return this.drawBehind {
        val shimmerX = size.width * shimmerOffset
        val shimmerWidth = size.width * 0.3f
        val shimmerHighlight = ObsColors.Shimmer1.copy(alpha = 0.18f)
        val gradient = Brush.horizontalGradient(
            colors = listOf(
                baseColor,
                shimmerHighlight,
                baseColor,
            ),
            startX = shimmerX - shimmerWidth,
            endX = shimmerX + shimmerWidth
        )
        drawRect(brush = gradient)
    }
}

@Composable
private fun rememberShimmerOffset(): Float {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerOffset"
    )
    return shimmerOffset
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Observatory Panel
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun LiveObservatoryPanel(
    iterationNumber: Int,
    stageMap: Map<PipelineStage, StageDiagnostics>,
    liveTokenStream: String,
    modifier: Modifier = Modifier
) {
    // CRITICAL: Do NOT add verticalScroll here.
    // LiveObservatoryPanel is always embedded inside the verticalScroll of
    // RecursiveRefinerPanel (RefinerPanel.kt) and CognitivePanel (CognitivePanel.kt).
    // A nested verticalScroll inside an outer verticalScroll gives both containers
    // unbounded height, which causes Compose measurement deadlock → ANR freeze the
    // instant the tab is selected. The outer panel Column scroll handles all scrolling.
    val shimmerOffset = rememberShimmerOffset()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(ObsColors.BgDeep)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PIPELINE OBSERVATORY",
                color = ObsColors.TextDim,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "ITER #$iterationNumber",
                color = ObsColors.TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.Monospace
            )
        }

        Divider(color = ObsColors.Border, thickness = 0.5.dp)

        // Stage cards
        ALL_STAGE_SPECS.forEach { spec ->
            val diag = stageMap[spec.stage]
            StageCard(
                spec = spec,
                diag = diag,
                shimmerOffset = shimmerOffset,
                liveTokenStream = liveTokenStream
            )
        }

        // Token stream footer
        if (liveTokenStream.isNotBlank()) {
            Divider(color = ObsColors.Border, thickness = 0.5.dp)
            ShimmerText(liveTokenStream)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Individual Stage Card — auto-expand/collapse
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun StageCard(
    liveTokenStream: String,
    spec: StageSpec,
    diag: StageDiagnostics?,
    shimmerOffset: Float
) {
    var expanded by remember { mutableStateOf(diag?.status == StageStatus.ACTIVE) }

    LaunchedEffect(diag?.status) {
        if (diag?.status == StageStatus.ACTIVE) expanded = true
    }

    val isActive = diag?.status == StageStatus.ACTIVE
    val isCompleted = diag?.status == StageStatus.COMPLETED
    val isFailed = diag?.status == StageStatus.FAILED
    val isSkipped = diag?.status == StageStatus.SKIPPED

    val cardBg = when {
        isActive  -> ObsColors.BgCard
        isCompleted -> ObsColors.BgCard
        else      -> ObsColors.BgPanel
    }

    val borderColor = when {
        isActive  -> ObsColors.AccentCyan.copy(alpha = 0.4f)
        isCompleted -> ObsColors.AccentGreen.copy(alpha = 0.3f)
        isFailed -> ObsColors.AccentRed.copy(alpha = 0.3f)
        else     -> ObsColors.Border
    }

    val pulseAlpha = if (isActive) {
        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        infiniteTransition.animateFloat(
            initialValue = 0.4f,
            targetValue = 0.8f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseAlpha"
        ).value
    } else 1f

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isActive) Modifier.activeShimmer(shimmerOffset, cardBg)
                else Modifier.background(cardBg)
            )
            .border(0.5.dp, borderColor, RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp))
            .clickable { expanded = !expanded }
            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        // Collapsed header row
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Status indicator
            StageStatusIndicator(diag?.status, pulseAlpha)

            // Stage label
            val labelColor = when {
                isActive   -> ObsColors.TextPrime
                isCompleted -> ObsColors.AccentGreen
                isFailed   -> ObsColors.AccentRed
                isSkipped  -> ObsColors.TextDim
                else       -> ObsColors.TextMuted
            }
            Text(
                text = spec.label,
                color = labelColor,
                fontSize = 10.sp,
                fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Medium,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )

            Spacer(Modifier.weight(1f))

            // Time if available
            diag?.let {
                if (it.completedAtMs > 0 && it.startedAtMs > 0) {
                    val elapsed = (it.completedAtMs - it.startedAtMs) / 1000.0
                    Text(
                        text = "${elapsed.toInt()}ms",
                        color = ObsColors.TextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Expand chevron
            Text(
                text = if (expanded) "▲" else "▼",
                color = ObsColors.TextDim,
                fontSize = 8.sp
            )
        }

        // Short summary on one line when collapsed
        if (!expanded && !diag?.outputSummary.isNullOrBlank()) {
            Text(
                text = diag!!.outputSummary.take(45),
                color = ObsColors.TextDim,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 0.dp)
                    .widthIn(max = 160.dp)
            )
        }

        // Expanded details
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)),
            exit  = shrinkVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (diag == null) {
                    Text("Awaiting...", color = ObsColors.TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                } else {
                    // Stage description
                    Text(spec.description, color = ObsColors.TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

                    Divider(color = ObsColors.Border, thickness = 0.5.dp)

                    // Memory read nodes
                    if (diag.readNodes.isNotEmpty()) {
                        Text("MEMORY READ", color = ObsColors.AccentCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                        diag.readNodes.forEach { node ->
                            Text("  $node", color = ObsColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Archived nodes
                    if (diag.archivedNodes.isNotEmpty()) {
                        Text("ARCHIVED", color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                        diag.archivedNodes.forEach { node ->
                            Text("  $node", color = ObsColors.TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Live token stream
                    if (diag.stage == PipelineStage.HYPOTHESIS_GENERATION && liveTokenStream.isNotBlank()) {
                        Text("TOKEN STREAM", color = ObsColors.AccentCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0A0A0A), RoundedCornerShape(4.dp))
                                .padding(6.dp)
                        ) {
                            Text(
                                text = liveTokenStream.takeLast(200),
                                color = ObsColors.TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 280.dp)
                            )
                        }
                    }

                    // Code execution result
                    if (diag.codeSnippet.isNotBlank()) {
                        Text("SNIPPET", color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0A0A0A), RoundedCornerShape(4.dp))
                                .padding(6.dp)
                        ) {
                            Text(diag.codeSnippet.take(150), color = ObsColors.TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                        if (diag.codeOutput.isNotBlank()) {
                            Text("RESULT", color = if (diag.codeSuccess) ObsColors.AccentGreen else ObsColors.AccentRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                            Box(
                                modifier = Modifier.fillMaxWidth().background(Color(0xFF0A0A0A), RoundedCornerShape(4.dp)).padding(6.dp)
                            ) {
                                Text(diag.codeOutput.take(100), color = ObsColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                            Text("Exec time: ${diag.codeTimeMs}ms", color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Verification
                    if (diag.jaccardScore > 0f) {
                        Text("JACCARD: ${"%.2f".format(diag.jaccardScore)} | DOMAIN: ${if (diag.domainVerified) "✓" else "✗"} | ADVERSARIAL: ${diag.adversarialGate}", color = ObsColors.TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }

                    // Repair
                    if (diag.repairLog.isNotBlank()) {
                        Text("REPAIR LOG", color = ObsColors.AccentAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                        Text(diag.repairLog, color = ObsColors.TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        if (diag.repairAttempts > 0) Text("Attempts: ${diag.repairAttempts}", color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }

                    // Error
                    diag.errorMessage?.let {
                        Text("ERROR: $it", color = ObsColors.AccentRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }

                    // Output summary if not shown in token stream
                    if (diag.outputSummary.isNotBlank() && diag.stage != PipelineStage.HYPOTHESIS_GENERATION) {
                        Text("OUTPUT: ${diag.outputSummary}", color = ObsColors.TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Status Indicator
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun StageStatusIndicator(status: StageStatus?, pulseAlpha: Float) {
    Box(
        modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .then(
                when (status) {
                    StageStatus.ACTIVE    -> Modifier.background(ObsColors.AccentCyan.copy(alpha = pulseAlpha))
                    StageStatus.COMPLETED -> Modifier.background(ObsColors.AccentGreen)
                    StageStatus.FAILED    -> Modifier.background(ObsColors.AccentRed)
                    StageStatus.SKIPPED   -> Modifier.background(ObsColors.TextDim)
                    else                  -> Modifier.background(ObsColors.BorderMid)
                }
            )
    ) {
        if (status == StageStatus.ACTIVE) {
            CircularProgressIndicator(
                modifier = Modifier.size(8.dp),
                color = ObsColors.AccentCyan.copy(alpha = pulseAlpha),
                strokeWidth = 1.dp
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shimmer text with animated gradient
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ShimmerText(text: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmerText")
    val shimmerProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerText"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A0A0A), RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Text(
            text = text.takeLast(300),
            color = ObsColors.TextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.drawBehind {
                val gradient = Brush.horizontalGradient(
                    colors = listOf(
                        ObsColors.TextMuted,
                        ObsColors.Shimmer1,
                        ObsColors.TextMuted
                    ),
                    startX = 0f,
                    endX = size.width
                )
            }
        )
    }
}