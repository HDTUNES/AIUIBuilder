package com.arena.aiuibuilder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ─────────────────────────────────────────────────────────────────────────────
// Shared color system — replaces scattered private color definitions
// ─────────────────────────────────────────────────────────────────────────────
object ObsColors {
    val BgDeep     = Color(0xFF020617)   // slate-950
    val BgPanel    = Color(0xFF0F172A)   // slate-900
    val BgCard     = Color(0xFF111827)   // gray-900
    val Border     = Color(0xFF1E293B)   // slate-800
    val BorderMid  = Color(0xFF334155)   // slate-700
    val TextPrime  = Color(0xFFF8FAFC)   // slate-50
    val TextMuted  = Color(0xFF94A3B8)   // slate-400
    val TextDim    = Color(0xFF475569)   // slate-600
    val AccentCyan = Color(0xFF06B6D4)   // cyan-500
    val AccentGreen= Color(0xFF10B981)   // emerald-500
    val AccentAmber= Color(0xFFF59E0B)   // amber-500
    val AccentRed  = Color(0xFFEF4444)   // red-500
    val Shimmer1   = Color(0xFFE2E8F0)   // slate-200
    val Shimmer2   = Color(0xFF94A3B8)   // slate-400
}

// ─────────────────────────────────────────────────────────────────────────────
// Stage metadata: label, description, icon char
// ─────────────────────────────────────────────────────────────────────────────
private data class StageSpec(
    val stage: PipelineStage,
    val label: String,
    val shortLabel: String,
    val description: String
)

private val ALL_STAGE_SPECS = listOf(
    StageSpec(PipelineStage.SYSTEM_PROMPT_ASSEMBLY,   "Prompt Assembly",    "PROMPT",   "Building system context, directives, schema"),
    StageSpec(PipelineStage.MEMORY_RETRIEVAL,         "Memory Retrieval",   "MEMORY",   "ACT-R activation scoring, top-K working set"),
    StageSpec(PipelineStage.GOAL_SELECTION,           "Goal Selection",     "GOAL",     "UCB bandit, MAP-Elites target coordinate"),
    StageSpec(PipelineStage.ARCHIVE_REVIEW,           "Archive Review",     "ARCHIVE",  "Niche boundaries, elite quality comparison"),
    StageSpec(PipelineStage.HYPOTHESIS_GENERATION,    "Generating",         "GENERATE", "GBNF grammar-constrained token stream"),
    StageSpec(PipelineStage.CODE_EXECUTION,           "Code Execution",     "CODE",     "JS sandbox reality check, logical gates"),
    StageSpec(PipelineStage.VERIFICATION_TESTING,     "Verification",       "VERIFY",   "Adversarial scoring, domain tag check"),
    StageSpec(PipelineStage.REPAIR_RETRY,             "Repair / Retry",     "REPAIR",   "JSON fix, lens rotation, failure postmortem"),
    StageSpec(PipelineStage.PERSISTENCE_SNAPSHOT,     "Persisting",         "SAVE",     "Memory snapshot, node consolidation")
)

// ─────────────────────────────────────────────────────────────────────────────
// Performance shimmer: GPU-based sweep avoids recomposition cost
// ─────────────────────────────────────────────────────────────────────────────
private fun Modifier.activeShimmer(sweepOffset: Float, baseColor: Color = ObsColors.BgCard): Modifier = this.drawBehind {
    drawRect(color = baseColor)
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.0f),
                Color.White.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.08f),
                Color.White.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.0f)
            ),
            start = Offset(sweepOffset - 200f, 0f),
            end   = Offset(sweepOffset + 200f, size.height)
        )
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Main composable: the full 9-stage observatory panel
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun LiveObservatoryPanel(
    iterationNumber: Int,
    isRunning: Boolean,
    liveTokenStream: String
) {
    val stageMap = ObservatoriumSession.stageMap

    // Global shimmer transition — one animation drives all active stages
    val shimmerTransition = rememberInfiniteTransition(label = "obs-shimmer")
    val shimmerOffset by shimmerTransition.animateFloat(
        initialValue = -400f,
        targetValue  = 2000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer-sweep"
    )

    // Pulse for active stage status dot
    val pulseAlpha by shimmerTransition.animateFloat(
        initialValue = 0.4f,
        targetValue  = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse-alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsColors.BgPanel, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // ── Header ─────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (isRunning) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(ObsColors.AccentCyan.copy(alpha = pulseAlpha))
                    )
                }
                Text(
                    text = if (isRunning) "RUNNING — ITER $iterationNumber" else "IDLE",
                    color = if (isRunning) ObsColors.AccentCyan else ObsColors.TextDim,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.5.sp
                )
            }
            Text(
                text = "COGNITIVE PIPELINE",
                color = ObsColors.TextDim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        Spacer(Modifier.height(6.dp))
        Divider(color = ObsColors.Border, thickness = 0.5.dp)
        Spacer(Modifier.height(6.dp))

        // ── Stage cards ─────────────────────────────────────────────────────
        ALL_STAGE_SPECS.forEach { spec ->
            val diag = stageMap[spec.stage]
                ?: StageDiagnostics(stage = spec.stage, status = StageStatus.PENDING)
            StageCard(
                spec = spec,
                diag = diag,
                shimmerOffset = shimmerOffset,
                pulseAlpha = pulseAlpha,
                liveTokenStream = liveTokenStream
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Individual stage card
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun StageCard(
    spec: StageSpec,
    diag: StageDiagnostics,
    shimmerOffset: Float,
    pulseAlpha: Float,
    liveTokenStream: String
) {
    var expanded by remember { mutableStateOf(false) }

    // Auto-expand when ACTIVE, auto-collapse after delay when COMPLETED/FAILED
    LaunchedEffect(diag.status) {
        when (diag.status) {
            StageStatus.ACTIVE -> expanded = true
            StageStatus.COMPLETED, StageStatus.FAILED -> {
                delay(1400)
                expanded = false
            }
            else -> {}
        }
    }

    val isActive = diag.status == StageStatus.ACTIVE
    val cardBg = when (diag.status) {
        StageStatus.ACTIVE    -> ObsColors.BgCard
        StageStatus.COMPLETED -> ObsColors.BgPanel
        StageStatus.FAILED    -> Color(0xFF1A0A0A)
        else                  -> ObsColors.BgPanel
    }
    val borderColor = when (diag.status) {
        StageStatus.ACTIVE    -> ObsColors.AccentCyan.copy(alpha = 0.5f)
        StageStatus.COMPLETED -> ObsColors.Border
        StageStatus.FAILED    -> ObsColors.AccentRed.copy(alpha = 0.4f)
        else                  -> ObsColors.Border.copy(alpha = 0.4f)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isActive) Modifier.activeShimmer(shimmerOffset, cardBg)
                else Modifier.background(cardBg)
            )
            .border(0.5.dp, borderColor, RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp))
            .clickable { expanded = !expanded }
            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        // ── Collapsed header row ───────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Status indicator
            StageStatusIndicator(diag.status, pulseAlpha)

            // Stage label
            val labelColor = when (diag.status) {
                StageStatus.ACTIVE    -> ObsColors.AccentCyan
                StageStatus.COMPLETED -> ObsColors.TextMuted
                StageStatus.FAILED    -> ObsColors.AccentRed
                else                  -> ObsColors.TextDim
            }
            if (isActive) {
                ShimmerText(spec.label, ObsColors.TextDim, ObsColors.TextPrime, fontSize = 12)
            } else {
                Text(
                    text = spec.label,
                    color = labelColor,
                    fontSize = 12.sp,
                    fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Light,
                    fontFamily = FontFamily.Default
                )
            }

            Spacer(Modifier.weight(1f))

            // Elapsed time if complete
            if (diag.status == StageStatus.COMPLETED || diag.status == StageStatus.FAILED) {
                val ms = diag.completedAtMs - diag.startedAtMs
                Text(
                    text = if (ms > 1000) "${"%.1f".format(ms / 1000.0)}s" else "${ms}ms",
                    color = ObsColors.TextDim,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            } else if (isActive) {
                CircularProgressIndicator(
                    modifier = Modifier.size(12.dp),
                    color = ObsColors.AccentCyan,
                    strokeWidth = 1.5.dp
                )
            }

            // Short summary on one line when collapsed
            if (!expanded && diag.outputSummary.isNotBlank()) {
                Text(
                    text = diag.outputSummary.take(45),
                    color = ObsColors.TextDim,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 160.dp)
                )
            }
        }

        // ── Expanded details ────────────────────────────────────────────────
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)),
            exit  = shrinkVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF080C14))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(spec.description, color = ObsColors.TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Divider(color = ObsColors.Border, thickness = 0.5.dp)

                if (diag.inputSummary.isNotBlank()) {
                    DiagRow("IN", diag.inputSummary, ObsColors.TextMuted)
                }
                if (diag.promptSizeChars > 0) {
                    DiagRow("SIZE", "${diag.promptSizeChars} chars (~${diag.promptSizeTokensEstimate} tokens)", ObsColors.TextDim)
                }
                if (diag.outputSummary.isNotBlank()) {
                    DiagRow("OUT", diag.outputSummary, ObsColors.TextMuted)
                }

                if (diag.readNodes.isNotEmpty()) {
                    Text("MEMORY READ", color = ObsColors.AccentCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                    diag.readNodes.forEach { node ->
                        Text("  $node", color = ObsColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                if (diag.archivedNodes.isNotEmpty()) {
                    Text("ARCHIVED", color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    diag.archivedNodes.take(3).forEach { node ->
                        Text("  $node", color = ObsColors.TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                if (diag.selectedCell.isNotBlank()) {
                    DiagRow("CELL", diag.selectedCell, ObsColors.AccentCyan)
                }
                if (diag.winningPolicy.isNotBlank()) {
                    DiagRow("POLICY", "${diag.winningPolicy} (${(diag.policySuccessRate * 100).toInt()}%)", ObsColors.TextMuted)
                }
                if (diag.ucbScore > 0f) {
                    DiagRow("UCB", "%.4f".format(diag.ucbScore), ObsColors.TextDim)
                }

                // HYPOTHESIS_GENERATION: live stream
                if (spec.stage == PipelineStage.HYPOTHESIS_GENERATION && (diag.status == StageStatus.ACTIVE || diag.rawJsonGenerated.isNotBlank())) {
                    val displayText = if (diag.status == StageStatus.ACTIVE && liveTokenStream.isNotBlank()) liveTokenStream
                                      else diag.rawJsonGenerated
                    if (displayText.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text("TOKEN STREAM", color = ObsColors.AccentCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF000000), RoundedCornerShape(4.dp))
                                .padding(8.dp)
                                .heightIn(max = 120.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = displayText.takeLast(800) + if (diag.status == StageStatus.ACTIVE) "█" else "",
                                color = Color(0xFF86EFAC),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                // CODE_EXECUTION
                if (spec.stage == PipelineStage.CODE_EXECUTION) {
                    if (diag.codeOutput.isNotBlank()) {
                        Text("RESULT", color = if (diag.codeSuccess) ObsColors.AccentGreen else ObsColors.AccentRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Box(Modifier.fillMaxWidth().background(Color(0xFF000000), RoundedCornerShape(4.dp)).padding(8.dp)) {
                            Text(
                                diag.codeOutput,
                                color = if (diag.codeSuccess) ObsColors.AccentGreen else ObsColors.AccentRed,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (diag.codeTimeMs > 0) {
                            Text("Exec time: ${diag.codeTimeMs}ms", color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                // VERIFICATION
                if (spec.stage == PipelineStage.VERIFICATION_TESTING) {
                    DiagRow("JACCARD", "%.3f".format(diag.jaccardScore), ObsColors.TextMuted)
                    DiagRow("DOMAIN", if (diag.domainVerified) "VERIFIED" else "MISMATCH",
                        if (diag.domainVerified) ObsColors.AccentGreen else ObsColors.AccentAmber)
                    if (diag.adversarialGate.isNotBlank()) {
                        DiagRow("NOVELTY", diag.adversarialGate, ObsColors.TextMuted)
                    }
                }

                // REPAIR_RETRY
                if (spec.stage == PipelineStage.REPAIR_RETRY && diag.repairLog.isNotBlank()) {
                    Text("REPAIR LOG", color = ObsColors.AccentAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(diag.repairLog, color = ObsColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                // PERSISTENCE
                if (spec.stage == PipelineStage.PERSISTENCE_SNAPSHOT) {
                    DiagRow("SNAPSHOT", "${diag.snapshotSizeBytes / 1024} KB in ${diag.snapshotWriteMs}ms", ObsColors.TextMuted)
                    DiagRow("CONSOLIDATED", "${diag.nodesConsolidated} nodes", ObsColors.TextDim)
                }

                if (diag.metacognitionTriggered != null) {
                    DiagRow("META", diag.metacognitionTriggered, ObsColors.AccentAmber)
                }

                if (diag.errorMessage != null) {
                    DiagRow("ERROR", diag.errorMessage, ObsColors.AccentRed)
                }
            }
        }
    }
}

@Composable
private fun DiagRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(label, color = ObsColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(56.dp))
        Text(value, color = valueColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun StageStatusIndicator(status: StageStatus, pulseAlpha: Float) {
    Box(modifier = Modifier.size(16.dp), contentAlignment = Alignment.Center) {
        when (status) {
            StageStatus.ACTIVE -> {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(ObsColors.AccentCyan.copy(alpha = pulseAlpha))
                )
            }
            StageStatus.COMPLETED -> {
                Text("✓", color = ObsColors.AccentGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            StageStatus.FAILED -> {
                Text("✗", color = ObsColors.AccentRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            StageStatus.SKIPPED -> {
                Text("—", color = ObsColors.TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            StageStatus.PENDING -> {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(ObsColors.TextDim.copy(alpha = 0.3f))
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shimmer text: for active stage label
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ShimmerText(text: String, dimColor: Color, brightColor: Color, fontSize: Int = 12) {
    val transition = rememberInfiniteTransition(label = "stage-label-shimmer")
    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue  = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1200, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "sweep"
    )
    val brush = Brush.linearGradient(
        colors = listOf(dimColor, brightColor, brightColor, dimColor),
        start = Offset(0f + offset * 300f, 0f),
        end   = Offset(80f + offset * 300f, 0f)
    )
    Text(
        text = text,
        style = TextStyle(
            brush = brush,
            fontWeight = FontWeight.SemiBold,
            fontSize = fontSize.sp,
            fontFamily = FontFamily.Default
        )
    )
}