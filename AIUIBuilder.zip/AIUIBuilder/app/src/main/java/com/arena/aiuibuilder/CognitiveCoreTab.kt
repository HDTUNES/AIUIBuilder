package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arm.aichat.InferenceEngine

/**
 * COGNITIVE CORE — the unified reasoning tab.
 *
 * One brain, two operating conditions, not two separate products:
 *
 *  - NORMAL  -- the existing Cognitive engine (CognitivePanel/CognitiveEngine),
 *               unchanged. Bounded (max 20 operator calls), always converges to
 *               one confident final answer, then stops. This is what you use when
 *               you want an answer to a specific question.
 *
 *  - META-COGNITIVE -- the existing Refiner (RecursiveRefinerPanel/MesaEngine),
 *               unchanged. Open-ended: a MAP-Elites-style archive plus a
 *               Thompson-sampling policy bandit that keeps exploring and
 *               refining indefinitely via Auto Loop, never "concluding" on its
 *               own. This is what you use when you're curious what the model
 *               converges toward after many iterations, not after one.
 *
 * Deliberately NOT a rewrite of either engine -- both keep their own working
 * internals exactly as they are (per "the cognitive tab is working perfectly,
 * no modifications needed to the architecture"). This file is the shared roof:
 * one tab, one mode switch, both panels underneath it unchanged in behavior.
 */
private val CorePanel  = Color(0xFF000000)   // v10: pure black (was 0xFF0B0F17 dark navy)
private val CoreStroke = Color(0xFF1A1A1A)   // v10: dark grey stroke (was 0xFF263244 navy)
private val CoreTextMain = Color(0xFFE5E7EB)
private val CoreTextMuted = Color(0xFF94A3B8)
private val CoreAccentNormal = Color(0xFF7C3AED)
private val CoreAccentMeta = Color(0xFFF59E0B)

enum class CognitiveCoreMode { NORMAL, META_COGNITIVE }

@Composable
fun CognitiveCoreTab(
    engine: InferenceEngine,
    modelReady: Boolean,
    maxTokens: Int,
    onStatus: (String) -> Unit,
    onError: (String) -> Unit
) {
    var mode by remember { mutableStateOf(CognitiveCoreMode.NORMAL) }

    // CRITICAL: Do NOT add verticalScroll here.
    // CognitivePanel (Normal mode) and RecursiveRefinerPanel (Meta-Cognitive mode)
    // both already have their own verticalScroll. A nested verticalScroll inside
    // another verticalScroll gives both containers unbounded height, which causes
    // Compose measurement deadlock → ANR freeze the instant the tab is selected.
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text(
            "Cognitive Core",
            color = CoreTextMain,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
        )
        Text(
            "One reasoning mind, two operating conditions.",
            color = CoreTextMuted,
            fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        // ── Mode switch ─────────────────────────────────────────────────────
        Card(
            colors = CardDefaults.cardColors(containerColor = CorePanel),
            border = BorderStroke(1.dp, CoreStroke),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CoreModeChip(
                    label = "Normal",
                    sublabel = "Reach a confident final answer",
                    selected = mode == CognitiveCoreMode.NORMAL,
                    accent = CoreAccentNormal,
                    modifier = Modifier.weight(1f),
                    onClick = { mode = CognitiveCoreMode.NORMAL }
                )
                CoreModeChip(
                    label = "Meta-Cognitive",
                    sublabel = "Explore indefinitely, no final stop",
                    selected = mode == CognitiveCoreMode.META_COGNITIVE,
                    accent = CoreAccentMeta,
                    modifier = Modifier.weight(1f),
                    onClick = { mode = CognitiveCoreMode.META_COGNITIVE }
                )
            }
        }

        when (mode) {
            CognitiveCoreMode.NORMAL -> {
                CognitivePanel(
                    engine = engine,
                    enabled = modelReady,
                    maxTokens = maxTokens,
                    onStatus = onStatus,
                    onError = onError
                )
            }
            CognitiveCoreMode.META_COGNITIVE -> {
                RecursiveRefinerPanel(
                    modelReady = modelReady,
                    onStatus = onStatus,
                    onError = { onError(it ?: "") }
                )
            }
        }
    }
}

@Composable
private fun CoreModeChip(
    label: String,
    sublabel: String,
    selected: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (selected) accent.copy(alpha = 0.16f) else Color.Transparent
        ),
        border = BorderStroke(1.dp, if (selected) accent.copy(alpha = 0.55f) else CoreStroke),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Text(
                label,
                color = if (selected) accent else CoreTextMain,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                sublabel,
                color = CoreTextMuted,
                fontSize = 10.sp
            )
        }
    }
}