package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun ErrorLogPanel(onStatus: (String) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var logs by remember { mutableStateOf(AppLog.read(context)) }
    val path = remember { AppLog.path(context) }

    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)), border = BorderStroke(1.dp, Color(0xFF263244))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Error / Debug Logs", color = Color(0xFFE5E7EB), fontWeight = FontWeight.Bold)
            Text("Internal log path: $path", color = Color(0xFF94A3B8))
            Text("If the app crashes, reopen it and check this tab. Native hard crashes may only leave the last breadcrumb before the crash.", color = Color(0xFF94A3B8))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    logs = AppLog.read(context)
                    onStatus("Logs refreshed")
                }) { Text("Refresh") }
                Button(onClick = {
                    clipboard.setText(AnnotatedString(logs))
                    onStatus("Logs copied to clipboard")
                }) { Text("Copy") }
                Button(onClick = {
                    AppLog.clear(context)
                    logs = AppLog.read(context)
                    onStatus("Logs cleared")
                }) { Text("Clear") }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), modifier = Modifier.fillMaxWidth().height(520.dp)) {
                Text(
                    logs,
                    color = Color(0xFFE5E7EB),
                    modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState())
                )
            }
        }
    }
}
