package com.arena.aiuibuilder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

private val RPanel = Color(0xFF111827)
private val RPanel2 = Color(0xFF0F172A)
private val RStroke = Color(0xFF263244)
private val RText = Color(0xFFE5E7EB)
private val RMuted = Color(0xFF94A3B8)
private val RDanger = Color(0xFFF87171)

private val RefinerNativeDispatcher = Executors.newSingleThreadExecutor { runnable ->
    Thread(runnable, "recursive-refiner-native").apply { isDaemon = true }
}.asCoroutineDispatcher()

@Composable
fun RecursiveRefinerPanel(
    modelReady: Boolean,
    onStatus: (String) -> Unit,
    onError: (String?) -> Unit
) {
    val scope = AppScopes.main
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var grounding by remember { mutableStateOf("Design an artificial general intelligence capable of scientific discovery beyond current transformer architectures.") }
    var maxTokens by remember { mutableStateOf(650) }
    var temperature by remember { mutableStateOf(0.7f) }
    var topK by remember { mutableStateOf(40) }
    var topP by remember { mutableStateOf(0.9f) }
    var minP by remember { mutableStateOf(0.05f) }
    var repeatPenalty by remember { mutableStateOf(1.1f) }
    var strictKvCache by remember { mutableStateOf(false) }
    var thinkingMode by remember { mutableStateOf("OFF") }
    var webSearchEnabled by remember { mutableStateOf(false) }

    var cognitiveStage by remember { mutableStateOf(CognitiveStage.IDLE) }
    var controller by remember { mutableStateOf<RecursiveRefinerController?>(null) }
    var runningJob by remember { mutableStateOf<Job?>(null) }
    var liveProgress by remember { mutableStateOf("Idle") }
    var liveRawOutput by remember { mutableStateOf("") }
    var lastRawOutput by remember { mutableStateOf("") }
    var showLiveRaw by remember { mutableStateOf(true) }

    val iterations = remember { mutableStateListOf<RefinerIteration>() }
    val fullJsonHistory = remember { mutableStateListOf<String>() }
    val running = runningJob?.isActive == true

    Card(colors = CardDefaults.cardColors(containerColor = RPanel), border = BorderStroke(1.dp, RStroke), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("RECURSIVE OBSERVATORY", color = RText, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 1.5.sp)
            Text(
                "MESA Architecture Live Execution Monitor. Tracks coordinate targets, active policy bandits, and graph consistency verifications.",
                color = RMuted, fontSize = 11.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Status: $liveProgress", color = Color(0xFF86EFAC), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), fontSize = 12.sp)
                TextButton(onClick = {
                    val fullDump = buildString {
                        appendLine("=== MESA SCIENTIFIC REVISION SESSION ===")
                        appendLine("Grounding: $grounding")
                        appendLine("Iterations Run: ${iterations.size}")
                        appendLine("Parameters: temp=$temperature, maxTokens=$maxTokens, strictKV=$strictKvCache")
                        appendLine("\n=== FULL GENERATION HISTORICAL STREAM ===")
                        fullJsonHistory.forEachIndexed { idx, json ->
                            appendLine("\n[Iteration ${idx + 1} Raw GBNF JSON]:")
                            appendLine(json)
                        }
                    }
                    clipboard.setText(AnnotatedString(fullDump))
                    onStatus("Full Session state copied.")
                }) { Text("Copy Full Session", fontSize = 12.sp) }
            }
            OutlinedTextField(
                value = grounding,
                onValueChange = { grounding = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Universal Discovery Grounding") },
                minLines = 3
            )
            RefinerSlider("Max tokens", maxTokens.toFloat(), 80f, 900f, { maxTokens = it.toInt() }, maxTokens.toString())
            RefinerSlider("Temperature", temperature, 0.05f, 1.2f, { temperature = it }, "%.2f".format(temperature))
            RefinerSlider("Top K", topK.toFloat(), 1f, 100f, { topK = it.toInt() }, topK.toString())
            RefinerSlider("Top P", topP, 0.1f, 1.0f, { topP = it }, "%.2f".format(topP))
            RefinerSlider("Min P", minP, 0.0f, 0.2f, { minP = it }, "%.2f".format(minP))
            RefinerSlider("Repeat penalty", repeatPenalty, 1.0f, 1.5f, { repeatPenalty = it }, "%.2f".format(repeatPenalty))
            Card(colors = CardDefaults.cardColors(containerColor = RPanel2), border = BorderStroke(1.dp, RStroke)) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Strict KV cache erasure", color = RText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(
                                if (strictKvCache) "ON: sequence erasure active." else "OFF: safe compatibility evaluation.",
                                color = RMuted, fontSize = 11.sp
                            )
                        }
                        Switch(checked = strictKvCache, onCheckedChange = { strictKvCache = it })
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Thinking pre-stage", color = RText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { thinkingMode = "OFF" }, enabled = thinkingMode != "OFF") { Text("Off") }
                            Button(onClick = { thinkingMode = "AUTO" }, enabled = thinkingMode != "AUTO") { Text("Auto") }
                            Button(onClick = { thinkingMode = "FORCE" }, enabled = thinkingMode != "FORCE") { Text("Force") }
                        }
                    }
                }
            }
            CognitiveLoopMapV1Header(
                activeNodes = CognitiveOsMemory.getActiveNodesCount(),
                edgesCount = CognitiveOsMemory.getEdgesCount(),
                step = CognitiveOsMemory.getCurrentStep()
            )
            LiveStepTrackerV2(currentStage = cognitiveStage, liveText = liveRawOutput)
            WebSearchToggleSwitch(
                enabled = webSearchEnabled,
                onToggle = { 
                    webSearchEnabled = it
                    controller?.webSearchEnabled = it
                }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = modelReady && !running && grounding.isNotBlank(), onClick = {
                    scope.launch {
                        try {
                            onError(null)
                            onStatus("Caching grounding...")
                            val c = RecursiveRefinerController(
                                context = context.applicationContext,
                                grounding = grounding,
                                maxTokens = maxTokens,
                                temperature = temperature,
                                topK = topK,
                                topP = topP,
                                minP = minP,
                                repeatPenalty = repeatPenalty,
                                strictKvCache = strictKvCache,
                                thinkingMode = thinkingMode
                            ).apply { this.webSearchEnabled = webSearchEnabled }
                            val job = scope.async(RefinerNativeDispatcher) { c.startSession() }
                            while (job.isActive) {
                                liveProgress = "Evaluating prompt..."
                                delay(300)
                            }
                            job.await()
                            liveProgress = "Grounding cached"
                            controller = c
                            iterations.clear()
                            fullJsonHistory.clear()
                            onStatus("Grounding cached. Ready.")
                        } catch (t: Throwable) {
                            AppLog.appendError("Session failed", t)
                            onError(t.message ?: t.toString())
                            onStatus("Failed.")
                        }
                    }
                }) { Text("Start Session") }
                Button(enabled = modelReady && !running && controller != null, onClick = {
                    scope.launch {
                        runCatching {
                            onStatus("Running refinement...")
                            val c = controller ?: error("Controller missing")
                            val startedAt = System.nanoTime()
                            liveRawOutput = lastRawOutput

                            val job = scope.async(RefinerNativeDispatcher) { 
                                c.runOneIteration(onStage = { stage -> cognitiveStage = stage }) 
                            }
                            while (job.isActive) {
                                val elapsed = (System.nanoTime() - startedAt) / 1_000_000_000.0
                                val chars = NativeRecursiveRefiner.getProgressChars()
                                val tokens = NativeRecursiveRefiner.getProgressTokens()
                                val polledText = NativeRecursiveRefiner.getProgressText()
                                if (polledText.isNotBlank()) liveRawOutput = polledText
                                val timing = NativeRecursiveRefiner.getTimingSummary()
                                val tokSec = if (elapsed > 0.2) tokens / elapsed else 0.0
                                liveProgress = "Generating... $chars chars, $tokens tokens, ${"%.1f".format(tokSec)} tok/s • $timing"
                                delay(350)
                            }
                            val item = job.await()
                            lastRawOutput = NativeRecursiveRefiner.getProgressText().ifBlank { liveRawOutput }
                            liveRawOutput = lastRawOutput
                            fullJsonHistory.add(lastRawOutput)
                            liveProgress = "Done: ${item.refined.length} chars in ${"%.1f".format(item.generationTimeSeconds)}s"
                            iterations.add(0, item)
                            onStatus("Iteration ${item.iteration} complete.")
                            onError(null)
                        }.onFailure {
                            AppLog.appendError("Refiner iteration failed", it)
                            onError(it.message ?: it.toString())
                            onStatus("Failed.")
                        }
                    }
                }) { Text("Run Once") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = modelReady && controller != null && !running, onClick = {
                    runningJob = scope.launch {
                        onStatus("Auto-loop active...")
                        val c = controller ?: return@launch
                        var consecutiveFailures = 0
                        while (isActive) {
                            try {
                                val startedAt = System.nanoTime()
                                liveRawOutput = lastRawOutput
                                val job = scope.async(RefinerNativeDispatcher) { 
                                    c.runOneIteration(onStage = { stage -> cognitiveStage = stage }) 
                                }
                                while (job.isActive && isActive) {
                                    val elapsed = (System.nanoTime() - startedAt) / 1_000_000_000.0
                                    val chars = NativeRecursiveRefiner.getProgressChars()
                                    val tokens = NativeRecursiveRefiner.getProgressTokens()
                                    val polledText = NativeRecursiveRefiner.getProgressText()
                                    if (polledText.isNotBlank()) liveRawOutput = polledText
                                    val timing = NativeRecursiveRefiner.getTimingSummary()
                                    val tokSec = if (elapsed > 0.2) tokens / elapsed else 0.0
                                    liveProgress = "Generating... $chars chars, $tokens tokens, ${"%.1f".format(tokSec)} tok/s • $timing"
                                    delay(350)
                                }
                                val item = job.await()
                                lastRawOutput = NativeRecursiveRefiner.getProgressText().ifBlank { liveRawOutput }
                                liveRawOutput = lastRawOutput
                                fullJsonHistory.add(lastRawOutput)
                                iterations.add(0, item)
                                consecutiveFailures = 0
                                onStatus("Iteration ${item.iteration} complete.")
                                delay(1500)
                            } catch (t: CancellationException) {
                                onStatus("Auto-loop stopped.")
                                break
                            } catch (t: IllegalStateException) {
                                consecutiveFailures++
                                AppLog.appendError("Loop warning (retrying), count=$consecutiveFailures", t)
                                onStatus("GBNF parse warning, retrying...")
                                if (consecutiveFailures >= 3) {
                                    onError("Failed to parse GBNF after multiple retries. Loop halted.")
                                    break
                                }
                                delay(1000)
                            } catch (t: Throwable) {
                                AppLog.appendError("Loop crash", t)
                                onError(t.message ?: t.toString())
                                break
                            }
                        }
                    }
                }) { Text("Auto Loop") }
                Button(enabled = running, onClick = {
                    runningJob?.cancel()
                    runningJob = null
                    onStatus("Loop stopped.")
                }) { Text("Stop") }
                Button(enabled = !running && controller != null, onClick = {
                    controller?.reset()
                    controller = null
                    iterations.clear()
                    fullJsonHistory.clear()
                    onStatus("Session reset.")
                }) { Text("Reset") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showLiveRaw = true }, enabled = !showLiveRaw) { Text("Live JSON") }
                Button(onClick = { showLiveRaw = false }, enabled = showLiveRaw) { Text("Rendered") }
                Button(onClick = {
                    clipboard.setText(AnnotatedString(liveRawOutput.ifBlank { lastRawOutput }))
                    onStatus("Live JSON copied.")
                }) { Text("Copy JSON") }
            }
            if (liveRawOutput.isNotBlank() || lastRawOutput.isNotBlank()) {
                ThinkingAwareLiveOutput(
                    raw = liveRawOutput.ifBlank { lastRawOutput },
                    showRaw = showLiveRaw,
                    latest = iterations.firstOrNull(),
                    isGenerating = runningJob != null,
                    onCopy = { text ->
                        clipboard.setText(AnnotatedString(text))
                        onStatus("Copied.")
                    }
                )
            }
            MapElitesArchiveDashboard(refreshKey = iterations.size)
            Text("Historical Iterations", color = RText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Column(modifier = Modifier.height(300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (iterations.isEmpty()) {
                    Text("No iterations yet.", color = RMuted, fontSize = 12.sp)
                }
                iterations.forEach { item -> RefinerIterationCard(item) }
            }
        }
    }
}

@Composable
private fun RefinerSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, shown: String) {
    Column {
        Row { Text(label, color = RMuted, modifier = Modifier.weight(1f), fontSize = 12.sp); Text(shown, color = RText, fontSize = 12.sp) }
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max)
    }
}

@Composable
private fun RefinerIterationCard(item: RefinerIteration) {
    Card(colors = CardDefaults.cardColors(containerColor = RPanel2), border = BorderStroke(1.dp, RStroke)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Iteration ${item.iteration} • ${"%.1f".format(item.generationTimeSeconds)}s", color = RText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Lens: ${item.lens}", color = RMuted, fontSize = 11.sp)
            if (item.lensChanged) Text("Lens rotated due to repetition.", color = RDanger, fontSize = 11.sp)
            Text("REFINED", color = Color(0xFF86EFAC), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            LatexAwareText(item.refined, color = RText)
            Text("NEXT FOCUS", color = Color(0xFFC4B5FD), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            LatexAwareText(item.nextFocus, color = RText)
        }
    }
}