package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember

import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

private val RPanel = Color(0xFF111827)
private val RPanel2 = Color(0xFF0F172A)
private val RStroke = Color(0xFF263244)
private val RText = Color(0xFFE5E7EB)
private val RMuted = Color(0xFF94A3B8)
private val RDanger = Color(0xFFF87171)

// llama.cpp context operations must be serialized. Using general Dispatchers.IO can
// resume different native calls on different worker threads and risks unsafe overlap
// with the global native context. This dedicated single thread mirrors llama.cpp's
// own Android wrapper pattern and prevents UI ANR while keeping native calls ordered.
private val RefinerNativeDispatcher = Executors.newSingleThreadExecutor { runnable ->
    Thread(runnable, "recursive-refiner-native").apply { isDaemon = true }
}.asCoroutineDispatcher()

@Composable
fun RecursiveRefinerPanel(
    modelReady: Boolean,
    onStatus: (String) -> Unit,
    onError: (String?) -> Unit
) {
    val scope = AppScopes.main
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var grounding by remember { mutableStateOf("Describe your fixed original idea here. This grounding is evaluated once and kept in KV cache.") }
    var maxTokens by remember { mutableStateOf(180) }
    var temperature by remember { mutableStateOf(0.7f) }
    var topK by remember { mutableStateOf(40) }
    var topP by remember { mutableStateOf(0.9f) }
    var minP by remember { mutableStateOf(0.05f) }
    var repeatPenalty by remember { mutableStateOf(1.1f) }
    var strictKvCache by remember { mutableStateOf(false) }
    var thinkingMode by remember { mutableStateOf("OFF") }
    var webSearchEnabled by remember { mutableStateOf(false) }
    var cognitiveStage by remember { mutableStateOf(CognitiveStage.IDLE) }
    var controller by remember { mutableStateOf<RecursiveRefinerController?>(null) }
    var runningJob by remember { mutableStateOf<Job?>(null) }
    var liveProgress by remember { mutableStateOf("Idle") }
    var liveRawOutput by remember { mutableStateOf("") }
    var lastRawOutput by remember { mutableStateOf("") }
    var showLiveRaw by remember { mutableStateOf(true) }
    val iterations = remember { mutableStateListOf<RefinerIteration>() }

    val running = runningJob?.isActive == true

    Card(colors = CardDefaults.cardColors(containerColor = RPanel), border = BorderStroke(1.dp, RStroke), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Recursive Refiner", color = RText, fontWeight = FontWeight.Bold)
            Text(
                "Strict mode: native GBNF JSON grammar + optional KV cache erase. Controller owns the loop.",
                color = RMuted
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Progress: $liveProgress", color = Color(0xFF86EFAC), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    val latest = buildString {
                        appendLine("Progress: $liveProgress")
                        appendLine("Live raw output:")
                        appendLine(liveRawOutput)
                        if (iterations.isNotEmpty()) {
                            val item = iterations.first()
                            appendLine("\nLatest rendered iteration:")
                            appendLine("Iteration ${item.iteration}")
                            appendLine("Lens: ${item.lens}")
                            appendLine("Refined: ${item.refined}")
                            appendLine("Next focus: ${item.nextFocus}")
                        }
                    }
                    clipboard.setText(AnnotatedString(latest))
                    onStatus("Refiner output copied")
                }) { Text("Copy") }
            }

            OutlinedTextField(
                value = grounding,
                onValueChange = { grounding = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Grounding / original idea") },
                minLines = 4
            )

            RefinerSlider("Max tokens", maxTokens.toFloat(), 80f, 300f, { maxTokens = it.toInt() }, maxTokens.toString())
            RefinerSlider("Temperature", temperature, 0.05f, 1.2f, { temperature = it }, "%.2f".format(temperature))
            RefinerSlider("Top K", topK.toFloat(), 1f, 100f, { topK = it.toInt() }, topK.toString())
            RefinerSlider("Top P", topP, 0.1f, 1.0f, { topP = it }, "%.2f".format(topP))
            RefinerSlider("Min P", minP, 0.0f, 0.2f, { minP = it }, "%.2f".format(minP))
            RefinerSlider("Repeat penalty", repeatPenalty, 1.0f, 1.5f, { repeatPenalty = it }, "%.2f".format(repeatPenalty))

            Card(colors = CardDefaults.cardColors(containerColor = RPanel2), border = BorderStroke(1.dp, RStroke)) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Strict KV cache erasure", color = RText, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (strictKvCache) "ON: uses llama_memory_seq_rm; fastest but may crash on some hybrid/MoE models." else "OFF: compatibility mode; still native grammar JSON, but re-evaluates grounding each iteration for stability.",
                                color = RMuted
                            )
                        }
                        Switch(checked = strictKvCache, onCheckedChange = { strictKvCache = it })
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Thinking pre-stage", color = RText, fontWeight = FontWeight.SemiBold)
                        Text(
                            when (thinkingMode) {
                                "AUTO" -> "AUTO: allows a short free <think> stage if useful, then strict grammar JSON."
                                "FORCE" -> "FORCE: strongly asks for short thinking first, then strict grammar JSON. Slowest."
                                else -> "OFF: fastest/stablest; grammar JSON starts immediately and suppresses think tags."
                            },
                            color = RMuted
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { thinkingMode = "OFF" }, enabled = thinkingMode != "OFF") { Text("Off") }
                            Button(onClick = { thinkingMode = "AUTO" }, enabled = thinkingMode != "AUTO") { Text("Auto") }
                            Button(onClick = { thinkingMode = "FORCE" }, enabled = thinkingMode != "FORCE") { Text("Force") }
                        }
                    }
                }
            }

            CognitiveLoopMapV1Header(
                activeNodes = CognitiveOsMemory.getActiveNodesCount(),
                edgesCount = CognitiveOsMemory.getEdgesCount(),
                step = CognitiveOsMemory.getCurrentStep()
            )

            if (running || cognitiveStage != CognitiveStage.IDLE) {
                CognitiveStepTrackerView(currentStage = cognitiveStage, liveText = liveRawOutput)
            }

            WebSearchToggleSwitch(
                enabled = webSearchEnabled,
                onToggle = { 
                    webSearchEnabled = it
                    controller?.webSearchEnabled = it
                }
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = modelReady && !running && grounding.isNotBlank(), onClick = {
                    scope.launch {
                        try {
                            onError(null)
                            onStatus("Caching grounding on background thread...")
                            val c = RecursiveRefinerController(
                                context = context.applicationContext,
                                grounding = grounding,
                                maxTokens = maxTokens,
                                temperature = temperature,
                                topK = topK,
                                topP = topP,
                                minP = minP,
                                repeatPenalty = repeatPenalty,
                                strictKvCache = strictKvCache,
                                thinkingMode = thinkingMode
                            ).apply { this.webSearchEnabled = webSearchEnabled }
                            val job = scope.async(RefinerNativeDispatcher) { c.startSession() }
                            while (job.isActive) {
                                liveProgress = "Caching grounding..."
                                delay(300)
                            }
                            job.await()
                            liveProgress = "Grounding cached"
                            controller = c
                            iterations.clear()
                            onStatus("Recursive grounding cached once. Ready to refine.")
                        } catch (t: Throwable) {
                            AppLog.appendError("Recursive session failed", t)
                            onError(t.message ?: t.toString())
                            onStatus("Recursive session failed.")
                        }
                    }
                }) { Text("Start session") }

                Button(enabled = modelReady && !running && controller != null, onClick = {
                    scope.launch {
                        runCatching {
                            onStatus("Running one strict refinement iteration in background...")
                            val c = controller ?: error("Controller missing")
                            val startedAt = System.nanoTime()
                            cognitiveStage = CognitiveStage.PREFILL_GOALS
                            delay(150)
                            cognitiveStage = CognitiveStage.SCORING_ACT_R
                            delay(150)
                            cognitiveStage = CognitiveStage.VERIFYING_GATE
                            delay(150)
                            cognitiveStage = CognitiveStage.GENERATING_GBNF
                            liveRawOutput = lastRawOutput
                            val job = scope.async(RefinerNativeDispatcher) { c.runOneIteration() }
                            while (job.isActive) {
                                val elapsed = (System.nanoTime() - startedAt) / 1_000_000_000.0
                                val chars = NativeRecursiveRefiner.getProgressChars()
                                val tokens = NativeRecursiveRefiner.getProgressTokens()
                                val polledText = NativeRecursiveRefiner.getProgressText()
                                if (polledText.isNotBlank()) liveRawOutput = polledText
                                val timing = NativeRecursiveRefiner.getTimingSummary()
                                val tokSec = if (elapsed > 0.2) tokens / elapsed else 0.0
                                liveProgress = if (tokens == 0) {
                                    "Prefill/evaluating prompt... ${"%.1f".format(elapsed)}s • $timing"
                                } else {
                                    "Generating... $chars chars, $tokens tokens, ${"%.2f".format(tokSec)} tok/s, ${"%.1f".format(elapsed)}s • $timing"
                                }
                                delay(500)
                            }
                            val item = job.await()
                            cognitiveStage = CognitiveStage.REGISTERING_BLACKBOARD
                            delay(180)
                            cognitiveStage = CognitiveStage.SAVING_SNAPSHOT
                            delay(180)
                            cognitiveStage = CognitiveStage.COMPLETE
                            lastRawOutput = NativeRecursiveRefiner.getProgressText().ifBlank { liveRawOutput }
                            liveRawOutput = lastRawOutput
                            liveProgress = "Done: ${item.refined.length + item.nextFocus.length} chars in ${"%.1f".format(item.generationTimeSeconds)}s"
                            iterations.add(0, item)
                            onStatus("Iteration ${item.iteration} complete.")
                            onError(null)
                        }.onFailure {
                            AppLog.appendError("Refiner iteration failed", it)
                            onError(it.message ?: it.toString())
                            onStatus("Refiner iteration failed.")
                        }
                    }
                }) { Text("Run once") }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = modelReady && controller != null && !running, onClick = {
                    runningJob = scope.launch {
                        onStatus("Auto refiner loop running in background...")
                        val c = controller ?: return@launch
                        while (isActive) {
                            try {
                                val startedAt = System.nanoTime()
                                cognitiveStage = CognitiveStage.PREFILL_GOALS
                                delay(200)
                                cognitiveStage = CognitiveStage.SCORING_ACT_R
                                delay(200)
                                cognitiveStage = CognitiveStage.VERIFYING_GATE
                                delay(200)
                                cognitiveStage = CognitiveStage.GENERATING_GBNF
                                liveRawOutput = lastRawOutput
                                val job = scope.async(RefinerNativeDispatcher) { c.runOneIteration() }
                                while (job.isActive && isActive) {
                                    val elapsed = (System.nanoTime() - startedAt) / 1_000_000_000.0
                                    val chars = NativeRecursiveRefiner.getProgressChars()
                                    val tokens = NativeRecursiveRefiner.getProgressTokens()
                                    val polledText = NativeRecursiveRefiner.getProgressText()
                                    if (polledText.isNotBlank()) liveRawOutput = polledText
                                    val timing = NativeRecursiveRefiner.getTimingSummary()
                                    val tokSec = if (elapsed > 0.2) tokens / elapsed else 0.0
                                    liveProgress = if (tokens == 0) {
                                        "Prefill/evaluating prompt... ${"%.1f".format(elapsed)}s • $timing"
                                    } else {
                                        "Generating... $chars chars, $tokens tokens, ${"%.2f".format(tokSec)} tok/s, ${"%.1f".format(elapsed)}s • $timing"
                                    }
                                    delay(500)
                                }
                                val item = job.await()
                                cognitiveStage = CognitiveStage.REGISTERING_BLACKBOARD
                                delay(200)
                                cognitiveStage = CognitiveStage.SAVING_SNAPSHOT
                                delay(200)
                                cognitiveStage = CognitiveStage.COMPLETE
                                lastRawOutput = NativeRecursiveRefiner.getProgressText().ifBlank { liveRawOutput }
                                liveRawOutput = lastRawOutput
                                liveProgress = "Done: ${item.refined.length + item.nextFocus.length} chars in ${"%.1f".format(item.generationTimeSeconds)}s"
                                iterations.add(0, item)
                                onStatus("Auto loop: iteration ${item.iteration} complete. Waiting before next pass...")
                                delay(1200)
                            } catch (t: CancellationException) {
                                AppLog.append("Auto loop cancelled/stopped by user")
                                onStatus("Auto loop stopped.")
                                break
                            } catch (t: IllegalStateException) {
                                AppLog.append("Auto loop hiccup: " + t.message)
                                onStatus("Generation hiccup — retrying...")
                                delay(800)
                            } catch (t: Throwable) {
                                AppLog.appendError("Auto loop stopped on error", t)
                                onError(t.message ?: t.toString())
                                onStatus("Auto loop stopped on error.")
                                break
                            }
                        }
                    }
                }) { Text("Auto loop") }

                Button(enabled = running, onClick = {
                    runningJob?.cancel()
                    runningJob = null
                    onStatus("Auto loop stopped.")
                }) { Text("Stop") }

                Button(enabled = !running && controller != null, onClick = {
                    controller?.reset()
                    controller = null
                    iterations.clear()
                    onStatus("Recursive refiner reset.")
                }) { Text("Reset") }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showLiveRaw = true }, enabled = !showLiveRaw) { Text("Live JSON") }
                Button(onClick = { showLiveRaw = false }, enabled = showLiveRaw) { Text("Rendered") }
                Button(onClick = {
                    clipboard.setText(AnnotatedString(liveRawOutput.ifBlank { lastRawOutput }))
                    onStatus("Live JSON copied")
                }) { Text("Copy JSON") }
                Button(onClick = {
                    val item = iterations.firstOrNull()
                    val rendered = if (item != null) "Iteration ${item.iteration}\nLens: ${item.lens}\nRefined: ${item.refined}\nNext focus: ${item.nextFocus}" else "No rendered iteration yet."
                    clipboard.setText(AnnotatedString(rendered))
                    onStatus("Rendered output copied")
                }) { Text("Copy Rendered") }
            }

            if (liveRawOutput.isNotBlank() || lastRawOutput.isNotBlank()) {
                ThinkingAwareLiveOutput(
                    raw = liveRawOutput.ifBlank { lastRawOutput },
                    showRaw = showLiveRaw,
                    latest = iterations.firstOrNull(),
                    isGenerating = runningJob != null,
                    onCopy = { text ->
                        clipboard.setText(AnnotatedString(text))
                        onStatus("Live output copied")
                    }
                )
            }

            if (controller?.lastSearchQuery?.isNotEmpty() == true && runningJob != null) {
                WebSearchAnimationBadge(controller?.lastSearchQuery ?: "")
            }
            if (controller?.lastSearchResults?.isNotEmpty() == true) {
                WebSearchResultsBar(controller?.lastSearchResults ?: emptyList())
            }

            MapElitesArchiveDashboard(refreshKey = iterations.size)

            Text("Iterations", color = RText, fontWeight = FontWeight.SemiBold)
            Column(modifier = Modifier.height(420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (iterations.isEmpty()) {
                    Text("No iterations yet. Start session, then run once or auto loop.", color = RMuted)
                }
                iterations.forEach { item -> RefinerIterationCard(item) }
            }
        }
    }
}

@Composable
private fun RefinerSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, shown: String) {
    Column {
        Row { Text(label, color = RMuted, modifier = Modifier.weight(1f)); Text(shown, color = RText) }
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max)
    }
}

@Composable
private fun RefinerIterationCard(item: RefinerIteration) {
    Card(colors = CardDefaults.cardColors(containerColor = RPanel2), border = BorderStroke(1.dp, RStroke)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Iteration ${item.iteration} • ${"%.2f".format(item.generationTimeSeconds)}s", color = RText, fontWeight = FontWeight.Bold)
            Text("Lens: ${item.lens}", color = RMuted)
            if (item.lensChanged) Text("Lens rotated due to drift.", color = RDanger)
                        Text("REFINED", color = Color(0xFF86EFAC), fontWeight = FontWeight.Bold)
            LatexAwareText(item.refined, color = RText)
            Text("NEXT FOCUS", color = Color(0xFFC4B5FD), fontWeight = FontWeight.Bold)
            LatexAwareText(item.nextFocus, color = RText)
        }
    }
}
