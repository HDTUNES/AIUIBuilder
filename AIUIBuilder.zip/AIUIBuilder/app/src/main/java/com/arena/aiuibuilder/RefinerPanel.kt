package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

private val RPanel = Color(0xFF111827)
private val RPanel2 = Color(0xFF0F172A)
private val RStroke = Color(0xFF263244)
private val RText = Color(0xFFE5E7EB)
private val RMuted = Color(0xFF94A3B8)
private val RDanger = Color(0xFFF87171)

// llama.cpp context operations must be serialized. Using general Dispatchers.IO can
// resume different native calls on different worker threads and risks unsafe overlap
// with the global native context. This dedicated single thread mirrors llama.cpp's
// own Android wrapper pattern and prevents UI ANR while keeping native calls ordered.
private val RefinerNativeDispatcher = Executors.newSingleThreadExecutor { runnable ->
    Thread(runnable, "recursive-refiner-native").apply { isDaemon = true }
}.asCoroutineDispatcher()

@Composable
fun RecursiveRefinerPanel(
    modelReady: Boolean,
    onStatus: (String) -> Unit,
    onError: (String?) -> Unit
) {
    val scope = rememberCoroutineScope()
    var grounding by remember { mutableStateOf("Describe your fixed original idea here. This grounding is evaluated once and kept in KV cache.") }
    var maxTokens by remember { mutableStateOf(300) }
    var temperature by remember { mutableStateOf(0.7f) }
    var topK by remember { mutableStateOf(40) }
    var topP by remember { mutableStateOf(0.9f) }
    var minP by remember { mutableStateOf(0.05f) }
    var repeatPenalty by remember { mutableStateOf(1.1f) }
    var controller by remember { mutableStateOf<RecursiveRefinerController?>(null) }
    var runningJob by remember { mutableStateOf<Job?>(null) }
    val iterations = remember { mutableStateListOf<RefinerIteration>() }

    val running = runningJob?.isActive == true

    Card(colors = CardDefaults.cardColors(containerColor = RPanel), border = BorderStroke(1.dp, RStroke), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Recursive Refiner", color = RText, fontWeight = FontWeight.Bold)
            Text(
                "Strict mode: native GBNF JSON grammar + KV cache erase after grounding. Controller owns the loop.",
                color = RMuted
            )

            OutlinedTextField(
                value = grounding,
                onValueChange = { grounding = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Grounding / original idea") },
                minLines = 4
            )

            RefinerSlider("Max tokens", maxTokens.toFloat(), 100f, 500f, { maxTokens = it.toInt() }, maxTokens.toString())
            RefinerSlider("Temperature", temperature, 0.05f, 1.2f, { temperature = it }, "%.2f".format(temperature))
            RefinerSlider("Top K", topK.toFloat(), 1f, 100f, { topK = it.toInt() }, topK.toString())
            RefinerSlider("Top P", topP, 0.1f, 1.0f, { topP = it }, "%.2f".format(topP))
            RefinerSlider("Min P", minP, 0.0f, 0.2f, { minP = it }, "%.2f".format(minP))
            RefinerSlider("Repeat penalty", repeatPenalty, 1.0f, 1.5f, { repeatPenalty = it }, "%.2f".format(repeatPenalty))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = modelReady && !running && grounding.isNotBlank(), onClick = {
                    scope.launch {
                        try {
                            onError(null)
                            onStatus("Caching grounding on background thread...")
                            val c = RecursiveRefinerController(
                                grounding = grounding,
                                maxTokens = maxTokens,
                                temperature = temperature,
                                topK = topK,
                                topP = topP,
                                minP = minP,
                                repeatPenalty = repeatPenalty
                            )
                            withContext(RefinerNativeDispatcher) {
                                c.startSession()
                            }
                            controller = c
                            iterations.clear()
                            onStatus("Recursive grounding cached once. Ready to refine.")
                        } catch (t: Throwable) {
                            onError(t.message ?: t.toString())
                            onStatus("Recursive session failed.")
                        }
                    }
                }) { Text("Start session") }

                Button(enabled = modelReady && !running && controller != null, onClick = {
                    scope.launch {
                        runCatching {
                            onStatus("Running one strict refinement iteration in background...")
                            val c = controller ?: error("Controller missing")
                            val item = withContext(RefinerNativeDispatcher) {
                                c.runOneIteration()
                            }
                            iterations.add(0, item)
                            onStatus("Iteration ${item.iteration} complete.")
                            onError(null)
                        }.onFailure {
                            onError(it.message ?: it.toString())
                            onStatus("Refiner iteration failed.")
                        }
                    }
                }) { Text("Run once") }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = modelReady && controller != null && !running, onClick = {
                    runningJob = scope.launch {
                        onStatus("Auto refiner loop running in background...")
                        val c = controller ?: return@launch
                        while (isActive) {
                            try {
                                val item = withContext(RefinerNativeDispatcher) {
                                    c.runOneIteration()
                                }
                                iterations.add(0, item)
                                onStatus("Auto loop: iteration ${item.iteration} complete. Waiting before next pass...")
                                delay(1200)
                            } catch (t: Throwable) {
                                onError(t.message ?: t.toString())
                                onStatus("Auto loop stopped on error.")
                                break
                            }
                        }
                    }
                }) { Text("Auto loop") }

                Button(enabled = running, onClick = {
                    runningJob?.cancel()
                    runningJob = null
                    onStatus("Auto loop stopped.")
                }) { Text("Stop") }

                Button(enabled = !running && controller != null, onClick = {
                    controller?.reset()
                    controller = null
                    iterations.clear()
                    onStatus("Recursive refiner reset.")
                }) { Text("Reset") }
            }

            Text("Iterations", color = RText, fontWeight = FontWeight.SemiBold)
            Column(modifier = Modifier.height(420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (iterations.isEmpty()) {
                    Text("No iterations yet. Start session, then run once or auto loop.", color = RMuted)
                }
                iterations.forEach { item -> RefinerIterationCard(item) }
            }
        }
    }
}

@Composable
private fun RefinerSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, shown: String) {
    Column {
        Row { Text(label, color = RMuted, modifier = Modifier.weight(1f)); Text(shown, color = RText) }
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max)
    }
}

@Composable
private fun RefinerIterationCard(item: RefinerIteration) {
    Card(colors = CardDefaults.cardColors(containerColor = RPanel2), border = BorderStroke(1.dp, RStroke)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Iteration ${item.iteration} • ${"%.2f".format(item.generationTimeSeconds)}s", color = RText, fontWeight = FontWeight.Bold)
            Text("Lens: ${item.lens}", color = RMuted)
            if (item.lensChanged) Text("Lens rotated due to drift.", color = RDanger)
            Text("REFINED", color = Color(0xFF86EFAC), fontWeight = FontWeight.Bold)
            Text(item.refined, color = RText)
            Text("NEXT FOCUS", color = Color(0xFFC4B5FD), fontWeight = FontWeight.Bold)
            Text(item.nextFocus, color = RText)
        }
    }
}
