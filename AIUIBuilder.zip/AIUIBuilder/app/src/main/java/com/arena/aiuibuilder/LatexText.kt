package com.arena.aiuibuilder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * State-of-the-Art production math & mixed markdown rendering engine.
 * Renders mathematical expressions inline inside text flow or clean display blocks.
 * Eliminates disruptive popup cards, floating widgets, and separate math containers.
 */
@Composable
fun LatexAwareText(text: String, color: Color = Color(0xFFE5E7EB)) {
    val blocks = remember(text) { splitDisplayBlocks(text) }
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        blocks.forEach { block ->
            if (block.isDisplayMath) {
                val beautified = remember(block.text) { beautifyLatex(block.text) }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp, horizontal = 8.dp)
                ) {
                    Text(
                        text = beautified,
                        color = color,
                        fontFamily = FontFamily.Serif,
                        fontSize = 18.sp,
                        lineHeight = 26.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Start
                    )
                }
            } else if (block.text.isNotBlank()) {
                val lines = remember(block.text) { block.text.split("\n") }
                lines.forEach { line ->
                    if (line.isNotBlank()) {
                        val annotated = remember(line, color) { buildParagraphAnnotatedString(line, color) }
                        Text(
                            text = annotated,
                            modifier = Modifier.fillMaxWidth(),
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }
    }
}

data class DisplayBlock(val text: String, val isDisplayMath: Boolean)

fun splitDisplayBlocks(raw: String): List<DisplayBlock> {
    if (raw.isBlank()) return listOf(DisplayBlock(raw, false))
    val result = mutableListOf<DisplayBlock>()
    var cursor = 0
    while (cursor < raw.length) {
        val candidates = listOf("$$", "\\[").mapNotNull { open ->
            val idx = raw.indexOf(open, cursor)
            if (idx >= 0) open to idx else null
        }.sortedBy { it.second }
        if (candidates.isEmpty()) {
            result += DisplayBlock(raw.substring(cursor), false)
            break
        }
        val (open, idx) = candidates.first()
        val close = if (open == "$$") "$$" else "\\]"
        if (idx > cursor) result += DisplayBlock(raw.substring(cursor, idx), false)
        val start = idx + open.length
        val end = raw.indexOf(close, start)
        if (end < 0) {
            result += DisplayBlock(raw.substring(idx), false)
            break
        }
        result += DisplayBlock(raw.substring(start, end).trim(), true)
        cursor = end + close.length
    }
    return result
}

sealed class InlineSpan(val text: String) {
    class Plain(text: String) : InlineSpan(text)
    class Math(text: String) : InlineSpan(text)
    class Bold(text: String) : InlineSpan(text)
    class Code(text: String) : InlineSpan(text)
}

fun tokenizeInline(line: String): List<InlineSpan> {
    val spans = mutableListOf<InlineSpan>()
    var cursor = 0
    val n = line.length
    while (cursor < n) {
        val cands = listOf("$", "\\(", "`", "**").mapNotNull { open ->
            val idx = line.indexOf(open, cursor)
            if (idx < 0) return@mapNotNull null
            if (open == "$" && idx + 1 < n && line[idx + 1] == '$') return@mapNotNull null
            Triple(idx, open, when (open) { "$" -> "$"; "\\(" -> "\\)"; "`" -> "`"; else -> "**" })
        }.sortedBy { it.first }
        if (cands.isEmpty()) {
            spans += InlineSpan.Plain(line.substring(cursor))
            break
        }
        val (idx, open, close) = cands.first()
        if (idx > cursor) spans += InlineSpan.Plain(line.substring(cursor, idx))
        val start = idx + open.length
        val end = line.indexOf(close, start)
        if (end < 0) {
            spans += InlineSpan.Plain(line.substring(idx))
            break
        }
        val inner = line.substring(start, end)
        when (open) {
            "$" -> spans += InlineSpan.Math(inner)
            "\\(" -> spans += InlineSpan.Math(inner)
            "`" -> spans += InlineSpan.Code(inner)
            else -> spans += InlineSpan.Bold(inner)
        }
        cursor = end + close.length
    }
    return spans
}

fun buildParagraphAnnotatedString(line: String, baseColor: Color): AnnotatedString {
    var textToParse = line
    var prefix = ""
    var isHeader = false
    when {
        line.startsWith("### ") -> { isHeader = true; textToParse = line.removePrefix("### ") }
        line.startsWith("## ") -> { isHeader = true; textToParse = line.removePrefix("## ") }
        line.startsWith("# ") -> { isHeader = true; textToParse = line.removePrefix("# ") }
        line.startsWith("- ") -> { prefix = "•  "; textToParse = line.removePrefix("- ") }
        line.startsWith("* ") -> { prefix = "•  "; textToParse = line.removePrefix("* ") }
    }

    val spans = tokenizeInline(textToParse)
    return buildAnnotatedString {
        if (prefix.isNotEmpty()) {
            withStyle(SpanStyle(color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)) {
                append(prefix)
            }
        }
        spans.forEach { span ->
            when (span) {
                is InlineSpan.Plain -> {
                    withStyle(SpanStyle(color = baseColor, fontWeight = if (isHeader) FontWeight.Bold else FontWeight.Normal, fontSize = if (isHeader) 16.sp else 14.sp)) {
                        append(span.text)
                    }
                }
                is InlineSpan.Bold -> {
                    withStyle(SpanStyle(color = baseColor, fontWeight = FontWeight.Bold)) {
                        append(span.text)
                    }
                }
                is InlineSpan.Code -> {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = Color(0xFFF8FAFC), background = Color(0xFF161616))) {
                        append(" ${span.text} ")
                    }
                }
                is InlineSpan.Math -> {
                    val beautified = beautifyLatex(span.text)
                    withStyle(SpanStyle(fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic, color = baseColor, fontSize = if (isHeader) 18.sp else 16.sp, fontWeight = FontWeight.SemiBold)) {
                        append(beautified)
                    }
                }
            }
        }
    }
}

fun beautifyLatex(src: String): String {
    var s = src.trim()

    // Multi-line matrix / cases formatting
    s = s.replace(Regex("\\\\begin\\{[pbbv]?matrix\\}"), "[ ")
    s = s.replace(Regex("\\\\end\\{[pbbv]?matrix\\}"), " ]")
    s = s.replace(Regex("\\\\begin\\{cases\\}"), "{ ")
    s = s.replace(Regex("\\\\end\\{cases\\}"), "")
    s = s.replace("\\\\", "\n  ")

    val symbols = mapOf(
        "\\alpha" to "α", "\\beta" to "β", "\\gamma" to "γ", "\\Gamma" to "Γ",
        "\\delta" to "δ", "\\Delta" to "Δ", "\\epsilon" to "ε", "\\varepsilon" to "ε",
        "\\zeta" to "ζ", "\\eta" to "η", "\\theta" to "θ", "\\Theta" to "Θ",
        "\\iota" to "ι", "\\kappa" to "κ", "\\lambda" to "λ", "\\Lambda" to "Λ",
        "\\mu" to "μ", "\\nu" to "ν", "\\xi" to "ξ", "\\Xi" to "Ξ",
        "\\pi" to "π", "\\Pi" to "Π", "\\rho" to "ρ", "\\sigma" to "σ",
        "\\Sigma" to "Σ", "\\tau" to "τ", "\\upsilon" to "υ", "\\phi" to "φ",
        "\\Phi" to "Φ", "\\varphi" to "φ", "\\chi" to "χ", "\\psi" to "ψ",
        "\\Psi" to "Ψ", "\\omega" to "ω", "\\Omega" to "Ω",
        "\\int" to "∫", "\\iint" to "∬", "\\iiint" to "∭", "\\oint" to "∮",
        "\\sum" to "∑", "\\prod" to "∏", "\\lim" to "lim", "\\partial" to "∂",
        "\\nabla" to "∇", "\\infty" to "∞", "\\times" to "×", "\\cdot" to "·",
        "\\pm" to "±", "\\mp" to "∓", "\\leq" to "≤", "\\le" to "≤",
        "\\geq" to "≥", "\\ge" to "≥", "\\neq" to "≠", "\\ne" to "≠",
        "\\approx" to "≈", "\\equiv" to "≡", "\\to" to "→", "\\rightarrow" to "→",
        "\\leftarrow" to "←", "\\leftrightarrow" to "↔", "\\implies" to "⟹",
        "\\iff" to "⟺", "\\forall" to "∀", "\\exists" to "∃", "\\in" to "∈",
        "\\notin" to "∉", "\\subset" to "⊂", "\\subseteq" to "⊆", "\\dots" to "…",
        "\\cdots" to "…",
        "\\sin" to "sin", "\\cos" to "cos", "\\tan" to "tan", "\\ln" to "ln",
        "\\log" to "log", "\\exp" to "exp", "\\sec" to "sec", "\\csc" to "csc",
        "\\cot" to "cot", "\\arcsin" to "arcsin", "\\arccos" to "arccos", "\\arctan" to "arctan",
        "\\sinh" to "sinh", "\\cosh" to "cosh", "\\tanh" to "tanh",
        "\\," to " ", "\\;" to "  ", "\\:" to " ", "\\!" to "", "\\quad" to "    ", "\\qquad" to "        "
    )
    symbols.forEach { (k, v) -> s = s.replace(k, v) }

    val simpleFracs = mapOf(
        "\\frac{1}{2}" to "½", "\\frac{1}{3}" to "⅓", "\\frac{2}{3}" to "⅔",
        "\\frac{1}{4}" to "¼", "\\frac{3}{4}" to "¾", "\\frac{1}{5}" to "⅕",
        "\\frac{2}{5}" to "⅖", "\\frac{3}{5}" to "⅗", "\\frac{4}{5}" to "⅘",
        "\\frac{1}{6}" to "⅙", "\\frac{5}{6}" to "⅚", "\\frac{1}{8}" to "⅛",
        "\\frac{3}{8}" to "⅜", "\\frac{5}{8}" to "⅝", "\\frac{7}{8}" to "⅞"
    )
    simpleFracs.forEach { (k, v) -> s = s.replace(k, v) }

    var prev = ""
    while (prev != s && s.contains("\\frac{")) {
        prev = s
        s = Regex("\\\\frac\\{([^{}]+)\\}\\{([^{}]+)\\}").replace(s) { m -> "(${m.groupValues[1]})⁄(${m.groupValues[2]})" }
    }

    s = Regex("\\\\sqrt\\{([^{}]+)\\}").replace(s) { m -> "√(${m.groupValues[1]})" }
    s = Regex("\\\\vec\\{([^{}]+)\\}").replace(s) { m -> "${m.groupValues[1]}⃗" }
    s = Regex("\\\\mathbf\\{([^{}]+)\\}").replace(s) { m -> m.groupValues[1] }
    s = Regex("\\\\hat\\{([^{}]+)\\}").replace(s) { m -> "${m.groupValues[1]}̂" }
    s = Regex("\\\\bar\\{([^{}]+)\\}").replace(s) { m -> "${m.groupValues[1]}̄" }

    s = Regex("\\^\\{([^{}]+)\\}").replace(s) { m -> toSuper(m.groupValues[1]) }
    s = Regex("_\\{([^{}]+)\\}").replace(s) { m -> toSub(m.groupValues[1]) }
    s = Regex("\\^([A-Za-z0-9+-])").replace(s) { m -> toSuper(m.groupValues[1]) }
    s = Regex("_([A-Za-z0-9+-])").replace(s) { m -> toSub(m.groupValues[1]) }

    return s
}

private fun toSuper(s: String): String = s.map { c ->
    when (c) {
        '0' -> '⁰'; '1' -> '¹'; '2' -> '²'; '3' -> '³'; '4' -> '⁴'; '5' -> '⁵'; '6' -> '⁶'; '7' -> '⁷'; '8' -> '⁸'; '9' -> '⁹'
        '+' -> '⁺'; '-' -> '⁻'; '=' -> '⁼'; '(' -> '⁽'; ')' -> '⁾'; 'n' -> 'ⁿ'; 'i' -> 'ⁱ'; 'x' -> 'ˣ'; 'y' -> 'ʸ'; 'k' -> 'ᵏ'; 'm' -> 'ᵐ'
        else -> c
    }
}.joinToString("")

private fun toSub(s: String): String = s.map { c ->
    when (c) {
        '0' -> '₀'; '1' -> '₁'; '2' -> '₂'; '3' -> '₃'; '4' -> '₄'; '5' -> '₅'; '6' -> '₆'; '7' -> '₇'; '8' -> '₈'; '9' -> '₉'
        '+' -> '₊'; '-' -> '₋'; '=' -> '₌'; '(' -> '₍'; ')' -> '₎'; 'a' -> 'ₐ'; 'e' -> 'ₑ'; 'h' -> 'ₕ'; 'i' -> 'ᵢ'; 'j' -> 'ⱼ'; 'k' -> 'ₖ'; 'l' -> 'ₗ'; 'm' -> 'ₘ'; 'n' -> 'ₙ'; 'o' -> 'ₒ'; 'p' -> 'ₚ'; 'r' -> 'ᵣ'; 's' -> 'ₛ'; 't' -> 'ₜ'; 'u' -> 'ᵤ'; 'v' -> 'ᵥ'; 'x' -> 'ₓ'
        else -> c
    }
}.joinToString("")
