package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Stable production-lite math rendering.
 * Detects common LaTeX delimiters and displays formulas as styled math blocks.
 * It also beautifies common symbols/superscripts/subscripts without heavy JS deps.
 */
@Composable
fun LatexAwareText(text: String, color: Color = Color(0xFFE5E7EB)) {
    val parts = splitLatexParts(text)
    Column {
        parts.forEach { part ->
            if (part.isFormula) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220)),
                    border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Text(
                        text = beautifyLatex(part.content),
                        color = Color(0xFFBAE6FD),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            } else if (part.content.isNotBlank()) {
                Text(part.content, color = color)
            }
        }
    }
}

data class LatexPart(val content: String, val isFormula: Boolean)

fun splitLatexParts(input: String): List<LatexPart> {
    if (input.isBlank()) return listOf(LatexPart(input, false))
    val result = mutableListOf<LatexPart>()
    var cursor = 0
    while (cursor < input.length) {
        val candidates = listOf("$$", "\\[", "\\(", "$").mapNotNull { open ->
            val idx = input.indexOf(open, cursor)
            if (idx >= 0) open to idx else null
        }.sortedBy { it.second }
        if (candidates.isEmpty()) {
            result += LatexPart(input.substring(cursor), false)
            break
        }
        val (open, idx) = candidates.first()
        val close = when (open) { "$$" -> "$$"; "\\[" -> "\\]"; "\\(" -> "\\)"; else -> "$" }
        if (idx > cursor) result += LatexPart(input.substring(cursor, idx), false)
        val start = idx + open.length
        val end = input.indexOf(close, start)
        if (end < 0) {
            result += LatexPart(input.substring(idx), false)
            break
        }
        result += LatexPart(input.substring(start, end).trim(), true)
        cursor = end + close.length
    }
    return result
}

fun beautifyLatex(src: String): String {
    var s = src.trim()
    val replacements = mapOf(
        "\\alpha" to "α", "\\beta" to "β", "\\gamma" to "γ", "\\delta" to "δ",
        "\\epsilon" to "ε", "\\theta" to "θ", "\\lambda" to "λ", "\\mu" to "μ",
        "\\pi" to "π", "\\sigma" to "σ", "\\omega" to "ω",
        "\\Delta" to "Δ", "\\Sigma" to "Σ", "\\Omega" to "Ω",
        "\\times" to "×", "\\cdot" to "·", "\\pm" to "±",
        "\\leq" to "≤", "\\geq" to "≥", "\\neq" to "≠", "\\approx" to "≈",
        "\\infty" to "∞", "\\rightarrow" to "→", "\\to" to "→"
    )
    replacements.forEach { (k, v) -> s = s.replace(k, v) }
    s = Regex("\\\\frac\\{([^{}]+)\\}\\{([^{}]+)\\}").replace(s) { m -> "(${m.groupValues[1]})⁄(${m.groupValues[2]})" }
    s = Regex("\\^\\{([^{}]+)\\}").replace(s) { m -> toSuper(m.groupValues[1]) }
    s = Regex("_\\{([^{}]+)\\}").replace(s) { m -> toSub(m.groupValues[1]) }
    s = Regex("\^([A-Za-z0-9])").replace(s) { m -> toSuper(m.groupValues[1]) }
    s = Regex("_([A-Za-z0-9])").replace(s) { m -> toSub(m.groupValues[1]) }
    return s
}

private fun toSuper(s: String): String = s.map { c ->
    when (c) {
        '0' -> '⁰'; '1' -> '¹'; '2' -> '²'; '3' -> '³'; '4' -> '⁴'; '5' -> '⁵'; '6' -> '⁶'; '7' -> '⁷'; '8' -> '⁸'; '9' -> '⁹'
        '+' -> '⁺'; '-' -> '⁻'; '=' -> '⁼'; '(' -> '⁽'; ')' -> '⁾'; 'n' -> 'ⁿ'; 'i' -> 'ⁱ'
        else -> c
    }
}.joinToString("")

private fun toSub(s: String): String = s.map { c ->
    when (c) {
        '0' -> '₀'; '1' -> '₁'; '2' -> '₂'; '3' -> '₃'; '4' -> '₄'; '5' -> '₅'; '6' -> '₆'; '7' -> '₇'; '8' -> '₈'; '9' -> '₉'
        '+' -> '₊'; '-' -> '₋'; '=' -> '₌'; '(' -> '₍'; ')' -> '₎'; 'a' -> 'ₐ'; 'e' -> 'ₑ'; 'h' -> 'ₕ'; 'i' -> 'ᵢ'; 'j' -> 'ⱼ'; 'k' -> 'ₖ'; 'l' -> 'ₗ'; 'm' -> 'ₘ'; 'n' -> 'ₙ'; 'o' -> 'ₒ'; 'p' -> 'ₚ'; 'r' -> 'ᵣ'; 's' -> 'ₛ'; 't' -> 'ₜ'; 'u' -> 'ᵤ'; 'v' -> 'ᵥ'; 'x' -> 'ₓ'
        else -> c
    }
}.joinToString("")
