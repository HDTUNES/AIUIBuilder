package com.arena.aiuibuilder

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID
import kotlin.math.ln
import kotlin.math.pow

// ============================================================================
// SEMANTIC MEMORY — long-term facts, concepts, principles, causal relations
// ============================================================================

@Serializable
data class SemanticNode(
    val id: String,
    val label: String,
    val content: String,
    val nodeType: String = "concept", // concept | principle | fact | claim | problem | solution
    var importance: Float = 0.85f,
    var confidence: Float = 0.90f,
    var createdIter: Int = 1,
    var lastTouchIter: Int = 1,
    var touchCount: Int = 1,
    var newSinceTouch: Int = 0,        // interference counter: how many new memories added since last touch
    var status: String = "ACTIVE" // ACTIVE | ARCHIVED | CONSOLIDATED
)

@Serializable
data class SemanticEdge(
    val sourceId: String,
    val targetId: String,
    val relation: String, // SUPPORTS | CONTRADICTS | DEPENDS_ON | ISA | PART_OF | CAUSES | RELATED
    var weight: Float = 1.0f
)

object SemanticMemory {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private const val STORE_FILE = "semantic_memory.json"

    private val nodes = mutableMapOf<String, SemanticNode>()
    private val edges = mutableListOf<SemanticEdge>()
    private var currentIter = 1

    fun load(context: Context) {
        val f = File(context.filesDir, STORE_FILE)
        if (!f.exists()) return
        runCatching {
            val snap = json.decodeFromString<SemanticMemorySnapshot>(f.readText())
            currentIter = snap.iter
            nodes.clear(); nodes.putAll(snap.nodes)
            edges.clear(); edges.addAll(snap.edges)
            AppLog.logStructured("INFO", "SEMANTIC", currentIter, "Loaded semantic memory", mapOf("nodes" to nodes.size, "edges" to edges.size))
        }
    }

    fun save(context: Context) {
        runCatching {
            val snap = SemanticMemorySnapshot(currentIter, nodes.toMap(), edges.toList())
            File(context.filesDir, STORE_FILE).writeText(json.encodeToString(snap))
        }
    }

    fun initSession(context: Context, grounding: String) {
        load(context)
        if (nodes.isNotEmpty()) {
            AppLog.logStructured("INFO", "SEMANTIC", currentIter, "Resuming semantic memory", mapOf("nodes" to nodes.size))
            return
        }
        currentIter = 1
        nodes.clear(); edges.clear()
        addNode("n_root", "Root topic", grounding, "problem", importance = 1.0f, confidence = 1.0f)
    }

    fun addNode(id: String, label: String, content: String, type: String = "concept", importance: Float = 0.85f, confidence: Float = 0.90f): SemanticNode {
        currentIter += 1

        // Interference: every new memory weakens all other active memories slightly.
        nodes.values.forEach { it.newSinceTouch += 1 }

        val node = SemanticNode(id, label, content, type, importance, confidence, currentIter, currentIter, 1, 0)
        nodes[id] = node

        // Archive nodes that have fallen below activation threshold due to interference.
        pruneWeakMemories()

        return node
    }

    /**
     * Reinforce a memory: called when the idea is retrieved or used successfully.
     * This mimics the brain strengthening synapses through repetition/use.
     */
    fun reinforce(id: String) {
        nodes[id]?.let { node ->
            node.touchCount += 1
            node.lastTouchIter = currentIter
            node.newSinceTouch = 0
            node.importance = (node.importance + 0.03f).coerceAtMost(1.0f)
            node.confidence = (node.confidence + 0.02f).coerceAtMost(1.0f)
            if (node.status == "ARCHIVED") node.status = "ACTIVE"
        }
    }

    private fun pruneWeakMemories(threshold: Float = 0.12f) {
        nodes.values.filter { it.status == "ACTIVE" && retrievalScore(it) < threshold }.forEach { node ->
            node.status = "ARCHIVED"
            AppLog.logStructured("INFO", "SEMANTIC", currentIter, "Archived weak memory", mapOf("id" to node.id, "label" to node.label.take(20)))
        }
    }

    fun addEdge(sourceId: String, targetId: String, relation: String, weight: Float = 1.0f) {
        edges.add(SemanticEdge(sourceId, targetId, relation, weight))
        touchNode(targetId)
    }

    fun touchNode(id: String) {
        reinforce(id)
    }

    /**
     * Brain-like activation score.
     * Combines importance, interference-based decay, frequency bonus, structural centrality,
     * and dynamic spreading activation (blueprint Part 5.1).
     */
    fun retrievalScore(node: SemanticNode, query: String = "", lambdaCentrality: Float = 0.25f, spreadingBoost: Float = 0f): Float {
        if (node.status != "ACTIVE") return -1f

        // Interference-based decay: the more new memories since last touch, the more it fades.
        val interference = (node.newSinceTouch + 1).toFloat()
        val recency = (1f / (1f + 0.08f * interference)).coerceIn(0.05f, 1f)

        // Frequency bonus: repeated ideas are easier to recall.
        val frequency = 1f + ln((node.touchCount + 1).toFloat())

        // Relevance to current query.
        val relevance = if (query.isBlank()) 1f else overlapScore(node.content, query.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet())

        // Structural centrality: foundational nodes with many dependents are harder to forget.
        val descendantCount = edges.count { it.targetId == node.id && it.relation in setOf("SUPPORTS", "DEPENDS_ON", "CAUSES") }
        val centrality = lambdaCentrality * ln(1f + descendantCount)

        // Spreading activation (Collins & Loftus, 1975 / Hebbian assemblies):
        // touching one memory "lights up" its connected neighbors instead of scoring
        // every node in total isolation.
        val activation = node.importance * node.confidence * recency * frequency * relevance + centrality + spreadingBoost
        return activation.coerceIn(0f, 2f)
    }

    /**
     * Spreading activation (Collins & Loftus, 1975 / Hebbian assemblies).
     * Returns a bonus per nodeId, computed by BFS from the currently-active seed set,
     * with activation halving at each hop and following edge weight. This is what
     * makes touching one memory "light up" its connected neighbors — the "constellation"
     * effect described in the architecture blueprint.
     */
    fun computeSpreadingActivation(
        seedIds: Collection<String>,
        maxHops: Int = 2,
        decayPerHop: Float = 0.5f
    ): Map<String, Float> {
        val boost = mutableMapOf<String, Float>()
        var frontier = seedIds.associateWith { 1.0f }
        var hop = 0
        while (frontier.isNotEmpty() && hop < maxHops) {
            val next = mutableMapOf<String, Float>()
            for ((nodeId, activation) in frontier) {
                // Outgoing edges
                edges.filter { it.sourceId == nodeId }.forEach { edge ->
                    val carried = activation * edge.weight * decayPerHop
                    if (carried > 0.02f) {
                        boost[edge.targetId] = (boost[edge.targetId] ?: 0f) + carried
                        next[edge.targetId] = maxOf(next[edge.targetId] ?: 0f, carried)
                    }
                }
                // Incoming edges (activation should spread both directions, per Collins & Loftus)
                edges.filter { it.targetId == nodeId }.forEach { edge ->
                    val carried = activation * edge.weight * decayPerHop
                    if (carried > 0.02f) {
                        boost[edge.sourceId] = (boost[edge.sourceId] ?: 0f) + carried
                        next[edge.sourceId] = maxOf(next[edge.sourceId] ?: 0f, carried)
                    }
                }
            }
            frontier = next
            hop += 1
        }
        seedIds.forEach { boost.remove(it) } // don't boost the seeds themselves
        return boost
    }

    fun retrieveRelevant(query: String, topK: Int = 5): List<SemanticNode> {
        val queryWords = query.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()

        // Spreading activation: seed from whatever is currently active in working memory.
        val seedIds = WorkingMemory.activeNodeIds()
        val spreadBoosts = computeSpreadingActivation(seedIds)

        // Pre-compute relevance scores via the RelevanceScorerProvider (blueprint 5.2).
        // This avoids making retrievalScore() suspend while still using the scorer.
        // For now, the default WordOverlapRelevanceScorer is synchronous-equivalent.
        val relevanceCache = mutableMapOf<String, Float>()
        // Run synchronously since WordOverlapRelevanceScorer doesn't actually suspend
        val scorer = RelevanceScorerProvider.active
        val activeNodes = nodes.values.filter { it.status == "ACTIVE" }
        // Use kotlinx.coroutines.runBlocking is not ideal; instead compute inline for WordOverlap.
        // For the default scorer this is fine; if an async embedding scorer is swapped in,
        // the caller (CognitiveEngine.reason) should pre-compute and pass scores.
        activeNodes.forEach { node ->
            relevanceCache[node.id] = if (query.isBlank()) 1f else {
                // Direct call to word-overlap (same as overlapScore) for now.
                // When embeddings are added, this will be replaced.
                overlapScore(node.content, queryWords)
            }
        }

        val retrieved = activeNodes
            .map { it to retrievalScore(it, query, spreadingBoost = spreadBoosts[it.id] ?: 0f) }
            .filter { it.second > 0.15f }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }

        // Reinforce retrieved memories (use strengthens recall).
        retrieved.forEach { reinforce(it.id) }
        return retrieved
    }

    fun getNode(id: String): SemanticNode? = nodes[id]
    fun getEdges(fromId: String): List<SemanticEdge> = edges.filter { it.sourceId == fromId }
    fun getAllActive(): List<SemanticNode> = nodes.values.filter { it.status == "ACTIVE" }
    fun getCurrentIter(): Int = currentIter

    fun firstPrinciplesChain(targetId: String, maxDepth: Int = 4): List<SemanticNode> {
        val chain = mutableListOf<SemanticNode>()
        var current = nodes[targetId] ?: return chain
        var depth = 0
        while (depth < maxDepth) {
            chain.add(current)
            val causeEdge = edges.find { it.sourceId == current.id && it.relation in setOf("DEPENDS_ON", "CAUSES", "PART_OF") }
            current = causeEdge?.let { nodes[it.targetId] } ?: break
            depth++
        }
        return chain
    }

    private fun overlapScore(text: String, queryWords: Set<String>): Float {
        val textWords = text.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        if (textWords.isEmpty() || queryWords.isEmpty()) return 0f
        return textWords.intersect(queryWords).size.toFloat() / textWords.union(queryWords).size.toFloat()
    }
}

@Serializable
data class SemanticMemorySnapshot(
    val iter: Int,
    val nodes: Map<String, SemanticNode>,
    val edges: List<SemanticEdge>
)

// ============================================================================
// EPISODIC MEMORY — recent reasoning traces, replayed for consolidation
// ============================================================================

@Serializable
data class EpisodicTrace(
    val id: String = UUID.randomUUID().toString(),
    val iter: Int,
    val goal: String,
    val operator: String,
    val input: String,
    val output: String,
    val surprise: Float,
    val success: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

object EpisodicMemory {
    private val buffer = ArrayDeque<EpisodicTrace>(32)

    fun record(goal: String, operator: String, input: String, output: String, surprise: Float, success: Boolean) {
        if (buffer.size >= 32) buffer.removeFirst()
        buffer.addLast(EpisodicTrace(iter = SemanticMemory.getCurrentIter(), goal = goal, operator = operator, input = input, output = output, surprise = surprise, success = success))
    }

    fun replayHighSurprise(n: Int = 3): List<EpisodicTrace> =
        buffer.sortedByDescending { it.surprise }.take(n)

    /**
     * Replay high-surprise traces as a prompt-safe string (blueprint Part 6 rec 3).
     * Each trace is truncated to prevent accidental prompt overflow when this
     * output is dumped into an LLM prompt.
     */
    fun replayHighSurpriseAsString(n: Int = 3, maxCharsPerTrace: Int = 120): String =
        replayHighSurprise(n).joinToString("\n") { t ->
            "Operator: ${t.operator} | Goal: ${t.goal.take(40)} | Output: ${t.output.take(maxCharsPerTrace)} | Surprise: ${"%.2f".format(t.surprise)}"
        }

    fun replaySimilar(goal: String, n: Int = 3): List<EpisodicTrace> {
        val goalWords = goal.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        return buffer.map { it to overlapScore(it.goal, goalWords) }
            .filter { it.second > 0.1f }
            .sortedByDescending { it.second }
            .take(n)
            .map { it.first }
    }

    fun all(): List<EpisodicTrace> = buffer.toList()

    private fun overlapScore(text: String, words: Set<String>): Float {
        val textWords = text.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        if (textWords.isEmpty() || words.isEmpty()) return 0f
        return textWords.intersect(words).size.toFloat() / textWords.union(words).size.toFloat()
    }
}

// ============================================================================
// PROCEDURAL MEMORY — reusable skills / mini-strategies
// ============================================================================

@Serializable
data class ProceduralSkill(
    val id: String,
    val name: String,
    val condition: String, // when to apply this skill
    val steps: List<String>,
    val successCount: Int = 0,
    val failureCount: Int = 0
)

object ProceduralMemory {
    private val skills = mutableListOf<ProceduralSkill>()

    fun initDefaults() {
        if (skills.isNotEmpty()) return
        skills.addAll(listOf(
            ProceduralSkill("sk_decompose", "Decompose complex problem", "problem has multiple parts or feels confusing", listOf("Identify the unknown", "Break into independent sub-problems", "Solve each sub-problem", "Integrate results")),
            ProceduralSkill("sk_first_principles", "Reduce to first principles", "problem feels too abstract or unfamiliar", listOf("Ask what caused this problem", "Ask what problem this concept solves", "Find the simplest base case", "Rebuild from the base case")),
            ProceduralSkill("sk_analogize", "Cross-domain analogy", "domain is unfamiliar", listOf("Identify structural pattern", "Search memory for matching pattern in another domain", "Map components across domains", "Test mapping validity")),
            ProceduralSkill("sk_verify", "Reality verification", "claim is quantitative or falsifiable", listOf("Generate testable prediction", "Run code or search web", "Compare prediction with evidence", "Adjust confidence")),
            ProceduralSkill("sk_chunk", "Chunk into manageable units", "problem is too large to hold in working memory", listOf("Identify natural boundaries", "Name each chunk", "Solve one chunk at a time", "Link chunks with relations"))
        ))
    }

    fun allSkills(): List<ProceduralSkill> = skills.toList()

    fun retrieveSkill(goal: String): List<ProceduralSkill> {
        val goalWords = goal.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        return skills.map { it to overlapScore(it.condition, goalWords) }
            .filter { it.second > 0.1f }
            .sortedByDescending { it.second }
            .take(3)
            .map { it.first }
    }

    fun extractSkillFromTrace(trace: EpisodicTrace) {
        if (!trace.success) return
        // Simple skill extraction: summarize the operator sequence
        val name = "skill_${trace.operator}_${System.currentTimeMillis()}"
        val skill = ProceduralSkill(name, "Extracted skill for ${trace.goal.take(30)}", trace.goal.take(80), listOf(trace.operator))
        skills.add(0, skill)
        if (skills.size > 64) skills.removeLast()
    }

    /**
     * Add an externally-constructed skill (e.g. from LLM consolidation, blueprint Part 4.5).
     */
    fun addSkill(skill: ProceduralSkill) {
        skills.add(0, skill)
        if (skills.size > 64) skills.removeLast()
    }

    private fun overlapScore(text: String, words: Set<String>): Float {
        val textWords = text.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        if (textWords.isEmpty() || words.isEmpty()) return 0f
        return textWords.intersect(words).size.toFloat() / textWords.union(words).size.toFloat()
    }
}

// ============================================================================
// META-MEMORY — what the system knows it knows / doesn't know
// ============================================================================

object MetaMemory {
    private val confidenceMap = mutableMapOf<String, Float>()

    fun updateConfidence(nodeId: String, verified: Boolean) {
        val current = confidenceMap[nodeId] ?: 0.9f
        confidenceMap[nodeId] = if (verified) (current + 0.05f).coerceAtMost(1.0f) else (current - 0.15f).coerceAtLeast(0.1f)
    }

    fun getConfidence(nodeId: String): Float = confidenceMap[nodeId] ?: 0.9f

    fun detectKnowledgeGap(query: String, retrieved: List<SemanticNode>): Boolean {
        if (retrieved.isEmpty()) return true
        val avgScore = retrieved.map { SemanticMemory.retrievalScore(it, query) }.average()
        return avgScore < 0.25
    }
}

// ============================================================================
// WORKING MEMORY — tiny, bounded, active memory window (like human consciousness)
// ============================================================================

object WorkingMemory {
    private const val MAX_ITEMS = 5
    private const val MAX_CHARS = 800
    private val items = mutableListOf<WorkingMemoryItem>()

    data class WorkingMemoryItem(
        val sourceId: String,
        val label: String,
        val content: String,
        var activation: Float
    )

    fun load(relevantNodes: List<SemanticNode>) {
        items.clear()
        var charsUsed = 0
        for (node in relevantNodes) {
            val entry = "[${node.id}] ${node.label}: ${node.content}"
            if (items.size >= MAX_ITEMS || charsUsed + entry.length > MAX_CHARS) break
            items.add(WorkingMemoryItem(node.id, node.label, node.content, SemanticMemory.retrievalScore(node, "")))
            charsUsed += entry.length + 2
        }
    }

    fun add(node: SemanticNode) {
        if (items.any { it.sourceId == node.id }) {
            items.find { it.sourceId == node.id }?.activation = SemanticMemory.retrievalScore(node, "")
            return
        }
        if (items.size >= MAX_ITEMS) {
            items.minByOrNull { it.activation }?.let { items.remove(it) }
        }
        items.add(WorkingMemoryItem(node.id, node.label, node.content, SemanticMemory.retrievalScore(node, "")))
    }

    fun toPromptString(): String {
        if (items.isEmpty()) return "[No active working memory]"
        return items.joinToString("\n") { "[${it.sourceId}] ${it.label}: ${it.content.take(120)}" }
    }

    fun loadFactor(): Float = (items.size.toFloat() / MAX_ITEMS).coerceAtMost(1f)
    fun isNearCapacity(): Boolean = loadFactor() > 0.8f
    fun isEmpty(): Boolean = items.isEmpty()

    /**
     * Accessor for spreading activation: returns the source IDs of all items
     * currently in working memory, so SemanticMemory can propagate activation
     * boost to their connected neighbors. (blueprint Part 5.1)
     */
    fun activeNodeIds(): List<String> = items.map { it.sourceId }
}
