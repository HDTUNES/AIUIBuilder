package com.arena.aiuibuilder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class CognitiveStage {
    IDLE, PREFILL_GOALS, SCORING_ACT_R, VERIFYING_GATE, GENERATING_GBNF, REGISTERING_BLACKBOARD, SAVING_SNAPSHOT, COMPLETE
}

private val StepDim = Color(0xFF5B6472)
private val StepBright = Color(0xFFF8FAFC)
private val StepBg = Color(0xFF000000)
private val StepStroke = Color(0xFF1F1F1F)

private data class StepSpec(val stage: CognitiveStage, val label: String, val detail: String)

private val stepOrder = listOf(
    StepSpec(CognitiveStage.PREFILL_GOALS, "TARGET", "Selecting active MAP-Elites coordinate targets"),
    StepSpec(CognitiveStage.SCORING_ACT_R, "RETRIEVE", "Retrieving historical context blocks and active policies"),
    StepSpec(CognitiveStage.VERIFYING_GATE, "VERIFY", "Performing logical consistency traversals on graph"),
    StepSpec(CognitiveStage.GENERATING_GBNF, "GENERATE", "Streaming grammar-constrained recursive output"),
    StepSpec(CognitiveStage.REGISTERING_BLACKBOARD, "COMMIT", "Merging facts and validating via execution gate"),
    StepSpec(CognitiveStage.SAVING_SNAPSHOT, "SNAPSHOT", "Writing secure updates into persistent app cache")
)

@Composable
fun CognitiveLoopMapV1Header(activeNodes: Int, edgesCount: Int, step: Int) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D0D)),
        border = BorderStroke(1.dp, Color(0xFF1F1F1F)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF38BDF8)))
                Text("MESA COGNITIVE OS CORES", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
            }
            Text(
                "Multi-Agent self-adaptation tracking loop. Causal verifiers validate hypotheses before grid allocation.",
                color = Color(0xFFECECF1),
                fontSize = 11.sp,
                lineHeight = 14.sp
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricPill("Blackboard", "$activeNodes nodes", Color(0xFF38BDF8))
                MetricPill("Edges", "$edgesCount connections", Color(0xFF38BDF8))
                MetricPill("OS Steps", "Step $step", Color(0xFF38BDF8))
            }
        }
    }
}

@Composable
private fun MetricPill(label: String, value: String, accent: Color) {
    Column(modifier = Modifier.background(Color(0xFF111111), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(label, color = Color(0xFF8E8EA0), fontSize = 9.sp)
        Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
fun LiveStepTrackerV2(currentStage: CognitiveStage, liveText: String) {
    var expandedStage by remember { mutableStateOf<CognitiveStage?>(null) }
    Card(
        colors = CardDefaults.cardColors(containerColor = StepBg),
        border = BorderStroke(1.dp, StepStroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                stepOrder.forEach { spec ->
                    val isActive = currentStage == spec.stage
                    val isDone = currentStage == CognitiveStage.COMPLETE || currentStage.ordinal > spec.stage.ordinal

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { expandedStage = if (expandedStage == spec.stage) null else spec.stage }
                    ) {
                        StepChip(spec.label, isActive, isDone)
                    }
                }
            }
            stepOrder.forEach { spec ->
                if (expandedStage == spec.stage || currentStage == spec.stage) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0D0D0D), RoundedCornerShape(6.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "STAGE: ${spec.label} - PROCESS LOG",
                                color = Color(0xFF38BDF8),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                spec.detail,
                                color = Color(0xFF8E8EA0),
                                fontSize = 11.sp
                            )
                            if (spec.stage == CognitiveStage.GENERATING_GBNF && liveText.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    liveText.takeLast(120),
                                    color = Color(0xFF86EFAC),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepChip(label: String, isActive: Boolean, isDone: Boolean) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        when {
            isActive -> CircularProgressIndicator(modifier = Modifier.size(10.dp), color = StepBright, strokeWidth = 1.5.dp)
            isDone -> Text("[x]", color = StepDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            else -> Text("[ ]", color = StepDim.copy(alpha = 0.4f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (isActive) {
            ShimmerLabel(label)
        } else {
            Text(
                label,
                color = if (isDone) StepDim else StepDim.copy(alpha = 0.4f),
                fontWeight = FontWeight.Light,
                fontSize = 9.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
private fun ShimmerLabel(label: String) {
    val transition = rememberInfiniteTransition(label = "step-shimmer")
    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1100, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "sweep"
    )
    val brush = Brush.linearGradient(
        colors = listOf(StepDim, StepBright, StepDim),
        start = Offset(0f + offset * 180f, 0f),
        end = Offset(60f + offset * 180f, 0f)
    )
    Text(
        text = label,
        style = TextStyle(brush = brush, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 0.5.sp)
    )
}

private val DashBg = Color(0xFF000000)
private val DashStroke = Color(0xFF1F1F1F)
private val DashDim = Color(0xFF5B6472)
private val DashEmpty = Color(0xFF0D0D0D)
private val domainOrder = listOf("structural", "biological", "economic", "physical", "computational")
private val abstractionOrder = listOf("concrete", "intermediate", "abstract")

@Composable
fun MapElitesArchiveDashboard(refreshKey: Int) {
    val cells = MesaEngine.archiveGrid
    val targetKey = MesaEngine.currentTargetCellKey
    val winningPolicy = MesaEngine.currentWinningPolicy
    Card(colors = CardDefaults.cardColors(containerColor = DashBg), border = BorderStroke(1.dp, DashStroke), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("MAP-ELITES POPULATION ARCHIVE", color = Color(0xFFE5E7EB), fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.5.sp)
            abstractionOrder.forEach { abs ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    domainOrder.forEach { dom ->
                        val key = "$dom/$abs"
                        val cell = cells[key]
                        ArchiveCellTile(
                            domain = dom,
                            quality = cell?.qualityScore ?: 0f,
                            visits = cell?.visitCount ?: 0,
                            isTarget = key == targetKey,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            if (winningPolicy != null) {
                Text("ACTIVE POLICY BANDIT", color = Color(0xFFE5E7EB), fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 4.dp))
                PolicyBar(winningPolicy)
            }
            if (MesaEngine.failureMemoryStore.isNotEmpty()) {
                Text("REFLEXION FAILURES", color = Color(0xFFE5E7EB), fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 4.dp))
                MesaEngine.failureMemoryStore.take(2).forEach { fm ->
                    Text("stalled@${fm.stalledIter} · \"${fm.whyStuck.take(65)}\" → pivot: ${fm.pivotDirection}", color = DashDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun ArchiveCellTile(domain: String, quality: Float, visits: Int, isTarget: Boolean, modifier: Modifier = Modifier) {
    val fillColor = if (visits == 0) DashEmpty else lerpQualityColor(quality)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(fillColor)
            .padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(domain.take(3).uppercase(), color = Color(0xFFE5E7EB), fontSize = 8.sp, fontWeight = FontWeight.Light, letterSpacing = 0.5.sp)
        Text(if (visits == 0) "—" else "%.2f".format(quality), color = Color(0xFFE5E7EB), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        if (isTarget) {
            Text("TARGET", color = Color(0xFF86EFAC), fontSize = 7.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

private fun lerpQualityColor(q: Float): Color {
    val t = q.coerceIn(0f, 1f)
    val from = Color(0xFF0D0D0D)
    val to = Color(0xFF155E75)
    return Color(
        red = from.red + (to.red - from.red) * t,
        green = from.green + (to.green - from.green) * t,
        blue = from.blue + (to.blue - from.blue) * t,
        alpha = 1f
    )
}

@Composable
private fun PolicyBar(policy: ReasoningPolicy) {
    val rate = policy.successRate.coerceIn(0f, 1f)
    Column {
        Text("${policy.name}  ·  ${"%.0f".format(rate * 100)}% Success Priority", color = Color(0xFFE5E7EB), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(4.dp))
        Box(modifier = Modifier.fillMaxWidth().height(4.dp).background(DashEmpty, RoundedCornerShape(2.dp))) {
            Box(modifier = Modifier.fillMaxWidth(rate).height(4.dp).background(Color(0xFF38BDF8), RoundedCornerShape(2.dp)))
        }
    }
}
