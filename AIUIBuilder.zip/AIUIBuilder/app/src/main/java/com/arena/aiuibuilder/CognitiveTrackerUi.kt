package com.arena.aiuibuilder

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class CognitiveStage {
    IDLE, PREFILL_GOALS, SCORING_ACT_R, VERIFYING_GATE, GENERATING_GBNF, REGISTERING_BLACKBOARD, SAVING_SNAPSHOT, COMPLETE
}

@Composable
fun CognitiveLoopMapV1Header(activeNodes: Int, edgesCount: Int, step: Int) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = BorderStroke(1.dp, Color(0xFF38BDF8)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF38BDF8)))
                Text("ACT-R & MESA Cognitive OS — Loop Map V1", color = Color(0xFFFFFFFF), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Text(
                "SOTA Persistent Reasoning Architecture V1: MAP-Elites Archive Grid + MCTS Selector + Thompson Bandits + Reflexion Memory. Prompt stays flat ~1100 chars forever.",
                color = Color(0xFFE5E7EB),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                MetricPill("Belief Nodes", activeNodes.toString(), Color(0xFFFFFFFF))
                MetricPill("Causal Edges", edgesCount.toString(), Color(0xFFFFFFFF))
                MetricPill("OS Step", step.toString(), Color(0xFFFFFFFF))
                MetricPill("Storage", "Private App", Color(0xFFFFFFFF))
            }
        }
    }
}

@Composable
private fun MetricPill(label: String, value: String, accent: Color) {
    Column(modifier = Modifier.background(Color(0xFF1E293B), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(label, color = Color(0xFF94A3B8), fontSize = 9.sp)
        Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun CognitiveStepTrackerView(currentStage: CognitiveStage, liveText: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220)),
        border = BorderStroke(1.dp, Color(0xFF263244)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("⚡ Live Architecture V1 Execution Progress", color = Color(0xFFFFFFFF), fontWeight = FontWeight.Bold, fontSize = 14.sp)

            val stagesOrder = listOf(
                CognitiveStage.PREFILL_GOALS to "🧠 Step 1: Objectives Goal Tree & HTN Task Decomposition",
                CognitiveStage.SCORING_ACT_R to "📊 Step 2: ACT-R Activation Memory & MCTS Target Selection",
                CognitiveStage.VERIFYING_GATE to "🛡️ Step 3: Empirical Verifier Gate & Graph Consistency",
                CognitiveStage.GENERATING_GBNF to "⚡ Step 4: Native GBNF Inference Engine (llama.cpp)",
                CognitiveStage.REGISTERING_BLACKBOARD to "💾 Step 5: Blackboard Truth Maintenance & Thompson Policy Update",
                CognitiveStage.SAVING_SNAPSHOT to "📦 Step 6: Private App Storage Persistence (Zero file permissions required)"
            )

            stagesOrder.forEach { (stageEnum, title) ->
                val isActive = currentStage == stageEnum
                val isDone = currentStage == CognitiveStage.COMPLETE || currentStage.ordinal > stageEnum.ordinal
                SotaMetallicBreathingTextStep(title = title, isActive = isActive, isDone = isDone, subtext = if (isActive && stageEnum == CognitiveStage.GENERATING_GBNF) liveText.takeLast(70) else null)
            }
        }
    }
}

@Composable
private fun SotaMetallicBreathingTextStep(title: String, isActive: Boolean, isDone: Boolean, subtext: String?) {
    val transition = rememberInfiniteTransition(label = "step-glow")
    val breathingAlpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(animation = tween(900, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "alpha-pulse"
    )

    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        when {
            isActive -> CircularProgressIndicator(modifier = Modifier.size(15.dp).padding(top = 2.dp), color = Color(0xFFFFFFFF), strokeWidth = 2.dp)
            isDone -> Text("✅", fontSize = 13.sp)
            else -> Text("•", color = Color(0xFF64748B), fontSize = 14.sp)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            val textColor = when {
                isActive -> Color(0xFFFFFFFF).copy(alpha = breathingAlpha)
                isDone -> Color(0xFFE5E7EB)
                else -> Color(0xFF64748B)
            }
            Text(text = title, color = textColor, fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp)
            if (subtext != null) {
                Text(subtext, color = Color(0xFFE5E7EB).copy(alpha = 0.8f), fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

@Composable
fun MapElitesArchiveDashboard(refreshKey: Int) {
    val cells = MesaEngine.archiveGrid
    val targetKey = MesaEngine.currentTargetCellKey
    val winningPolicy = MesaEngine.currentWinningPolicy

    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220)), border = BorderStroke(1.dp, Color(0xFF263244)), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("MAP-ELITES ARCHIVE — 15 POPULATION CELLS", color = Color(0xFFFFFFFF), fontWeight = FontWeight.Bold, fontSize = 13.sp)

            val abstractionOrder = listOf("concrete", "intermediate", "abstract")
            val domainOrder = listOf("structural", "biological", "economic", "physical", "computational")

            abstractionOrder.forEach { abs ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    domainOrder.forEach { dom ->
                        val key = "$dom/$abs"
                        val cell = cells[key]
                        ArchiveCellTile(
                            domain = dom,
                            quality = cell?.qualityScore ?: 0f,
                            visits = cell?.visitCount ?: 0,
                            isTarget = key == targetKey,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (winningPolicy != null) {
                Text("ACTIVE THOMPSON BANDIT POLICY: ${winningPolicy.name} (${"%.0f".format(winningPolicy.successRate * 100)}% Win Prior)", color = Color(0xFF7DD3FC), fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun ArchiveCellTile(domain: String, quality: Float, visits: Int, isTarget: Boolean, modifier: Modifier = Modifier) {
    val fillColor = if (visits == 0) Color(0xFF1E293B) else Color(0xFF0284C7).copy(alpha = quality.coerceIn(0.25f, 1f))
    Column(modifier = modifier.clip(RoundedCornerShape(4.dp)).background(fillColor).padding(vertical = 6.dp, horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(domain.take(3).uppercase(), color = Color(0xFFFFFFFF), fontSize = 9.sp, fontWeight = FontWeight.Light)
        Text(if (visits == 0) "—" else "%.2f".format(quality), color = Color(0xFFFFFFFF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        if (isTarget) Text("◂ target", color = Color(0xFF86EFAC), fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}
