package com.arena.aiuibuilder

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class CognitiveStage {
    IDLE, PREFILL_GOALS, SCORING_ACT_R, VERIFYING_GATE, GENERATING_GBNF, REGISTERING_BLACKBOARD, SAVING_SNAPSHOT, COMPLETE
}

@Composable
fun CognitiveLoopMapV1Header(activeNodes: Int, edgesCount: Int, step: Int) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = BorderStroke(1.dp, Color(0xFF38BDF8)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF38BDF8)))
                Text("ACT-R Cognitive Operating System — Loop Map V1", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Text(
                "Tripartite Cognition Active: Knowledge (Belief Graph), Attention (ACT-R + PageRank Centrality), Objectives (Goal Tree). Prompt stays flat ~400 tokens.",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                MetricPill("Belief Nodes", activeNodes.toString(), Color(0xFF86EFAC))
                MetricPill("Causal Edges", edgesCount.toString(), Color(0xFFC4B5FD))
                MetricPill("OS Step", step.toString(), Color(0xFF7DD3FC))
                MetricPill("Disk Storage", "Private App", Color(0xFFFDBA74))
            }
        }
    }
}

@Composable
private fun MetricPill(label: String, value: String, accent: Color) {
    Column(modifier = Modifier.background(Color(0xFF1E293B), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(label, color = Color(0xFF94A3B8), fontSize = 9.sp)
        Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun CognitiveStepTrackerView(currentStage: CognitiveStage, liveText: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220)),
        border = BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("⚡ Step-by-Step Live Architecture Execution Tracker", color = Color(0xFFE2E8F0), fontWeight = FontWeight.Bold, fontSize = 13.sp)

            val stagesOrder = listOf(
                CognitiveStage.PREFILL_GOALS to "🧠 [Step 1/6] Objectives Goal Tree (HTN Task Decomposition)",
                CognitiveStage.SCORING_ACT_R to "📊 [Step 2/6] Base-Level ACT-R Activation & PageRank Scoring",
                CognitiveStage.VERIFYING_GATE to "🛡️ [Step 3/6] Empirical Verifier Gate & Graph Consistency",
                CognitiveStage.GENERATING_GBNF to "⚡ [Step 4/6] Native GBNF Inference Engine (llama.cpp)",
                CognitiveStage.REGISTERING_BLACKBOARD to "💾 [Step 5/6] Blackboard Truth Maintenance & Confidence Update",
                CognitiveStage.SAVING_SNAPSHOT to "📦 [Step 6/6] Private Persistent Disk Storage (context.filesDir)"
            )

            stagesOrder.forEachIndexed { idx, (stageEnum, title) ->
                val statusState = when {
                    currentStage == CognitiveStage.IDLE -> "WAITING"
                    currentStage == CognitiveStage.COMPLETE -> "DONE"
                    currentStage.ordinal > stageEnum.ordinal -> "DONE"
                    currentStage == stageEnum -> "ACTIVE"
                    else -> "WAITING"
                }
                StepRowItem(title = title, status = statusState, subtext = if (statusState == "ACTIVE" && stageEnum == CognitiveStage.GENERATING_GBNF) liveText.takeLast(60) else null)
            }
        }
    }
}

@Composable
private fun StepRowItem(title: String, status: String, subtext: String?) {
    val borderColor by animateColorAsState(
        when (status) {
            "ACTIVE" -> Color(0xFF38BDF8)
            "DONE" -> Color(0xFF22C55E)
            else -> Color(0xFF1E293B)
        },
        label = "step-border"
    )

    val bgColor by animateColorAsState(
        when (status) {
            "ACTIVE" -> Color(0xFF0F172A)
            "DONE" -> Color(0xFF064E3B).copy(alpha = 0.3f)
            else -> Color(0xFF0F172A).copy(alpha = 0.5f)
        },
        label = "step-bg"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (status) {
            "ACTIVE" -> CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color(0xFF38BDF8), strokeWidth = 2.dp)
            "DONE" -> Text("✅", fontSize = 13.sp)
            else -> Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(Color(0xFF334155)))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = if (status == "WAITING") Color(0xFF64748B) else Color(0xFFF1F5F9), fontWeight = FontWeight.Medium, fontSize = 12.sp)
            if (subtext != null) {
                Text(subtext, color = Color(0xFF7DD3FC), fontFamily = FontFamily.Monospace, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}
