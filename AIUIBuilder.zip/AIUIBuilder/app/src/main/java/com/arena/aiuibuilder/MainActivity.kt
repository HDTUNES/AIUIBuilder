package com.arena.aiuibuilder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Global crash visibility (blueprint 5.5): capture the cause in AppLog
        // before the process dies, so next session has a diagnosable trace.
        // Also writes to a separate crash_log.txt that survives process death
        // and gets picked up by AppLog.install() on next launch.
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val crashMsg = "FATAL uncaught on ${thread.name}: ${throwable.message}\n${throwable.stackTraceToString().take(2000)}"
            // Write to crash file immediately (AppLog may not be fully initialized yet)
            runCatching {
                File(filesDir, "crash_log.txt").writeText(crashMsg)
            }
            // Also try AppLog if it's available
            runCatching { AppLog.appendError("FATAL uncaught on ${thread.name}", throwable) }
            // Let the default handler still run so the OS handles the crash normally.
            Thread.getDefaultUncaughtExceptionHandler()?.uncaughtException(thread, throwable)
        }

        AppLog.install(applicationContext)
        setContent { AiWorkbenchApp() }
    }
}

object NativeTuning {
    init { runCatching { System.loadLibrary("ai-chat") } }
    external fun setOptions(threads: Int, contextSize: Int, batchSize: Int, temperature: Float)
}

private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

private const val UI_JSON_SYSTEM_PROMPT = """
You are an offline Android UI generator.
Return ONLY one valid JSON object. No markdown. No explanation. No code fences. No <think>.
Allowed schema:
{
  "title": "screen title",
  "elements": [
    {"type":"heading|text|input|button|checkbox|card|spacer", "id":"optional", "text":"optional", "hint":"optional", "checked":false, "children":[]}
  ]
}
Rules:
- Use only the allowed element types.
- Keep IDs lowercase and simple.
- Keep output compact.
"""

private fun getUniversalSystemPrompt(): String {
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
    return """
You are AIUIBuilder Studio Agent, an advanced local AI intelligence running on Android.
Current Date: $today.
IMPORTANT HOST OVERRIDE: Unlike standard offline models, you DO have live internet search and real-time grounding provided by the Android host application. Never refuse a query by claiming you lack real-time data, internet access, or have a training knowledge cutoff.
When web search results are provided in your prompt context, treat them as absolute verified real-world facts and answer directly.
For normal chat, be direct, helpful, and natural.
For builder tasks, return clean valid code artifacts.
""".trimIndent()
}

// ─────────────────────────────────────────────────────────────────────────────
// App Entry Point
// ─────────────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiWorkbenchApp() {
    val vm: AppSessionViewModel = viewModel()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { AiChat.getInferenceEngine(context.applicationContext) }

    val selectedMode    by vm.selectedMode.collectAsState()
    val isBusy          by vm.isBusy.collectAsState()
    val statusText      by vm.statusText.collectAsState()
    val isGenerating    by vm.isGenerating.collectAsState()
    val selectedModelName by vm.selectedModelName.collectAsState()
    val copiedModelPath by vm.copiedModelPath.collectAsState()
    val errorText       by vm.errorText.collectAsState()
    val engineState     by engine.state.collectAsState()

    val threads     by vm.threads.collectAsState()
    val contextSize by vm.contextSize.collectAsState()
    val batchSize   by vm.batchSize.collectAsState()
    val temperature by vm.temperature.collectAsState()
    val maxTokens   by vm.maxTokens.collectAsState()

    var showSettings by remember { mutableStateOf(false) }

    // File picker launcher
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                vm.selectedModelUri.value = uri
                vm.selectedModelName.value = context.displayName(uri) ?: "model.gguf"
                vm.statusText.value = "Model selected. Tap Load."
                vm.errorText.value = null
            }
        }
    )

    // Load model function
    fun loadSelectedModel() {
        val uri = vm.selectedModelUri.value ?: return
        scope.launch {
            vm.isBusy.value = true
            vm.errorText.value = null
            try {
                vm.statusText.value = "Applying settings..."
                runCatching { NativeTuning.setOptions(threads, contextSize, batchSize, temperature) }
                vm.statusText.value = "Copying GGUF into app storage..."
                val modelFile = copyModelIntoAppStorage(context, uri)
                vm.copiedModelPath.value = modelFile.absolutePath
                vm.statusText.value = "Waiting for runtime..."
                waitUntilEngineInitialized(engine)
                vm.statusText.value = "Loading model. Keep app open."
                engine.loadModel(modelFile.absolutePath)
                engine.setSystemPrompt(getUniversalSystemPrompt())
                vm.statusText.value = "Model ready."
            } catch (t: Throwable) {
                AppLog.appendError("Model load failed", t)
                vm.errorText.value = t.message ?: t.toString()
                vm.statusText.value = "Load failed."
            } finally {
                vm.isBusy.value = false
            }
        }
    }

    // Unload model function
    fun unloadModel() {
        scope.launch {
            try {
                vm.statusText.value = "Unloading model..."
                // This was the actual bug: without calling engine.cleanUp(), engine.state
                // stayed at ModelReady forever, and ModelPickerCard's visibility condition
                // (engineState !is ModelReady) could never become true again -- the picker
                // UI had no way to reappear without fully restarting the app. cleanUp() is
                // the real native unload (declared right on InferenceEngine), transitioning
                // through State.UnloadingModel and back to State.Initialized.
                withContext(Dispatchers.IO) {
                    runCatching { engine.cleanUp() }.onFailure { AppLog.appendError("engine.cleanUp() failed", it) }
                }
                // Clear local model-selection state now that the engine itself is actually unloaded.
                vm.copiedModelPath.value = null
                vm.selectedModelName.value = null
                vm.selectedModelUri.value = null
                vm.statusText.value = "Model unloaded."
                vm.errorText.value = null
            } catch (t: Throwable) {
                AppLog.appendError("Unload failed", t)
                vm.errorText.value = t.message ?: t.toString()
                vm.statusText.value = "Unload failed."
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = ObsColors.BgDeep,
            surface    = ObsColors.BgPanel,
            primary    = ObsColors.TextPrime,
            onBackground = ObsColors.TextPrime,
            onSurface  = ObsColors.TextPrime
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = ObsColors.BgDeep) {
            Scaffold(
                containerColor = ObsColors.BgDeep,
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ObsColors.BgPanel,
                            titleContentColor = ObsColors.TextPrime,
                            actionIconContentColor = ObsColors.TextMuted
                        ),
                        title = {
                            Column {
                                Text(
                                    text = selectedModelName ?: "No model loaded",
                                    color = ObsColors.TextPrime,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                val stateLabel = when (engineState) {
                                    is InferenceEngine.State.ModelReady   -> "Ready"
                                    is InferenceEngine.State.Initialized  -> "Initialized"
                                    is InferenceEngine.State.Error        -> "Error"
                                    else                                  -> "Not loaded"
                                }
                                Text(stateLabel, color = ObsColors.TextMuted, fontSize = 10.sp)
                            }
                        },
                        actions = {
                            // Settings icon — clear gear icon
                            SettingsIconButton(onClick = { showSettings = true })
                        }
                    )
                }
            ) { paddingValues ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    // ── Mode tabs (shifted to top) ─────────────────────────────────
                    ModeTabRow(
                        selectedMode = selectedMode,
                        onSelect = {
                            if (selectedMode != it) {
                                AppLog.logUi("TabSwitch", "Switching from $selectedMode to $it")
                            }
                            vm.selectedMode.value = it
                        }
                    )

                    // ── Status bar ───────────────────────────────────────────────
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ObsColors.BgPanel)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isBusy) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(ObsColors.AccentAmber)
                            )
                        }
                        Text(
                            statusText,
                            color = ObsColors.TextMuted,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f)
                        )
                        errorText?.let {
                            Text("Error: $it", color = ObsColors.AccentRed, fontSize = 11.sp)
                        }
                    }

                    // ── Model Picker Card (when no model loaded) ─────────────────
                    if (engineState !is InferenceEngine.State.ModelReady) {
                        ModelPickerCard(
                            onPickModel = { if (!isBusy) picker.launch(arrayOf("*/*")) },
                            onLoadModel = { loadSelectedModel() },
                            onUnloadModel = null,
                            isBusy = isBusy
                        )
                    } else {
                        // Show compact model status + unload option
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (engineState is InferenceEngine.State.ModelReady) ObsColors.AccentGreen else ObsColors.AccentAmber)
                            )
                            Text(selectedModelName ?: "", color = ObsColors.TextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                            if (copiedModelPath != null) {
                                TextButton(
                                    onClick = { unloadModel() },
                                    modifier = Modifier.height(24.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                ) {
                                    Text("Unload", color = ObsColors.AccentRed, fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    // ── Content area ─────────────────────────────────────────────
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        when (selectedMode) {
                            "chat"      -> ChatMainPanel(vm = vm, engine = engine)
                            "cognitive_core" -> CognitiveCoreTabWrapper(vm = vm, engine = engine)
                        }
                    }
                }
            }
        }

        if (showSettings) {
            SettingsSheet(vm = vm, onDismiss = { showSettings = false })
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Settings Icon Button (clear, professional gear icon)
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun SettingsIconButton(onClick: () -> Unit) {
    // Professional gear icon using simple shapes — no emoji
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(ObsColors.BgCard)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // Gear-like icon using two overlapping rectangles + circle
        Box(
            modifier = Modifier.size(18.dp),
            contentAlignment = Alignment.Center
        ) {
            // Outer ring (border)
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .border(1.5.dp, ObsColors.TextMuted, CircleShape)
            )
            // Inner dot
            Box(
                modifier = Modifier
                    .size(4.dp)
                    .background(ObsColors.TextMuted, CircleShape)
            )
            // Gear teeth simulation — 4 small rectangles around
            listOf(
                Alignment.TopCenter to 0.dp,
                Alignment.BottomCenter to 0.dp,
                Alignment.CenterStart to 0.dp,
                Alignment.CenterEnd to 0.dp
            ).forEach { (align, _) ->
                Box(
                    modifier = Modifier
                        .size(width = 1.5.dp, height = 4.dp)
                        .background(ObsColors.TextMuted)
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Model Picker Card — prominent card below tabs
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ModelPickerCard(
    onPickModel: () -> Unit,
    onLoadModel: (() -> Unit)?,
    onUnloadModel: (() -> Unit)?,
    isBusy: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: Pick GGUF Model — full width
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, ObsColors.BorderMid, RoundedCornerShape(12.dp))
                    .background(ObsColors.BgPanel)
                    .clickable(enabled = !isBusy) { onPickModel() },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(ObsColors.BgCard, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📁", fontSize = 14.sp)
                    }
                    Column {
                        Text(
                            text = "Pick GGUF Model",
                            color = ObsColors.TextPrime,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "LOCAL GGUF MODEL",
                            color = ObsColors.TextDim,
                            fontSize = 9.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Row 2: Load button — full width, matching height and corner radius
            // Blueprint 1.1/7: real CircularProgressIndicator + "Loading model…" text
            // while busy, button disabled until both "not busy" and model selected.
            if (isBusy) {
                // Loading state: spinner + text in place of the button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsColors.BgPanel),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = ObsColors.AccentGreen,
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = "Loading model…",
                            color = ObsColors.TextMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else if (onLoadModel != null) {
                ActionButton(
                    text = "Load",
                    icon = "▶",
                    color = ObsColors.AccentGreen,
                    enabled = true,
                    onClick = onLoadModel,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                )
            }

            // Unload button (if applicable)
            if (onUnloadModel != null && !isBusy) {
                ActionButton(
                    text = "Unload",
                    icon = "■",
                    color = ObsColors.AccentRed,
                    enabled = true,
                    onClick = onUnloadModel,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                )
            }
        }
    }
}

@Composable
private fun ActionButton(
    text: String,
    icon: String,
    color: Color,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (enabled) color.copy(alpha = 0.15f) else ObsColors.BgPanel)
            .border(1.dp, if (enabled) color.copy(alpha = 0.4f) else ObsColors.Border, RoundedCornerShape(10.dp))
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(icon, fontSize = 12.sp, color = if (enabled) color else ObsColors.TextDim)
            Text(text, color = if (enabled) color else ObsColors.TextDim, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Mode Tab Row — shifted to top, clean selected indicator
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ModeTabRow(selectedMode: String, onSelect: (String) -> Unit) {
    val modes = listOf("chat" to "Chat", "cognitive_core" to "Cognitive Core")
    val selectedIndex = modes.indexOfFirst { it.first == selectedMode }.coerceAtLeast(0)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsColors.BgPanel)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 0.dp, vertical = 0.dp),
            horizontalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            modes.forEach { (key, label) ->
                val selected = selectedMode == key
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clickable { onSelect(key) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (selected) ObsColors.TextPrime else ObsColors.TextMuted,
                        fontSize = 13.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }

        // Bottom indicator line — 3 segments, active one is white, others are border
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
        ) {
            modes.forEachIndexed { index, (key, _) ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .background(if (index == selectedIndex) ObsColors.TextPrime else ObsColors.Border)
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Chat Panel — fully redesigned UI
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ChatMainPanel(vm: AppSessionViewModel, engine: InferenceEngine) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val chatInput   by vm.chatInput.collectAsState()
    val messages    by vm.chatMessages.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    val webSearch   by vm.chatWebSearch.collectAsState()
    val modelReady  = engine.state.value is InferenceEngine.State.ModelReady
    val maxTokens   by vm.maxTokens.collectAsState()

    var generationJob by remember { mutableStateOf<Job?>(null) }
    var showExtras   by remember { mutableStateOf(false) }

    val extrasRotation by animateFloatAsState(
        targetValue = if (showExtras) 45f else 0f,
        animationSpec = tween(250),
        label = "extrasRotation"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        // ── Message list ──────────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Start a conversation", color = ObsColors.TextDim, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Type a message below", color = ObsColors.TextDim.copy(alpha = 0.6f), fontSize = 12.sp)
                    }
                }
            }
            messages.forEach { msg -> MessageBubble(msg) }
        }

        // ── Extras menu (animated expand) ─────────────────────────────────────
        AnimatedContent(
            targetState = showExtras,
            transitionSpec = {
                fadeIn(tween(200)) togetherWith fadeOut(tween(150))
            },
            label = "extras"
        ) { show ->
            if (show) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 4.dp)
                        .background(ObsColors.BgPanel, RoundedCornerShape(12.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ExtraMenuItem(
                        label = "Web Search",
                        enabled = true,
                        checked = webSearch,
                        onClick = { vm.chatWebSearch.value = !webSearch }
                    )
                    ExtraMenuItem(
                        label = "Thinking Mode",
                        enabled = false,
                        checked = false,
                        onClick = { /* not yet implemented */ }
                    )
                }
            }
        }

        // ── Input row ─────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ObsColors.BgPanel)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Plus button (left) with rotation animation
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(ObsColors.BgCard)
                    .border(1.dp, ObsColors.Border, RoundedCornerShape(10.dp))
                    .clickable { showExtras = !showExtras },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "+",
                    color = ObsColors.TextMuted,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.rotate(extrasRotation)
                )
            }

            // Chat input — rounded rectangle, dark background, no sharp edges
            OutlinedTextField(
                value = chatInput,
                onValueChange = { vm.chatInput.value = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text("Message...", color = ObsColors.TextDim, fontSize = 13.sp)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ObsColors.BorderMid,
                    unfocusedBorderColor = ObsColors.InputBorder,
                    focusedTextColor = ObsColors.TextPrime,
                    unfocusedTextColor = ObsColors.TextPrime,
                    cursorColor = ObsColors.TextPrime,
                    focusedContainerColor = ObsColors.InputBg,
                    unfocusedContainerColor = ObsColors.InputBg
                ),
                shape = RoundedCornerShape(14.dp),
                maxLines = 5
            )

            // Send / Stop morphing button — white icon always
            AnimatedContent(
                targetState = isGenerating,
                transitionSpec = {
                    fadeIn(tween(150)) togetherWith fadeOut(tween(150))
                },
                label = "send-stop"
            ) { generating ->
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (generating) ObsColors.AccentRed.copy(alpha = 0.2f)
                            else ObsColors.BgCard
                        )
                        .border(
                            1.dp,
                            if (generating) ObsColors.AccentRed.copy(alpha = 0.5f)
                            else ObsColors.Border,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            if (generating) {
                                generationJob?.cancel()
                                generationJob = null
                                vm.isGenerating.value = false
                                AppLog.append("[USER CANCELLED]")
                                vm.updateLastMessage { it.copy(isGenerating = false, text = it.text + " [cancelled]") }
                            } else {
                                val input = chatInput.trim()
                                if (input.isBlank() || !modelReady) return@clickable
                                vm.chatInput.value = ""
                                vm.addMessage(ChatMessage("You", input))
                                vm.addMessage(ChatMessage("AI", "", isGenerating = true))
                                vm.isGenerating.value = true
                                generationJob = scope.launch {
                                    try {
                                        val prompt = "${getUniversalSystemPrompt()}\n\nUser: $input\nAssistant:"
                                        val sb = StringBuilder()
                                        engine.sendUserPrompt(prompt, maxTokens).collect { token ->
                                            sb.append(token)
                                            vm.updateLastMessage { it.copy(text = sb.toString()) }
                                        }
                                    } catch (e: kotlinx.coroutines.CancellationException) {
                                        AppLog.append("[USER CANCELLED]")
                                    } catch (t: Throwable) {
                                        AppLog.appendError("Chat failed", t)
                                        vm.updateLastMessage { it.copy(text = "[Error: ${t.message}]", isGenerating = false) }
                                    } finally {
                                        vm.isGenerating.value = false
                                        vm.updateLastMessage { it.copy(isGenerating = false) }
                                    }
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (generating) {
                        // Stop button: white square inside white circle
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .background(ObsColors.TextPrime, RoundedCornerShape(4.dp))
                        )
                    } else {
                        // Send button: white arrow-up
                        Text("↑", color = ObsColors.TextPrime, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Extra menu item
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ExtraMenuItem(
    label: String,
    enabled: Boolean,
    checked: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (enabled) ObsColors.BgCard else ObsColors.BgDeep)
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (enabled) ObsColors.TextMuted else ObsColors.TextDim.copy(alpha = 0.4f),
            fontSize = 12.sp
        )
        if (enabled) {
            Switch(
                checked = checked,
                onCheckedChange = { onClick() },
                modifier = Modifier.height(20.dp),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ObsColors.TextPrime,
                    checkedTrackColor = ObsColors.TextMuted.copy(alpha = 0.4f),
                    uncheckedThumbColor = ObsColors.TextDim,
                    uncheckedTrackColor = ObsColors.Border
                )
            )
        } else {
            Text("Coming soon", color = ObsColors.TextDim.copy(alpha = 0.4f), fontSize = 10.sp)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Message Bubble
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun MessageBubble(msg: ChatMessage) {
    val isUser = msg.role == "You"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .then(if (isUser) Modifier.widthIn(max = 300.dp) else Modifier.fillMaxWidth())
                .clip(
                    RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isUser) 14.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 14.dp
                    )
                )
                .background(if (isUser) ObsColors.BgCard else ObsColors.BgPanel)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            if (msg.isGenerating && msg.text.isBlank()) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(3) { i ->
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(ObsColors.TextDim)
                        )
                    }
                }
            } else {
                Text(msg.text, color = ObsColors.TextPrime, fontSize = 15.sp, fontWeight = if (isUser) FontWeight.Normal else FontWeight.Light)
            }
        }
        Text(
            msg.role,
            color = ObsColors.TextDim,
            fontSize = 9.sp,
            modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Text Field Colors Helper
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun makeTextFieldColors(
    focusedBorderColor: Color,
    unfocusedBorderColor: Color,
    focusedTextColor: Color,
    unfocusedTextColor: Color,
    cursorColor: Color
) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = focusedBorderColor,
    unfocusedBorderColor = unfocusedBorderColor,
    focusedTextColor = focusedTextColor,
    unfocusedTextColor = unfocusedTextColor,
    cursorColor = cursorColor,
    focusedContainerColor = ObsColors.InputBg,
    unfocusedContainerColor = ObsColors.InputBg
)

// ─────────────────────────────────────────────────────────────────────────────
// Refiner Panel Wrapper
// ─────────────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RefinerMainPanelWrapper(vm: AppSessionViewModel, engine: InferenceEngine) {
    val engineState by engine.state.collectAsState()
    val modelReady = engineState is InferenceEngine.State.ModelReady
    AppLog.logUi("RefinerTab", "Composing RefinerMainPanelWrapper")
    Column(modifier = Modifier.fillMaxSize()) {
        RecursiveRefinerPanel(
            modelReady = modelReady,
            onStatus = { vm.statusText.value = it },
            onError = { vm.errorText.value = it }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Cognitive Panel Wrapper
// ─────────────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CognitivePanelWrapper(vm: AppSessionViewModel, engine: InferenceEngine) {
    val engineState by engine.state.collectAsState()
    AppLog.logUi("CognitiveTab", "Composing CognitivePanelWrapper")
    Column(modifier = Modifier.fillMaxSize()) {
        CognitivePanel(
            engine = engine,
            enabled = engineState is InferenceEngine.State.ModelReady,
            maxTokens = vm.maxTokens.value,
            onStatus = { vm.statusText.value = it },
            onError = { vm.errorText.value = it }
        )
    }
}

// Unified Cognitive Core tab wrapper -- replaces the two separate "refiner" and
// "cognitive" tab entries above with one tab that contains both, switched via
// CognitiveCoreTab's internal Normal / Meta-Cognitive mode chips. Both
// CognitivePanelWrapper and RefinerMainPanelWrapper above are left in place
// (now unreferenced) rather than deleted, so this can be rolled back to the old
// two-tab layout by reverting just the dispatch/ModeTabRow changes if needed.
@Composable
private fun CognitiveCoreTabWrapper(vm: AppSessionViewModel, engine: InferenceEngine) {
    val engineState by engine.state.collectAsState()
    AppLog.logUi("CognitiveCoreTab", "Composing CognitiveCoreTabWrapper")
    CognitiveCoreTab(
        engine = engine,
        modelReady = engineState is InferenceEngine.State.ModelReady,
        maxTokens = vm.maxTokens.value,
        onStatus = { vm.statusText.value = it },
        onError = { vm.errorText.value = it }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Builder Panel
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun BuilderPanel(
    prompt: String,
    onPrompt: (String) -> Unit,
    outputMode: String,
    onOutputMode: (String) -> Unit,
    code: String,
    raw: String,
    schema: UiSchema,
    enabled: Boolean,
    onGenerate: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "Builder",
                color = ObsColors.TextPrime,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Generate JSON UI for native preview, HTML for WebView, or React-style code.",
                color = ObsColors.TextMuted
            )
            OutlinedTextField(
                value = prompt,
                onValueChange = onPrompt,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Describe the UI/app") },
                minLines = 3,
                shape = RoundedCornerShape(12.dp),
                colors = makeTextFieldColors(
                    focusedBorderColor = ObsColors.BorderMid,
                    unfocusedBorderColor = ObsColors.InputBorder,
                    focusedTextColor = ObsColors.TextPrime,
                    unfocusedTextColor = ObsColors.TextPrime,
                    cursorColor = ObsColors.TextPrime
                )
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("JSON UI", "HTML", "React").forEach { mode ->
                    Button(
                        onClick = { onOutputMode(mode) },
                        enabled = enabled && mode != outputMode,
                        shape = RoundedCornerShape(8.dp)
                    ) { Text(mode, fontSize = 12.sp) }
                }
            }
            Button(
                enabled = enabled && prompt.isNotBlank(),
                onClick = onGenerate,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) { Text("Generate / refine") }
            Text("Preview", color = ObsColors.TextPrime, fontWeight = FontWeight.SemiBold)
            when (outputMode) {
                "JSON UI" -> DynamicScreen(schema)
                "HTML"    -> HtmlPreview(code)
                else      -> Text(
                    "React preview is code. Android cannot run React without bundling a JS runtime.",
                    color = ObsColors.TextMuted
                )
            }
            Text("Output", color = ObsColors.TextPrime, fontWeight = FontWeight.SemiBold)
            CodeBox(code.ifBlank { raw })
        }
    }
}

@Composable
private fun HtmlPreview(html: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        AndroidView(
            factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = false } },
            update = { webView -> webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null) }
        )
    }
}

@Composable
private fun CodeBox(code: String) {
    if (code.isBlank()) {
        Text("No output yet.", color = ObsColors.TextDim, fontSize = 12.sp)
        return
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsColors.BgDeep, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(code, color = ObsColors.TextMuted, fontSize = 10.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Utility Functions
// ─────────────────────────────────────────────────────────────────────────────
private suspend fun runBuilderLoop(
    engine: InferenceEngine,
    request: String,
    mode: String,
    maxTokens: Int,
    refinePasses: Int,
    setStatus: (String) -> Unit
): String {
    var currentPrompt = buildBuilderPrompt(request, mode)
    var result = ""
    val total = refinePasses.coerceIn(0, 3) + 1
    repeat(total) { pass ->
        setStatus(if (pass == 0) "Generating..." else "Refinement $pass/$refinePasses...")
        val sb = StringBuilder()
        engine.sendUserPrompt(currentPrompt, maxTokens).collect { token -> sb.append(token) }
        result = sb.toString()
        if (pass < refinePasses) {
            currentPrompt = """
Review and improve your previous output.
Original user request: $request
Previous output:
$result
Return the complete improved final output only. Keep the same output type: $mode.
""".trimIndent()
        }
    }
    return result
}

private fun buildBuilderPrompt(request: String, mode: String): String = when (mode) {
    "JSON UI" -> "Create a native UI JSON for: $request. Return only JSON matching the schema."
    "HTML"    -> "Create a polished dark responsive HTML UI for: $request. Return only a complete HTML document."
    else      -> "Create a React component for: $request. Return only code."
}

private fun cleanBuilderOutput(text: String, mode: String): String = when (mode) {
    "JSON UI" -> extractFirstJsonObject(text)
    "HTML"    -> extractHtml(text)
    else      -> stripCodeFences(text).trim()
}

private fun stripCodeFences(text: String): String =
    text.replace(Regex("```[a-zA-Z]*"), "").replace("```", "")

private fun extractFirstJsonObject(text: String): String {
    val clean = stripCodeFences(text)
    val start = clean.indexOf('{')
    val end   = clean.lastIndexOf('}')
    require(start >= 0 && end > start) { "No JSON object found" }
    return clean.substring(start, end + 1).trim()
}

private fun extractHtml(text: String): String {
    val clean = stripCodeFences(text).trim()
    val start = clean.indexOf("<", ignoreCase = true).coerceAtLeast(0)
    return clean.substring(start)
}

private suspend fun waitUntilEngineInitialized(engine: InferenceEngine) {
    repeat(200) {
        when (val state = engine.state.value) {
            is InferenceEngine.State.Initialized, is InferenceEngine.State.ModelReady -> return
            is InferenceEngine.State.Error -> throw state.exception
            else -> delay(100)
        }
    }
    error("Timed out waiting for llama.cpp runtime initialization")
}

private suspend fun copyModelIntoAppStorage(context: Context, uri: Uri): File = withContext(Dispatchers.IO) {
    val dir   = File(context.filesDir, "models").apply { mkdirs() }
    val name  = (context.displayName(uri) ?: "local-model.gguf").sanitizeFileName()
    val target = File(dir, name)
    context.contentResolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Could not open selected model file" }
        target.outputStream().use { output -> input.copyTo(output) }
    }
    target
}

private fun Context.displayName(uri: Uri): String? = runCatching {
    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }
}.getOrNull()

private fun String.sanitizeFileName(): String = replace(Regex("[^A-Za-z0-9._-]"), "_")
private fun snapContext(v: Int): Int  = listOf(1024, 1536, 2048, 3072, 4096).minBy { kotlin.math.abs(it - v) }
private fun snapBatch(v: Int): Int    = listOf(128, 256, 384, 512).minBy { kotlin.math.abs(it - v) }
private fun parseUiSchema(raw: String): UiSchema = json.decodeFromString<UiSchema>(raw)

// ─────────────────────────────────────────────────────────────────────────────
// Data Classes & UI Schemas
// ─────────────────────────────────────────────────────────────────────────────
data class ChatMessage(val role: String, val text: String, val isGenerating: Boolean = false, val searchProcess: String? = null)

@Serializable data class UiSchema(val title: String = "Untitled", val elements: List<UiElement> = emptyList())
@Serializable data class UiElement(val type: String, val id: String? = null, val text: String? = null, val hint: String? = null, val checked: Boolean = false, val children: List<UiElement> = emptyList())

@Composable
fun DynamicScreen(schema: UiSchema) {
    val textState     = remember { mutableStateMapOf<String, String>() }
    val checkboxState = remember { mutableStateMapOf<String, Boolean>() }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ObsColors.BgPanel),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(schema.title, color = ObsColors.TextPrime, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            schema.elements.forEachIndexed { index, el -> RenderElement(el, "el_$index", textState, checkboxState) }
        }
    }
}

@Composable
fun RenderElement(element: UiElement, fallbackId: String, textState: MutableMap<String, String>, checkboxState: MutableMap<String, Boolean>) {
    val id = element.id ?: fallbackId
    when (element.type.lowercase()) {
        "text" -> Text(element.text.orEmpty(), color = ObsColors.TextMuted)
        "heading" -> Text(element.text.orEmpty(), color = ObsColors.TextPrime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        "input" -> OutlinedTextField(
            value = textState[id].orEmpty(),
            onValueChange = { textState[id] = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(element.hint ?: element.text ?: "Input") },
            shape = RoundedCornerShape(10.dp),
            colors = makeTextFieldColors(ObsColors.BorderMid, ObsColors.InputBorder, ObsColors.TextPrime, ObsColors.TextPrime, ObsColors.TextPrime)
        )
        "button" -> Button(onClick = {}, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) { Text(element.text ?: "Button") }
        "checkbox" -> {
            val checked = checkboxState[id] ?: element.checked
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Checkbox(checked = checked, onCheckedChange = { checkboxState[id] = it })
                Text(element.text ?: "Checkbox", color = ObsColors.TextPrime)
            }
        }
        "card" -> Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                element.text?.let { Text(it, color = ObsColors.TextPrime, fontWeight = FontWeight.SemiBold) }
                element.children.forEachIndexed { index, child -> RenderElement(child, "$id-$index", textState, checkboxState) }
            }
        }
        "spacer" -> Spacer(modifier = Modifier.height(10.dp))
        else -> Text("Unsupported: ${element.type}", color = ObsColors.AccentRed)
    }
}

object ExampleSchemas {
    val login = """
{"title":"Simple Login","elements":[{"type":"text","text":"Sign in to continue."},{"type":"input","id":"email","hint":"Email address"},{"type":"input","id":"password","hint":"Password"},{"type":"checkbox","id":"remember","text":"Remember me","checked":true},{"type":"button","text":"Login"}]}
    """.trimIndent()
}

// ─────────────────────────────────────────────────────────────────────────────
// Validation Suite (preserved)
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun QualityValidationSuite() {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Rendering Quality and Math Validation Suite", color = ObsColors.TextPrime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Verifying LaTeX display math blocks, inline equations, and mixed markdown formatting.", color = ObsColors.TextMuted)
        ValidationCard("1. Basic Algebra", "Solving equations: 2x + 5 = 15, so x = 5. Quadratic formula: x = (-b +/- sqrt(b^2 - 4ac)) / 2a")
        ValidationCard("2. Calculus", "Derivative: d/dx[x^2 sin x] = 2x sin x + x^2 cos x. Integral: integral from 0 to 1 of 4/(1+x^2) dx = pi")
        ValidationCard("3. Linear Algebra", "det(A) != 0 ensures invertibility. Dot product u.v = 0 indicates orthogonality.")
        ValidationCard("4. Probability", "Bayes Theorem: P(A|B) = P(B|A) * P(A) / P(B)")
        ValidationCard("5. Physics", "Einstein: E = mc^2. Newton: F = G * (m1 * m2) / r^2")
        ValidationCard("6. Long Derivations", "Let S = sum from n=0 to infinity of r^n. Then S(1-r) = 1, so S = 1/(1-r) for |r| < 1.")
        ValidationCard("7. Mixed Content", "QED: Photon propagator D_munu(k) = (-i g_munu) / (k^2 + i epsilon). Code: q_field.sample(GBNF_sampler)")
        ValidationCard("8. Indefinite Integrals", "integral of x^3 dx = x^4/4 + C. integral of e^x dx = e^x + C")
    }
}

@Composable
private fun ValidationCard(title: String, content: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = ObsColors.TextMuted, fontWeight = FontWeight.Bold)
            LatexAwareText(content, color = ObsColors.TextPrime)
        }
    }
}