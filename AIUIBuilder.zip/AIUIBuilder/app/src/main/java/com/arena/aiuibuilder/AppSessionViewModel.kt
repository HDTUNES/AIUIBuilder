package com.arena.aiuibuilder

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * AppSessionViewModel — survives screen rotation via the AndroidX ViewModel lifecycle.
 *
 * All state that must NOT reset on orientation change lives here.
 * Compose observes it via collectAsState(). This is the correct pattern.
 */
class AppSessionViewModel(app: Application) : AndroidViewModel(app) {

    // ── Model state ──────────────────────────────────────────────────────────
    val selectedModelUri   = MutableStateFlow<Uri?>(null)
    val selectedModelName  = MutableStateFlow<String?>(null)
    val copiedModelPath    = MutableStateFlow<String?>(null)
    val isBusy             = MutableStateFlow(false)
    val statusText         = MutableStateFlow("Pick a GGUF model to begin.")
    val errorText          = MutableStateFlow<String?>(null)

    // ── Mode ─────────────────────────────────────────────────────────────────
    val selectedMode = MutableStateFlow("chat")  // "chat" | "cognitive_core"

    // ── Sampler / tuning ─────────────────────────────────────────────────────
    val threads        = MutableStateFlow(4)
    val contextSize    = MutableStateFlow(2048)
    val batchSize      = MutableStateFlow(256)
    val temperature    = MutableStateFlow(0.25f)
    val maxTokens      = MutableStateFlow(700)
    val topK           = MutableStateFlow(40)
    val topP           = MutableStateFlow(0.95f)
    val minP           = MutableStateFlow(0.05f)
    val repeatPenalty  = MutableStateFlow(1.1f)
    val refinePasses   = MutableStateFlow(1)
    val strictKvCache  = MutableStateFlow(false)
    val thinkingMode   = MutableStateFlow("OFF")  // OFF | AUTO | FORCE

    // ── Chat messages (survive rotation) ─────────────────────────────────────
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()
    val chatInput      = MutableStateFlow("")
    val chatWebSearch  = MutableStateFlow(false)
    val isGenerating   = MutableStateFlow(false)

    fun addMessage(msg: ChatMessage) {
        _chatMessages.value = _chatMessages.value + msg
    }
    fun updateLastMessage(transform: (ChatMessage) -> ChatMessage) {
        val list = _chatMessages.value.toMutableList()
        if (list.isNotEmpty()) {
            list[list.lastIndex] = transform(list.last())
            _chatMessages.value = list
        }
    }
    fun clearMessages() { _chatMessages.value = emptyList() }
}