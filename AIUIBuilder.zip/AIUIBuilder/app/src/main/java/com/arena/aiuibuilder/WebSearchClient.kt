package com.arena.aiuibuilder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class SearchResult(
    val id: Int,
    val title: String,
    val url: String,
    val snippet: String
)

object WebSearchClient {
    /**
     * Searches DuckDuckGo HTML Lite asynchronously without API keys.
     * Extracts top [limit] result titles, URLs, and snippets.
     */
    suspend fun search(query: String, limit: Int = 3): List<SearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val results = mutableListOf<SearchResult>()
        try {
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val url = URL("https://html.duckduckgo.com/html/?q=$encoded")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "en-US,en;q=0.5")
            }

            if (conn.responseCode == 200) {
                val html = conn.inputStream.bufferedReader().use { it.readText() }

                val snippetMatches = Regex("""<a class="result__snippet[^"]*"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL).findAll(html)
                val urlMatches = Regex("""<a class="result__url[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL).findAll(html)
                val titleMatches = Regex("""<a class="result__a[^"]*"[^>]*href="[^"]+"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL).findAll(html)

                val snippets = snippetMatches.map { stripHtml(it.groupValues[1]) }.toList()
                val urls = urlMatches.map { stripHtml(it.groupValues[1]).trim() }.toList()
                val titles = titleMatches.map { stripHtml(it.groupValues[1]) }.toList()

                val count = minOf(limit, snippets.size, titles.size)
                for (i in 0 until count) {
                    val u = if (i < urls.size && urls[i].startsWith("http")) urls[i] else "https://${urls.getOrNull(i) ?: "duckduckgo.com"}"
                    results.add(SearchResult(i + 1, titles[i], u, snippets[i]))
                }
            }
            conn.disconnect()
        } catch (e: Exception) {
            // Safe fallback if offline or timeout
        }
        results
    }

    private fun stripHtml(raw: String): String {
        return raw.replace(Regex("<[^>]*>"), "")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun formatGrounding(results: List<SearchResult>): String {
        if (results.isEmpty()) return ""
        return buildString {
            appendLine("[Live Web Search Context (Top ${results.size} Sources)]:")
            results.forEach { r ->
                appendLine("[${r.id}] Title: ${r.title}")
                appendLine("URL: ${r.url}")
                appendLine("Excerpt: ${r.snippet}")
                appendLine()
            }
            appendLine("Instruction: Use these verified live web facts to ground your reasoning.")
        }.trim()
    }

    fun extractKeywords(text: String): String {
        val clean = text.replace(Regex("[^A-Za-z0-9\\s]"), " ")
            .split(" ")
            .filter { it.length > 3 }
            .filterNot { it.lowercase() in stopWords }
            .take(6)
            .joinToString(" ")
        return clean.ifBlank { text.take(40) }
    }

    private val stopWords = setOf(
        "this", "that", "with", "from", "have", "would", "should", "could", "there", "their",
        "about", "which", "when", "what", "where", "next", "focus", "refined", "idea", "improve",
        "make", "more", "better", "analysis", "structural", "feasibility", "practicality"
    )
}
