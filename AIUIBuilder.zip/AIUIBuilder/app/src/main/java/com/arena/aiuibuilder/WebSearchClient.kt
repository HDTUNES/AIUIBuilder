package com.arena.aiuibuilder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SearchResult(
    val id: Int,
    val title: String,
    val url: String,
    val snippet: String,
    val score: Int = 0
)

object WebSearchClient {
    suspend fun search(query: String, limit: Int = 3): List<SearchResult> =
        searchWithFeedback(query, limit) {}

    suspend fun searchWithFeedback(
        query: String,
        limit: Int = 3,
        onProgress: (String) -> Unit
    ): List<SearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val rawCandidates = mutableListOf<SearchResult>()

        val isDatetimeQuery = query.contains("today", ignoreCase = true) ||
            query.contains("date", ignoreCase = true) ||
            query.contains("time", ignoreCase = true) ||
            query.contains("day", ignoreCase = true)

        onProgress("🌍 [Step 1/4] Connecting to Wikipedia Search REST API...")
        try {
            val enc = URLEncoder.encode(query.trim(), "UTF-8")
            val wikiUrl = URL("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$enc&utf8=&format=json&srlimit=8")
            val conn = (wikiUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("User-Agent", "AIUIBuilderStudio/1.0 (Android LocalAI)")
            }
            if (conn.responseCode == 200) {
                val jsonText = conn.inputStream.bufferedReader().use { it.readText() }
                val titleMatches = Regex("\"title\":\"([^\"]+)\"").findAll(jsonText)
                val snippetMatches = Regex("\"snippet\":\"([^\"]+)\"").findAll(jsonText)
                val titles = titleMatches.map { unescapeJson(it.groupValues[1]) }.toList()
                val snips = snippetMatches.map { trafilaturaSanitize(unescapeJson(it.groupValues[1])) }.toList()

                val count = minOf(titles.size, snips.size)
                for (i in 0 until count) {
                    val u = "https://en.wikipedia.org/wiki/" + URLEncoder.encode(titles[i].replace(" ", "_"), "UTF-8")
                    rawCandidates.add(SearchResult(rawCandidates.size + 1, "Wikipedia: ${titles[i]}", u, snips[i]))
                }
                onProgress("📚 Extracted ${rawCandidates.size} articles from Wikipedia.")
            }
            conn.disconnect()
        } catch (e: Exception) {
            AppLog.append("Wiki search error: ${e.message}")
            onProgress("⚠️ Wikipedia API error: ${e.message}")
        }

        onProgress("🦆 [Step 2/4] Querying DuckDuckGo Instant Answers...")
        try {
            val enc = URLEncoder.encode(query.trim(), "UTF-8")
            val ddgUrl = URL("https://api.duckduckgo.com/?q=$enc&format=json&no_html=1")
            val conn = (ddgUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("User-Agent", "AIUIBuilderStudio/1.0")
            }
            if (conn.responseCode == 200) {
                val jsonText = conn.inputStream.bufferedReader().use { it.readText() }
                val headingMatch = Regex("\"Heading\":\"([^\"]+)\"").find(jsonText)
                val abstractMatch = Regex("\"AbstractText\":\"([^\"]+)\"").find(jsonText)
                val urlMatch = Regex("\"AbstractURL\":\"([^\"]+)\"").find(jsonText)
                if (headingMatch != null && abstractMatch != null && abstractMatch.groupValues[1].isNotBlank()) {
                    val h = unescapeJson(headingMatch.groupValues[1])
                    val abs = trafilaturaSanitize(unescapeJson(abstractMatch.groupValues[1]))
                    val u = urlMatch?.let { unescapeJson(it.groupValues[1]) } ?: "https://duckduckgo.com/?q=$enc"
                    rawCandidates.add(SearchResult(rawCandidates.size + 1, "DuckDuckGo: $h", u, abs))
                }
            }
            conn.disconnect()
        } catch (e: Exception) { AppLog.append("DDG search error: ${e.message}") }

        if (isDatetimeQuery || rawCandidates.isEmpty()) {
            val now = SimpleDateFormat("EEEE, MMMM dd, yyyy HH:mm:ss z", Locale.getDefault()).format(Date())
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            rawCandidates.add(
                SearchResult(
                    id = rawCandidates.size + 1,
                    title = "Authoritative Host Application System Clock",
                    url = "host://system-clock-authoritative",
                    snippet = "Current Authoritative Today Date: $todayStr ($now). Location: India/Asia. Note: Ignore pre-trained training cutoff dates.",
                    score = 100
                )
            )
        }

        onProgress("📊 [Step 3/4] Scoring & Ranking ${rawCandidates.size} candidates by Keyword Overlap...")
        val ranked = rankAndScore(query, rawCandidates, limit)

        onProgress("✅ [Step 4/4] Top ${ranked.size} Sources Verified & Ready for Prompt Injection:\n" +
            ranked.joinToString("\n") { "[${it.id}] ${it.title} (Score: ${it.score})" })

        AppLog.append("WebSearchClient ranked final: " + ranked.map { "${it.title}(score=${it.score})" })
        ranked
    }

    private fun rankAndScore(query: String, candidates: List<SearchResult>, limit: Int): List<SearchResult> {
        val qWords = query.lowercase().replace(Regex("[^a-z0-9\\s]"), " ").split(" ").filter { it.length > 2 }.filterNot { it in stopWords }
        val scored = candidates.map { res ->
            if (res.url.startsWith("host://")) return@map res to res.score
            val text = "${res.title} ${res.snippet}".lowercase()
            val overlap = qWords.count { word -> text.contains(word) }
            val phraseBonus = if (text.contains(query.lowercase().trim())) 10 else 0
            val titleBonus = if (qWords.any { res.title.lowercase().contains(it) }) 4 else 0
            val total = overlap * 3 + phraseBonus + titleBonus + 1
            res.copy(score = total) to total
        }.sortedByDescending { it.second }

        return scored.take(limit).mapIndexed { idx, pair -> pair.first.copy(id = idx + 1) }
    }

    private fun trafilaturaSanitize(raw: String): String {
        return raw.replace(Regex("<(script|style|nav|header|footer|aside)[^>]*>.*?</(script|style|nav|header|footer|aside)>", RegexOption.DOT_MATCHES_ALL), "")
            .replace(Regex("<[^>]*>"), "")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun unescapeJson(raw: String): String {
        return raw.replace("\\\"", "\"")
            .replace("\\/", "/")
            .replace("\\n", " ")
            .replace("\\t", " ")
            .replace("\\\\", "\\")
    }

    fun formatGrounding(results: List<SearchResult>): String {
        if (results.isEmpty()) return ""
        return buildString {
            appendLine("[MANDATORY HARD CONTEXT INJECTION (Top ${results.size} Factual Sources)]:")
            results.forEach { r ->
                appendLine("[${r.id}] Title: ${r.title} (Relevance Score: ${r.score})")
                appendLine("URL: ${r.url}")
                appendLine("Article Content: ${r.snippet}")
                appendLine()
            }
            appendLine("CRITICAL RESTRICTION: You are strictly restricted to answering the user prompt using ONLY the verified article facts above. Do NOT guess. Do NOT claim you lack real-time access or state your training cutoff date.")
        }.trim()
    }

    fun extractKeywords(text: String): String {
        val clean = text.replace(Regex("[^A-Za-z0-9\\s]"), " ")
            .split(" ")
            .filter { it.length > 3 }
            .filterNot { it.lowercase() in stopWords }
            .take(6)
            .joinToString(" ")
        return clean.ifBlank { text.take(40) }
    }

    private val stopWords = setOf(
        "this", "that", "with", "from", "have", "would", "should", "could", "there", "their",
        "about", "which", "when", "what", "where", "next", "focus", "refined", "idea", "improve",
        "make", "more", "better", "analysis", "structural", "feasibility", "practicality", "recent", "news"
    )
}
