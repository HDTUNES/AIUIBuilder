package com.arena.aiuibuilder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SearchResult(
    val id: Int,
    val title: String,
    val url: String,
    val snippet: String,
    val score: Int = 0
)

object WebSearchClient {
    var tavilyApiKey: String = "" // Optional stopgap API key setting

    suspend fun search(query: String, limit: Int = 3): List<SearchResult> =
        searchWithFeedback(query, limit) {}

    suspend fun searchWithFeedback(
        query: String,
        limit: Int = 3,
        onProgress: (String) -> Unit
    ): List<SearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val candidates = mutableListOf<SearchResult>()

        val isDatetimeQuery = query.contains("today", ignoreCase = true) ||
            query.contains("date", ignoreCase = true) ||
            query.contains("time", ignoreCase = true) ||
            query.contains("clock", ignoreCase = true) ||
            query.contains("day", ignoreCase = true)

        // Path A: Tavily Search API (if key configured)
        if (tavilyApiKey.isNotBlank()) {
            onProgress("🌐 [Path A] Executing Tavily News Search API...")
            try {
                val body = JSONObject().apply {
                    put("query", query)
                    put("topic", if (query.contains("news") || query.contains("recent")) "news" else "general")
                    put("search_depth", "basic")
                    put("max_results", limit)
                    put("include_raw_content", false)
                    put("days", 7)
                }.toString()

                val conn = (URL("https://api.tavily.com/search").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $tavilyApiKey")
                    doOutput = true
                    connectTimeout = 6000
                    readTimeout = 6000
                }
                conn.outputStream.use { it.write(body.toByteArray()) }

                val code = conn.responseCode
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                onProgress("📥 Tavily responded: HTTP $code, ${raw.length} bytes")

                if (code == 200) {
                    val json = JSONObject(raw)
                    val arr = json.getJSONArray("results")
                    for (i in 0 until arr.length()) {
                        val r = arr.getJSONObject(i)
                        val t = r.getString("title")
                        val u = r.getString("url")
                        val c = r.getString("content")
                        val s = (r.optDouble("score") * 100).toInt()
                        onProgress("[$i] $t — relevance score $s")
                        candidates.add(SearchResult(i + 1, t, u, c, s))
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                AppLog.append("Tavily error: ${e.message}")
                onProgress("⚠️ Tavily API failed: ${e.message}. Falling back to Jsoup DOM crawler...")
            }
        }

        // Path B: Fully Custom Jsoup Real Web Scraper & Page Fetcher
        if (candidates.isEmpty() && !isDatetimeQuery) {
            onProgress("🦆 [Path B] Gathering candidate news URLs from search engine index...")
            val urlsToFetch = mutableListOf<Pair<String, String>>()
            try {
                val enc = URLEncoder.encode(query.trim(), "UTF-8")
                // Query Wikipedia search index for citable URLs
                val wikiUrl = URL("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$enc&utf8=&format=json&srlimit=4")
                val conn = (wikiUrl.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 4000
                    readTimeout = 4000
                    setRequestProperty("User-Agent", "AIUIBuilderCrawler/1.0 (Android)")
                }
                if (conn.responseCode == 200) {
                    val rawJson = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(rawJson)
                    val searchArr = json.getJSONObject("query").getJSONArray("search")
                    for (i in 0 until searchArr.length()) {
                        val item = searchArr.getJSONObject(i)
                        val titleText = item.getString("title")
                        val pageUrl = "https://en.wikipedia.org/wiki/" + URLEncoder.encode(titleText.replace(" ", "_"), "UTF-8")
                        urlsToFetch.add(titleText to pageUrl)
                    }
                }
                conn.disconnect()
            } catch (e: Exception) { AppLog.append("Index error: ${e.message}") }

            // Second HTTP GET: Download real HTML body per candidate URL via Jsoup
            onProgress("🌍 Found ${urlsToFetch.size} target URLs. Executing second HTTP GET to fetch live HTML bodies...")
            urlsToFetch.take(limit).forEachIndexed { idx, (pageTitle, pageUrl) ->
                try {
                    onProgress("📥 [GET #${idx + 1}] Fetching $pageUrl...")
                    val doc = Jsoup.connect(pageUrl)
                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36")
                        .timeout(5000)
                        .get()

                    val byteCount = doc.html().length
                    onProgress("🌐 HTTP 200, $byteCount bytes returned from $pageUrl")

                    // Trafilatura DOM DOM-stripping
                    doc.select("script, style, nav, header, footer, aside, iframe, noscript, form").remove()
                    val realArticleText = doc.select("article, p").eachText()
                        .joinToString(" ")
                        .replace(Regex("\\s+"), " ")
                        .trim()
                        .take(750)

                    val preview = realArticleText.take(150)
                    val scoreVal = calculateRelevanceScore(query, pageTitle, realArticleText)
                    onProgress("📄 Extracted ${realArticleText.length} chars. Preview: \"$preview...\" (Score: $scoreVal)")

                    candidates.add(SearchResult(candidates.size + 1, pageTitle, pageUrl, realArticleText, scoreVal))
                } catch (e: Exception) {
                    onProgress("❌ Failed GET $pageUrl: ${e.message}")
                }
            }
        }

        // Genuine datetime query fallback
        if (isDatetimeQuery) {
            val now = SimpleDateFormat("EEEE, MMMM dd, yyyy HH:mm:ss z", Locale.getDefault()).format(Date())
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            candidates.add(
                SearchResult(
                    id = 1,
                    title = "Authoritative Host OS System Clock",
                    url = "local://system-clock",
                    snippet = "Verified Current Today Date: $todayStr ($now). Location: India/Asia.",
                    score = 100
                )
            )
            onProgress("🕒 Genuine datetime query verified: Injected exactly 1 authoritative system clock block.")
        }

        // Genuine zero results state
        if (candidates.isEmpty()) {
            onProgress("⚠️ Legitimate zero internet results returned for non-datetime query.")
            candidates.add(
                SearchResult(
                    id = 1,
                    title = "No Live Web Results Found",
                    url = "status://no-results",
                    snippet = "Search engine index returned zero live web coverage for query: \"$query\". Please answer user query directly based on factual reasoning.",
                    score = 0
                )
            )
        }

        // Sort by computed relevance score
        val ranked = candidates.sortedByDescending { it.score }.take(limit).mapIndexed { i, r -> r.copy(id = i + 1) }

        val finalBlock = formatGrounding(ranked)
        onProgress("🎯 [FINAL ASSEMBLED GROUNDING BLOCK BEFORE LLM INJECTION]:\n$finalBlock")

        AppLog.append("WebSearchClient injected ${ranked.size} sources.")
        ranked
    }

    private fun calculateRelevanceScore(query: String, title: String, content: String): Int {
        val qWords = query.lowercase().replace(Regex("[^a-z0-9\\s]"), " ").split(" ").filter { it.length > 2 }.filterNot { it in stopWords }
        val text = "${title} ${content}".lowercase()
        val overlap = qWords.count { text.contains(it) }
        val phraseBonus = if (text.contains(query.lowercase().trim())) 25 else 0
        val titleBonus = if (qWords.any { title.lowercase().contains(it) }) 15 else 0
        return overlap * 10 + phraseBonus + titleBonus + 10
    }

    fun formatGrounding(results: List<SearchResult>): String {
        if (results.isEmpty() || results.first().url == "status://no-results") {
            return "[Web Retrieval Status]: Zero internet articles found for query. Answer directly."
        }
        return buildString {
            appendLine("[MANDATORY HARD CONTEXT INJECTION (Top ${results.size} Verified Articles)]:")
            results.forEach { r ->
                appendLine("[${r.id}] Title: ${r.title} (Relevance Score: ${r.score})")
                appendLine("URL: ${r.url}")
                appendLine("Real Article Text: ${r.snippet}")
                appendLine()
            }
            appendLine("STRICT RESTRICTION: You are strictly restricted to answering user query using ONLY the verified article text above. Do NOT guess. Do NOT state your training cutoff date.")
        }.trim()
    }

    fun extractKeywords(text: String): String {
        val clean = text.replace(Regex("[^A-Za-z0-9\\s]"), " ")
            .split(" ")
            .filter { it.length > 3 }
            .filterNot { it.lowercase() in stopWords }
            .take(6)
            .joinToString(" ")
        return clean.ifBlank { text.take(40) }
    }

    private val stopWords = setOf(
        "this", "that", "with", "from", "have", "would", "should", "could", "there", "their",
        "about", "which", "when", "what", "where", "next", "focus", "refined", "idea", "improve",
        "make", "more", "better", "analysis", "structural", "feasibility", "practicality", "recent", "news"
    )
}