package com.arena.aiuibuilder

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Reasoning Operators — the atomic actions of the cognitive engine.
 *
 * Each operator builds a tight, structured prompt, calls the LLM once,
 * and parses the result into a structured OperatorResult.
 */

@Serializable
data class OperatorResult(
    val operator: String,
    val output: String,
    val structured: Map<String, String> = emptyMap(),
    val confidence: Float = 0.75f,
    val surprise: Float = 0.0f,
    val subgoals: List<String> = emptyList()
)

object ReasoningOperators {

    private val json = Json { ignoreUnknownKeys = true }

    // -----------------------------------------------------------------------
    // 1. ORIENT — parse the problem, extract unknowns, detect confusion
    // -----------------------------------------------------------------------
    fun buildOrientPrompt(query: String, relevantMemory: String): String = """
        |You are MESA, a systematic reasoning engine. Read the following question carefully.
        |
        |QUESTION: $query
        |
        |RELEVANT PRIOR KNOWLEDGE:
        |$relevantMemory
        |
        |Task: produce a JSON object with exactly these fields:
        |  "topic": the main topic in 3-6 words
        |  "unknowns": list of 1-3 specific things we need to figure out
        |  "confusion_level": "low" | "medium" | "high"
        |  "needed_knowledge": list of 1-3 concepts we should verify we understand
        |  "next_operator": "DECOMPOSE" | "FIRST_PRINCIPLES" | "RETRIEVE" | "ANALOGIZE"
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 2. DECOMPOSE — break complex problem into chunks
    // -----------------------------------------------------------------------
    fun buildDecomposePrompt(query: String, orientation: OperatorResult): String = """
        |You are MESA. Break the following question into 3-5 small, independent sub-problems.
        |
        |QUESTION: $query
        |TOPIC: ${orientation.structured["topic"] ?: "unknown"}
        |UNKNOWNS: ${orientation.structured["unknowns"] ?: ""}
        |
        |Rules:
        |  - Each sub-problem should be solvable in one short step.
        |  - Sub-problems should not overlap.
        |  - Order them logically (what must be solved first).
        |
        |Output ONLY a JSON array of objects with fields:
        |  "id": "c1", "c2", ...
        |  "question": the sub-question text
        |  "operator_hint": "SOLVE_CHUNK" | "VERIFY" | "EXECUTE"
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 3. FIRST_PRINCIPLES — reduce to foundational causes
    // -----------------------------------------------------------------------
    fun buildFirstPrinciplesPrompt(query: String): String = """
        |You are MESA. The user is lost on a complex topic. Help them ground it from first principles.
        |
        |TOPIC: $query
        |
        |Task: produce a JSON object with exactly these fields:
        |  "base_problem": what fundamental problem this topic was invented to solve
        |  "causal_chain": 2-4 sentences walking backward from the topic to its root cause
        |  "simplest_case": a concrete minimal example or base case
        |  "core_principle": one sentence summarizing the invariant/law/pattern involved
        |  "rebuild_step": the first small step toward reconstructing the topic from the base case
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 4. ANALOGIZE — cross-domain structure mapping
    // -----------------------------------------------------------------------
    fun buildAnalogizePrompt(query: String, sourceDomain: String, targetDomain: String): String = """
        |You are MESA. Find a useful analogy between two domains to understand the topic.
        |
        |TOPIC: $query
        |SOURCE DOMAIN: $sourceDomain
        |TARGET DOMAIN: $targetDomain
        |
        |Task: produce a JSON object with exactly these fields:
        |  "source_concept": concept in source domain
        |  "target_concept": analogous concept in target domain
        |  "mapping": list of 2-4 specific component mappings (e.g., "X in source is like Y in target")
        |  "insight": one sentence explaining what the analogy reveals about the topic
        |  "limit": one sentence explaining where the analogy breaks down
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 5. SOLVE_CHUNK — solve one small sub-problem
    // -----------------------------------------------------------------------
    fun buildSolveChunkPrompt(chunkQuestion: String, priorChunks: String, memory: String): String = """
        |You are MESA. Solve ONE small sub-problem concretely.
        |
        |SUB-PROBLEM: $chunkQuestion
        |
        |PRIOR SUB-PROBLEM RESULTS:
        |$priorChunks
        |
        |RELEVANT MEMORY:
        |$memory
        |
        |Task: produce a JSON object with exactly these fields:
        |  "answer": a concise, specific answer (max 200 chars)
        |  "confidence": "low" | "medium" | "high"
        |  "falsifiable_claim": one claim from the answer that could be tested (or empty string)
        |  "needs_code_test": true or false
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 6. VERIFY — internal consistency + external reality check prompt
    // -----------------------------------------------------------------------
    fun buildVerifyPrompt(claim: String, evidence: String): String = """
        |You are MESA. Verify the following claim against available evidence.
        |
        |CLAIM: $claim
        |
        |EVIDENCE / SEARCH RESULTS:
        |$evidence
        |
        |Task: produce a JSON object with exactly these fields:
        |  "verdict": "SUPPORTED" | "PARTIALLY_SUPPORTED" | "CONTRADICTED" | "UNCERTAIN"
        |  "objection": strongest objection if any (max 120 chars)
        |  "confidence": 0.0 to 1.0
        |  "suggested_operator": "EXECUTE" | "SEARCH" | "SOLVE_CHUNK" | "INTEGRATE"
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 7. EXECUTE — generate code to test a claim
    // -----------------------------------------------------------------------
    fun buildExecutePrompt(claim: String): String = """
        |You are MESA. Generate a tiny JavaScript snippet that tests this claim numerically or logically.
        |
        |CLAIM: $claim
        |
        |Rules:
        |  - Use only basic JS (no external libraries, no fetch, no DOM).
        |  - The script must return a single string or number result.
        |  - Keep it under 10 lines.
        |
        |Output ONLY the raw JavaScript code, nothing else.
    """.trimMargin()

    /**
     * Wrap generated test code in a safe IIFE so it can be executed in the WebView sandbox.
     */
    fun wrapTestCode(generatedCode: String): String {
        return """
            (function(){
                var console = { log: function(){} };
                ${generatedCode.trim()}
            })()
        """.trimIndent()
    }

    /**
     * Quick arithmetic test extraction for simple numeric claims.
     */
    fun generateArithmeticTest(claim: String): String? {
        val exprMatch = Regex("(\\d+\\s*[+\\-*/^]\\s*\\d+)\\s*=\\s*(\\d+)").find(claim)
        if (exprMatch != null) {
            val expr = exprMatch.groupValues[1].replace("^", "**")
            val expected = exprMatch.groupValues[2]
            return "return ($expr === $expected) ? 'TRUE' : 'FALSE: expected $expected, got ' + ($expr);"
        }
        return null
    }

    // -----------------------------------------------------------------------
    // 8. INTEGRATE — synthesize sub-problem answers into final answer
    // -----------------------------------------------------------------------
    fun buildIntegratePrompt(query: String, chunks: String, originalGoal: String): String = """
        |You are MESA. Synthesize the following solved sub-problems into a coherent final answer.
        |
        |ORIGINAL QUESTION: $query
        |
        |SOLVED SUB-PROBLEMS:
        |$chunks
        |
        |Task: produce a JSON object with exactly these fields:
        |  "summary": a 1-2 sentence high-level summary
        |  "answer": the detailed final answer, structured in clear steps
        |  "key_insight": the most important insight (1 sentence)
        |  "confidence": 0.0 to 1.0
        |  "remaining_uncertainty": one remaining uncertainty or empty string
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 9. REFLECT — metacognitive pause
    // -----------------------------------------------------------------------
    fun buildReflectPrompt(query: String, history: String): String = """
        |You are MESA. You have been working on this problem and may be stuck. Reflect.
        |
        |QUESTION: $query
        |
        |RECENT HISTORY:
        |$history
        |
        |Task: produce a JSON object with exactly these fields:
        |  "diagnosis": why we are stuck (max 120 chars)
        |  "best_next_action": "DECOMPOSE" | "FIRST_PRINCIPLES" | "ANALOGIZE" | "VERIFY" | "STOP"
        |  "new_angle": one concrete, different angle to try (max 120 chars)
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // Parsing helpers
    // -----------------------------------------------------------------------
    fun parseJsonObject(raw: String): Map<String, String> {
        return try {
            json.decodeFromString<Map<String, String>>(raw)
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun parseJsonArray(raw: String): List<Map<String, String>> {
        return try {
            json.decodeFromString<List<Map<String, String>>>(raw)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun extractJson(raw: String): String {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start >= 0 && end > start) return raw.substring(start, end + 1)
        val arrStart = raw.indexOf('[')
        val arrEnd = raw.lastIndexOf(']')
        if (arrStart >= 0 && arrEnd > arrStart) return raw.substring(arrStart, arrEnd + 1)
        return raw
    }

    /**
     * Simple regex salvage for critical fields when JSON is malformed.
     */
    fun salvageField(raw: String, key: String): String? {
        val pattern = Regex(""""$key"\s*:\s*"([^"]+)"""")
        return pattern.find(raw)?.groupValues?.get(1)
    }
}
