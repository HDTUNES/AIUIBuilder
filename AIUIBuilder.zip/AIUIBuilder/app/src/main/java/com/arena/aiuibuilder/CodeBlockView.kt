package com.arena.aiuibuilder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CodeBg = Color(0xFF1E1E1E)
private val CodeHeaderBg = Color(0xFF2A2A2A)
private val TrafficRed = Color(0xFFFF5F56)
private val TrafficYellow = Color(0xFFFFBD2E)
private val TrafficGreen = Color(0xFF27C93F)
private val CodeDefaultText = Color(0xFFABB2BF)
private val KEYWORD = Color(0xFFC678DD)
private val FUNCTION = Color(0xFF61AFEF)
private val STRING = Color(0xFF98C379)
private val NUMBER = Color(0xFFD19A66)
private val COMMENT = Color(0xFF5C6370)

private val KEYWORDS_BY_LANG: Map<String, Set<String>> = mapOf(
    "kotlin" to setOf("fun","val","var","if","else","when","for","while","return","class","object","interface","import","package","private","public","suspend","companion","data","is","in","null","true","false","try","catch","finally"),
    "python" to setOf("def","class","import","from","return","if","elif","else","for","while","try","except","finally","with","as","lambda","yield","None","True","False","and","or","not","in","is"),
    "javascript" to setOf("function","const","let","var","if","else","for","while","return","class","import","export","from","async","await","try","catch","finally","new","this","null","undefined","true","false"),
    "java" to setOf("public","private","protected","class","interface","void","static","final","if","else","for","while","return","new","try","catch","finally","import","package","true","false","null"),
    "bash" to setOf("if","then","else","fi","for","while","do","done","function","echo","export","return"),
    "json" to emptySet(),
    "text" to emptySet()
)

private val COMMENT_PATTERN = Regex("(//.*|#.*|<!--.*?-->)")
private val STRING_PATTERN = Regex("(\"(?:[^\"\\\\]|\\\\.)*\"|'(?:[^'\\\\]|\\\\.)*')")
private val NUMBER_PATTERN = Regex("\\b\\d+(\\.\\d+)?\\b")
private val FUNCTION_CALL_PATTERN = Regex("([A-Za-z_][A-Za-z0-9_]*)\\s*(?=\\()")

private fun highlightLine(line: String, language: String): AnnotatedString {
    val keywords = KEYWORDS_BY_LANG[language.lowercase()] ?: emptySet()
    return buildAnnotatedString {
        var i = 0
        val commentMatch = COMMENT_PATTERN.find(line)
        val end = commentMatch?.range?.first ?: line.length
        while (i < end) {
            val str = STRING_PATTERN.find(line, i)?.takeIf { it.range.first < end }
            val num = NUMBER_PATTERN.find(line, i)?.takeIf { it.range.first < end }
            val fn = FUNCTION_CALL_PATTERN.find(line, i)?.takeIf { it.range.first < end }
            val next = listOfNotNull(str, num, fn).minByOrNull { it.range.first }
            if (next == null) {
                appendPlainOrKeyword(line.substring(i, end), keywords)
                i = end
            } else {
                if (next.range.first > i) appendPlainOrKeyword(line.substring(i, next.range.first), keywords)
                val c = when {
                    next == str -> STRING
                    next == num -> NUMBER
                    else -> FUNCTION
                }
                withStyle(SpanStyle(color = c)) { append(next.value) }
                i = next.range.last + 1
            }
        }
        if (commentMatch != null) withStyle(SpanStyle(color = COMMENT)) { append(line.substring(end)) }
    }
}

private fun AnnotatedString.Builder.appendPlainOrKeyword(text: String, keywords: Set<String>) {
    if (keywords.isEmpty()) { append(text); return }
    Regex("([A-Za-z_][A-Za-z0-9_]*)|([^A-Za-z_]+)").findAll(text).forEach { m ->
        val w = m.value
        if (w in keywords) withStyle(SpanStyle(color = KEYWORD)) { append(w) } else append(w)
    }
}

@Composable
fun CodeBlockView(language: String, code: String, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(elevation = 8.dp, shape = RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(CodeBg)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().background(CodeHeaderBg).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(TrafficRed, TrafficYellow, TrafficGreen).forEach { c ->
                    Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(c))
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(language.replaceFirstChar { it.uppercase() }, color = CodeDefaultText.copy(alpha = 0.7f), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.width(12.dp))
            Text("Copy", color = CodeDefaultText.copy(alpha = 0.7f), fontSize = 11.sp, modifier = Modifier.clickable { clipboard.setText(AnnotatedString(code)) })
        }
        Box(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
            Column {
                code.split("\n").forEach { line ->
                    Text(
                        text = highlightLine(line, language),
                        color = CodeDefaultText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        fontWeight = AppTypography.CodeWeight
                    )
                }
            }
        }
    }
}
