package com.arena.aiuibuilder

import androidx.compose.runtime.mutableStateMapOf
import android.os.Looper
import android.os.Handler

/**
 * V4.1 BrainStage bridge for ObservatoriumSession
 * Keeps legacy PipelineStage intact, adds BrainStage side-channel
 */
private val brainHandler = Handler(Looper.getMainLooper())
private val brainStageMapInternal = mutableStateMapOf<BrainStage, String>()
private val brainStageStatusInternal = mutableStateMapOf<BrainStage, StageStatus>()

val ObservatoriumSession.brainStageMap: Map<BrainStage, String>
    get() = brainStageMapInternal

fun ObservatoriumSession.setStage(stage: BrainStage, note: String = "") {
    // update brain map
    val r = Runnable {
        brainStageMapInternal[stage] = note
        brainStageStatusInternal[stage] = StageStatus.ACTIVE
        // clear previous active -> completed
        BrainStage.values().forEach { s ->
            if (s != stage && brainStageStatusInternal[s] == StageStatus.ACTIVE) {
                brainStageStatusInternal[s] = StageStatus.COMPLETED
            }
        }
    }
    if (Looper.myLooper() == Looper.getMainLooper()) r.run() else brainHandler.post(r)
    // also push to ThinkingStream + AppLog
    try {
        ThinkingStream.appendLine(stage.name, note)
        AppLog.logUi("BRAIN_STAGE", "$stage $note")
    } catch(_:Throwable){}
    // Map to legacy PipelineStage for old UI that still observes stageMap
    try {
        val legacy = when(stage) {
            BrainStage.SYSTEM_PROMPT, BrainStage.INTENT_ANALYSIS, BrainStage.CONCEPT_EXTRACTION, BrainStage.WORLD_MODEL_ASSEMBLY -> PipelineStage.SYSTEM_PROMPT_ASSEMBLY
            BrainStage.MEMORY_RETRIEVAL -> PipelineStage.MEMORY_RETRIEVAL
            BrainStage.GOAL_SELECTION -> PipelineStage.GOAL_SELECTION
            BrainStage.ARCHIVE_REVIEW -> PipelineStage.ARCHIVE_REVIEW
            BrainStage.HYPOTHESIS_GEN, BrainStage.INVARIANT_CHECK, BrainStage.PERIPHERAL_SCAN, BrainStage.CONCEPT_MATCH -> PipelineStage.HYPOTHESIS_GENERATION
            BrainStage.CODE_EXEC -> PipelineStage.CODE_EXECUTION
            BrainStage.VERIFY_TEST -> PipelineStage.VERIFICATION_TESTING
            BrainStage.REPAIR_RETRY, BrainStage.FREEZE_CHECKPOINT, BrainStage.BRAKE_EVAL -> PipelineStage.REPAIR_RETRY
            BrainStage.PERSISTENCE -> PipelineStage.PERSISTENCE_SNAPSHOT
        }
        updateStage(StageDiagnostics(stage = legacy, status = StageStatus.ACTIVE, outputSummary = note))
    } catch(_:Throwable){}
}

fun ObservatoriumSession.resetBrainStages() {
    brainHandler.post {
        brainStageMapInternal.clear()
        brainStageStatusInternal.clear()
        BrainStage.values().forEach { brainStageStatusInternal[it] = StageStatus.PENDING }
    }
}

// Called from ObservatoriumSession.resetForNewIteration via side-effect hook
// We patch resetForNewIteration at runtime? Simpler: UnifiedBrainEngine calls this explicitly
fun ObservatoriumSession.resetForNewBrainIteration(iterNum: Int) {
    currentIterationNumber = iterNum
    liveTokenStream = ""
    resetBrainStages()
    // also reset legacy pipeline for old UI compat
    resetForNewIteration(iterNum)
}

// Helper for LiveObservatoryUi V4
fun BrainStage.isActiveIn(session: ObservatoriumSession): Boolean {
    return brainStageStatusInternal[this] == StageStatus.ACTIVE
}
fun BrainStage.noteIn(session: ObservatoriumSession): String {
    return brainStageMapInternal[this] ?: ""
}
