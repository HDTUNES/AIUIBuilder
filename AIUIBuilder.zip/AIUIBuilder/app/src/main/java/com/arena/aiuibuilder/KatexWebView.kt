package com.arena.aiuibuilder

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

private class HeightCache(private val maxEntries: Int = 200) {
    private val map = object : LinkedHashMap<String, Int>(maxEntries, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Int>?) = size > maxEntries
    }
    @Synchronized fun get(key: String): Int? = map[key]
    @Synchronized fun put(key: String, value: Int) { map[key] = value }
}

private val katexHeightCache = HeightCache()
private fun cacheKey(latex: String, displayMode: Boolean, colorArgb: Int) = "$displayMode|$colorArgb|$latex"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun KatexMath(latex: String, displayMode: Boolean, color: Color, modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    val colorArgb = color.toArgb()
    val key = remember(latex, displayMode, colorArgb) { cacheKey(latex, displayMode, colorArgb) }
    var heightPx by remember(key) { mutableStateOf(katexHeightCache.get(key) ?: -1) }
    var timedOut by remember(key) { mutableStateOf(false) }

    LaunchedEffect(key) {
        delay(2500)
        if (heightPx <= 0) timedOut = true
    }

    if (timedOut) {
        Text(
            beautifyLatex(latex),
            color = color,
            fontSize = if (displayMode) 16.sp else 14.sp,
            modifier = modifier
        )
        return
    }

    val colorHex = remember(colorArgb) { String.format("#%06X", 0xFFFFFF and colorArgb) }
    val heightDp = if (heightPx > 0) with(density) { heightPx.toDp() } else if (displayMode) 48.dp else 24.dp

    AndroidView(
        modifier = modifier.fillMaxWidth().height(heightDp),
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = false
                addJavascriptInterface(object {
                    @JavascriptInterface
                    fun onHeight(px: Float) {
                        val rounded = px.toInt().coerceAtLeast(1)
                        katexHeightCache.put(key, rounded)
                        post { heightPx = rounded }
                    }
                }, "AndroidBridge")
                loadUrl("file:///android_asset/katex/render.html")
            }
        },
        update = { webView ->
            val escaped = org.json.JSONObject.quote(latex)
            webView.evaluateJavascript("renderMath($escaped, $displayMode, '$colorHex')", null)
        }
    )
}
