package com.arena.aiuibuilder

import kotlin.math.max

/**
 * Metacognitive Monitor: the "System 2" oversight layer.
 *
 * Tracks:
 *   - progress toward the active goal
 *   - stuckness / repetition
 *   - confidence calibration
 *   - compute budget
 *   - which reasoning strategy to use next
 */

enum class StrategySignal {
    CONTINUE,           // keep going with current operator
    DECOMPOSE,          // problem is too big; break it down
    FIRST_PRINCIPLES,   // reduce to foundational causes
    ANALOGIZE,          // switch to cross-domain analogy
    VERIFY,             // pause and reality-check
    REFLECT,            // explicit metacognitive pause
    SAVE_NOTE,          // memory load high; externalize insight to disk
    RETRIEVE_NOTE,      // relevant archived/disk note may exist
    INTEGRATE,          // enough chunks exist; synthesize answer
    STOP                // budget exhausted or answer complete
}

data class MonitorState(
    val iteration: Int,
    val goalStackDepth: Int,
    val recentOperators: List<String>,
    val recentSurprises: List<Float>,
    val averageConfidence: Float,
    val budgetRemaining: Float // 0..1
)

object MetacognitiveMonitor {

    private const val STUCK_WINDOW = 4
    private const val STUCK_THRESHOLD = 0.72f // Jaccard overlap
    private const val SURPRISE_FLOOR = 0.15f
    private const val MAX_ITERATIONS = 20

    private var totalIterations = 0
    private var consecutiveStuck = 0
    private var consecutiveNoProgress = 0
    private val operatorHistory = ArrayDeque<String>(STUCK_WINDOW * 2)
    private val surpriseHistory = ArrayDeque<Float>(STUCK_WINDOW)
    private var lastSolvedChunkCount = 0

    // Enhanced executive control tracking
    private val confidenceHistory = ArrayDeque<Float>(STUCK_WINDOW)
    private val noveltyHistory = ArrayDeque<Float>(STUCK_WINDOW)
    private var distinctOperatorsUsed = mutableSetOf<String>()
    private var consecutiveLowConfidence = 0

    fun reset() {
        totalIterations = 0
        consecutiveStuck = 0
        consecutiveNoProgress = 0
        operatorHistory.clear()
        surpriseHistory.clear()
        lastSolvedChunkCount = 0
        confidenceHistory.clear()
        noveltyHistory.clear()
        distinctOperatorsUsed.clear()
        consecutiveLowConfidence = 0
    }

    /**
     * Decide what to do next given the current cycle state.
     */
    fun decideNext(
        goalStackDepth: Int,
        lastOperator: String,
        lastOutput: String,
        lastSurprise: Float,
        confidence: Float,
        chunkCount: Int,
        solvedChunks: Int
    ): StrategySignal {
        totalIterations += 1
        operatorHistory.addLast(lastOperator)
        if (operatorHistory.size > STUCK_WINDOW * 2) operatorHistory.removeFirst()
        surpriseHistory.addLast(lastSurprise)
        if (surpriseHistory.size > STUCK_WINDOW) surpriseHistory.removeFirst()

        AppLog.logStructured(
            "INFO", "META", totalIterations,
            "Metacognitive assessment",
            mapOf("depth" to goalStackDepth, "confidence" to "%.2f".format(confidence), "surprise" to "%.2f".format(lastSurprise), "chunks" to "$solvedChunks/$chunkCount")
        )

        // Track confidence trend (uncertainty detection)
        confidenceHistory.addLast(confidence)
        if (confidenceHistory.size > STUCK_WINDOW) confidenceHistory.removeFirst()

        // Track novelty
        noveltyHistory.addLast(lastSurprise)
        if (noveltyHistory.size > STUCK_WINDOW) noveltyHistory.removeFirst()

        // Track exploration diversity
        distinctOperatorsUsed.add(lastOperator)

        // Dead-end detection: 3 consecutive low-confidence outputs
        if (confidence < 0.4f) consecutiveLowConfidence++ else consecutiveLowConfidence = 0
        if (consecutiveLowConfidence >= 3 && totalIterations > 4) {
            AppLog.logStructured("WARN", "META", totalIterations,
                "Dead-end detected: 3 consecutive low-confidence outputs. Forcing REFLECT.")
            consecutiveLowConfidence = 0
            return StrategySignal.REFLECT
        }

        // Low novelty detection: surprise decreasing for 3+ iterations
        if (noveltyHistory.size >= 3) {
            val avgRecent = noveltyHistory.takeLast(3).average()
            if (avgRecent < 0.15 && totalIterations > 5) {
                AppLog.logStructured("INFO", "META", totalIterations,
                    "Low novelty detected (avg surprise: ${"%.2f".format(avgRecent)}). Consider exploring.")
            }
        }

        // Exploration diversity: if fewer than 3 distinct operators used after 6 iterations
        if (totalIterations >= 6 && distinctOperatorsUsed.size < 3) {
            AppLog.logStructured("INFO", "META", totalIterations,
                "Low exploration diversity: only ${distinctOperatorsUsed.size} operators used.")
        }

        // Budget exhaustion
        if (totalIterations >= MAX_ITERATIONS) {
            AppLog.logStructured("WARN", "META", totalIterations, "Budget exhausted; forcing integration or stop")
            return if (solvedChunks > 0 || chunkCount > 0) StrategySignal.INTEGRATE else StrategySignal.STOP
        }

        // Adaptive early exit (blueprint Part 6 rec 1): if the first 1–3 iterations
        // already produce high confidence and low surprise, short-circuit instead of
        // always running the full 20-iteration ceiling. "I basically already know this"
        // should resolve in 1–3 iterations, not rely on STOP firing 18 iterations in.
        if (totalIterations <= 3 && confidence > 0.85f && lastSurprise < 0.15f && chunkCount <= 1) {
            AppLog.logStructured("INFO", "META", totalIterations, "Adaptive early exit: high confidence, low surprise, simple goal")
            return if (solvedChunks > 0 || lastOutput.isNotBlank()) StrategySignal.INTEGRATE else StrategySignal.STOP
        }

        // Detect repetition / stuckness
        if (isStuck(lastOutput)) {
            consecutiveStuck += 1
            AppLog.logStructured("WARN", "META", totalIterations, "Stuck detected", mapOf("consecutiveStuck" to consecutiveStuck))
            return when {
                consecutiveStuck >= 3 -> StrategySignal.FIRST_PRINCIPLES
                consecutiveStuck == 2 -> StrategySignal.ANALOGIZE
                else -> StrategySignal.DECOMPOSE
            }
        } else {
            consecutiveStuck = 0
        }

        // Low confidence on a falsifiable claim → verify
        if (confidence < 0.6f && lastSurprise > SURPRISE_FLOOR && isVerifiable(lastOutput)) {
            return StrategySignal.VERIFY
        }

        // Knowledge delta tracking: detect when the engine is running operators
        // but not actually solving any chunks (the infinite loop symptom).
        val newSolved = solvedChunks - lastSolvedChunkCount
        if (totalIterations > 3 && newSolved == 0 && solvedChunks == 0) {
            consecutiveNoProgress++
        } else {
            consecutiveNoProgress = 0
        }
        lastSolvedChunkCount = solvedChunks

        // If stuck in a question loop (no progress for 3+ iterations), force
        // the engine to work with what it has.
        if (consecutiveNoProgress >= 3 && chunkCount > 0) {
            AppLog.logStructured("WARN", "META", totalIterations,
                "No progress for $consecutiveNoProgress iterations. Forcing INTEGRATE with partial results.")
            return StrategySignal.INTEGRATE
        }

        // If all chunks are solved, integrate
        if (chunkCount > 0 && solvedChunks >= chunkCount) {
            return StrategySignal.INTEGRATE
        }

        // If problem is broad and not yet decomposed, decompose
        // BUT only if we haven't already decomposed (chunks == 0 means no pending either)
        if (goalStackDepth == 1 && chunkCount == 0 && totalIterations >= 2 && totalIterations <= 4) {
            return StrategySignal.DECOMPOSE
        }

        // High surprise with no progress → reflect and switch strategy
        if (lastSurprise > 0.6f && consecutiveStuck > 0) {
            return StrategySignal.REFLECT
        }

        return StrategySignal.CONTINUE
    }

    private fun isStuck(lastOutput: String): Boolean {
        if (operatorHistory.size < STUCK_WINDOW) return false
        val recent = operatorHistory.takeLast(STUCK_WINDOW).map { it.lowercase() }
        // Stuck if same operator repeats or outputs repeat words
        val sameOperator = recent.distinct().size == 1
        if (sameOperator) return true

        val recentOutputs = EpisodicMemory.all().takeLast(STUCK_WINDOW).map { it.output }
        if (recentOutputs.size < 3) return false
        val overlaps = mutableListOf<Float>()
        for (i in 1 until recentOutputs.size) {
            overlaps.add(wordOverlap(recentOutputs[i - 1], recentOutputs[i]))
        }
        return overlaps.average() > STUCK_THRESHOLD
    }

    private fun isVerifiable(text: String): Boolean {
        val verifiableMarkers = setOf("%", "=", "<", ">", "+", "-", "*", "/", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9")
        return verifiableMarkers.any { text.contains(it) } || text.contains(Regex("\\d"))
    }

    private fun wordOverlap(a: String, b: String): Float {
        val wordsA = a.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() && it.length > 3 }.toSet()
        val wordsB = b.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() && it.length > 3 }.toSet()
        if (wordsA.isEmpty() || wordsB.isEmpty()) return 0f
        return wordsA.intersect(wordsB).size.toFloat() / wordsA.union(wordsB).size.toFloat()
    }

    /**
     * Detect contradictions between a new belief and existing beliefs.
     * Uses lightweight heuristics: negation patterns, opposing claims.
     * Returns list of potentially contradictory node IDs.
     */
    fun detectContradictions(newContent: String, existingNodes: List<SemanticNode>): List<String> {
        val contradictions = mutableListOf<String>()
        val newLower = newContent.lowercase()

        // Check for negation patterns
        val negationPatterns = listOf(
            "not " to "", "cannot " to "can ", "is not " to "is ",
            "does not " to "does ", "will not " to "will ",
            "never " to "always ", "impossible " to "possible "
        )

        for (node in existingNodes) {
            val existingLower = node.content.lowercase()

            // Check if new content negates existing or vice versa
            for ((neg, pos) in negationPatterns) {
                if (newLower.contains(neg) && existingLower.contains(pos) &&
                    newLower.replace(neg, pos).take(60) == existingLower.take(60)) {
                    contradictions.add(node.id)
                    break
                }
                if (existingLower.contains(neg) && newLower.contains(pos) &&
                    existingLower.replace(neg, pos).take(60) == newLower.take(60)) {
                    contradictions.add(node.id)
                    break
                }
            }

            // Check for high word overlap with different sentiment
            val newWords = newLower.split(Regex("\\s+")).filter { it.length > 3 }.toSet()
            val existWords = existingLower.split(Regex("\\s+")).filter { it.length > 3 }.toSet()
            if (newWords.isNotEmpty() && existWords.isNotEmpty()) {
                val overlap = newWords.intersect(existWords).size.toFloat() / newWords.union(existWords).size
                if (overlap > 0.6f && node.confidence > 0.7f) {
                    // High overlap but different content — potential contradiction
                    contradictions.add(node.id)
                }
            }
        }
        return contradictions.distinct()
    }

    /**
     * Decide whether to externalize a note to disk based on memory load and insight value.
     */
    fun shouldExternalize(memoryLoad: Float, confidence: Float, surprise: Float): Boolean {
        return memoryLoad > 0.8f && (confidence > 0.75f || surprise > 0.5f)
    }

    /**
     * Decide whether to retrieve disk notes based on a detected knowledge gap.
     */
    fun shouldRetrieveDiskNotes(query: String, retrievedCount: Int, hasDiskNotes: Boolean): Boolean {
        return hasDiskNotes && retrievedCount < 2 && query.length > 10
    }

    fun estimateConfidence(output: String, verificationResult: Boolean?): Float {
        var score = 0.75f
        if (verificationResult == true) score += 0.15f
        if (verificationResult == false) score -= 0.30f
        if (output.contains("uncertain") || output.contains("maybe") || output.contains("possibly")) score -= 0.10f
        if (output.contains(Regex("\\d"))) score += 0.05f
        return score.coerceIn(0.05f, 1.0f)
    }
}
