package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.max

object RefinerConfigDefaults {
    const val MAX_TOKENS = 650
    const val MIN_REFINED_CHARS = 30
    const val MIN_NEXT_FOCUS_CHARS = 12
    const val MAX_REFINED_CHARS = 420
    const val MAX_NEXT_FOCUS_CHARS = 160
    const val PREVIOUS_REFINED_CHAR_LIMIT = 420
    const val TEMPERATURE = 0.7f
    const val TOP_K = 40
    const val TOP_P = 0.9f
    const val MIN_P = 0.05f
    const val REPEAT_PENALTY = 1.1f
    const val DRIFT_THRESHOLD = 0.65f
    const val DRIFT_WINDOW = 3
    const val HISTORY_SIZE = 3
    val lenses = listOf(
        "structural improvement",
        "feasibility and practicality",
        "cost and resource analysis",
        "risk identification",
        "user experience and accessibility",
        "edge cases and failure modes",
        "opposite perspective — argue against the idea",
        "analogy — relate it to something completely different"
    )
}

@Serializable
data class StrictRefinerJson(
    val refined: String,
    val next_focus: String,
    val domain_tag: String = "structural",
    val abstraction_level: String = "intermediate",
    val novelty_claim: String = "Iterative structural progression.",
    val supports: String? = null,
    val contradicts: String? = null,
    val close_q: String? = null,
    val open_q: String? = null
)

data class RefinerIteration(
    val iteration: Int,
    val lens: String,
    val lensChanged: Boolean,
    val refined: String,
    val nextFocus: String,
    val generationTimeSeconds: Float,
    val stuckCount: Int
)

class RecursiveRefinerController(
    private val context: android.content.Context,
    private val grounding: String,
    private val maxTokens: Int = RefinerConfigDefaults.MAX_TOKENS,
    private val temperature: Float = RefinerConfigDefaults.TEMPERATURE,
    private val topK: Int = RefinerConfigDefaults.TOP_K,
    private val topP: Float = RefinerConfigDefaults.TOP_P,
    private val minP: Float = RefinerConfigDefaults.MIN_P,
    private val repeatPenalty: Float = RefinerConfigDefaults.REPEAT_PENALTY,
    private val strictKvCache: Boolean = false,
    private val thinkingMode: String = "OFF",
    private val driftThreshold: Float = RefinerConfigDefaults.DRIFT_THRESHOLD,
    private val driftWindow: Int = RefinerConfigDefaults.DRIFT_WINDOW,
    private val historySize: Int = RefinerConfigDefaults.HISTORY_SIZE
) {
    private val json = Json { ignoreUnknownKeys = true }
    private var currentLens = RefinerConfigDefaults.lenses.first()
    private var lensIndex = 0
    private var lastRefined: String? = null
    private var lastDirective: String? = null
    private val history = ArrayDeque<String>()
    private var stuckCount = 0
    private var iteration = 0
    private var started = false
    var webSearchEnabled: Boolean = false
    var lastSearchQuery: String = ""
    var lastSearchResults: List<SearchResult> = emptyList()

    fun startSession() {
        MesaEngine.initMesa(grounding)
        CognitiveOsMemory.initSession(context, grounding)
        AppLog.append("Refiner startSession: strictKvCache=$strictKvCache thinkingMode=$thinkingMode groundingChars=${grounding.length}")
        NativeRecursiveRefiner.setStrictKvMode(strictKvCache)
        NativeRecursiveRefiner.setThinkingMode(thinkingMode != "OFF", if (thinkingMode == "FORCE") 128 else 64)
        val cachedGrounding = buildCachedGrounding(grounding)
        val code = NativeRecursiveRefiner.beginSession(cachedGrounding)
        require(code == 0) { "Native refiner failed to cache grounding. Code: $code" }
        currentLens = RefinerConfigDefaults.lenses.first()
        lensIndex = 0
        lastRefined = null
        lastDirective = null
        history.clear()
        stuckCount = 0
        iteration = 0
        started = true
    }

    fun reset() {
        NativeRecursiveRefiner.resetSession()
        started = false
    }

    /**
     * Run one iteration of the recursive refiner.
     * Emits full StageDiagnostics via onDiag at each pipeline stage boundary.
     * Callers must dispatch to main thread for Compose state updates.
     */
    fun runOneIteration(onDiag: (StageDiagnostics) -> Unit = {}): RefinerIteration {
        check(started) { "Start a refiner session first." }
        iteration += 1
        val iterStartMs = System.currentTimeMillis()

        // ── Stage 1: SYSTEM_PROMPT_ASSEMBLY ──────────────────────────────────
        onDiag(StageDiagnostics(PipelineStage.SYSTEM_PROMPT_ASSEMBLY, StageStatus.ACTIVE, startedAtMs = System.currentTimeMillis()))
        val targetCell = MesaEngine.selectExplorationTargetCell()
        val activePolicy = MesaEngine.selectWinningPolicy()
        currentLens = activePolicy.lens
        val lensUsed = currentLens
        val prompt = buildPrompt(targetCell, activePolicy)
        onDiag(StageDiagnostics(
            stage = PipelineStage.SYSTEM_PROMPT_ASSEMBLY,
            status = StageStatus.COMPLETED,
            startedAtMs = iterStartMs,
            completedAtMs = System.currentTimeMillis(),
            inputSummary = "Grounding: ${grounding.take(80)}...",
            outputSummary = "Prompt assembled: ${prompt.length} chars",
            promptSizeChars = prompt.length,
            promptSizeTokensEstimate = prompt.length / 4,
            selectedCell = "${targetCell.domainAxis}/${targetCell.abstractionAxis}",
            winningPolicy = activePolicy.name,
            policySuccessRate = activePolicy.successRate
        ))

        // ── Stage 2: MEMORY_RETRIEVAL ────────────────────────────────────────
        val memStageStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.MEMORY_RETRIEVAL, StageStatus.ACTIVE, startedAtMs = memStageStart))
        val activeNodes = CognitiveOsMemory.getAllActive()
            .sortedByDescending { CognitiveOsMemory.computeRetrievalScore(it, iteration) }
            .take(5)
        val archivedNodes = CognitiveOsMemory.getAllActive()
            .filter { it.status == "ARCHIVED" || it.status == "ARCHIVED_EVIDENCE" }
            .map { "[${it.id}] archived" }
        if (webSearchEnabled) {
            val queryText = lastDirective ?: grounding
            val kw = WebSearchClient.extractKeywords(queryText)
            lastSearchQuery = kw
            lastSearchResults = kotlinx.coroutines.runBlocking { WebSearchClient.search(kw, 3) }
        } else {
            lastSearchQuery = ""
            lastSearchResults = emptyList()
        }
        onDiag(StageDiagnostics(
            stage = PipelineStage.MEMORY_RETRIEVAL,
            status = StageStatus.COMPLETED,
            startedAtMs = memStageStart,
            completedAtMs = System.currentTimeMillis(),
            readNodes = activeNodes.map { "[${it.id}] conf=${"%.2f".format(it.confidence)} ${it.claim.take(50)}" },
            archivedNodes = archivedNodes,
            outputSummary = "Retrieved ${activeNodes.size} active nodes, ${archivedNodes.size} archived"
        ))

        // ── Stage 3: GOAL_SELECTION ──────────────────────────────────────────
        val goalStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.GOAL_SELECTION, StageStatus.ACTIVE, startedAtMs = goalStart))
        val ucbScore = MesaEngine.archiveGrid.values.maxOfOrNull { it.qualityScore } ?: 0f
        onDiag(StageDiagnostics(
            stage = PipelineStage.GOAL_SELECTION,
            status = StageStatus.COMPLETED,
            startedAtMs = goalStart,
            completedAtMs = System.currentTimeMillis(),
            selectedCell = "${targetCell.domainAxis}/${targetCell.abstractionAxis}",
            ucbScore = ucbScore,
            winningPolicy = activePolicy.name,
            policySuccessRate = activePolicy.successRate,
            outputSummary = "Target: ${targetCell.domainAxis}/${targetCell.abstractionAxis} | UCB: ${"%.3f".format(ucbScore)}"
        ))

        // ── Stage 4: ARCHIVE_REVIEW ──────────────────────────────────────────
        val archStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.ARCHIVE_REVIEW, StageStatus.ACTIVE, startedAtMs = archStart))
        val existingElite = MesaEngine.archiveGrid["${targetCell.domainAxis}/${targetCell.abstractionAxis}"]
        onDiag(StageDiagnostics(
            stage = PipelineStage.ARCHIVE_REVIEW,
            status = StageStatus.COMPLETED,
            startedAtMs = archStart,
            completedAtMs = System.currentTimeMillis(),
            inputSummary = if (existingElite != null) "Existing elite score: ${"%.3f".format(existingElite.qualityScore)}" else "Cell is empty",
            outputSummary = "Archive cells total: ${MesaEngine.archiveGrid.size}, elite visits: ${existingElite?.visitCount ?: 0}"
        ))

        // ── Stage 5: HYPOTHESIS_GENERATION ──────────────────────────────────
        val genStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.HYPOTHESIS_GENERATION, StageStatus.ACTIVE, startedAtMs = genStart))
        AppLog.append("Refiner iteration $iteration begin: promptChars=${prompt.length}")
        NativeRecursiveRefiner.setStrictKvMode(strictKvCache)
        NativeRecursiveRefiner.setThinkingMode(thinkingMode != "OFF", if (thinkingMode == "FORCE") 128 else 64)
        val nativeStart = System.nanoTime()
        val rawJson = NativeRecursiveRefiner.refineOnce(
            prompt = prompt,
            maxTokens = maxTokens,
            temperature = temperature,
            topK = topK,
            topP = topP,
            minP = minP,
            repeatPenalty = repeatPenalty
        )
        val seconds = ((System.nanoTime() - nativeStart).toDouble() / 1_000_000_000.0).toFloat()
        AppLog.append("Refiner iteration $iteration native returned chars=${rawJson.length}")
        onDiag(StageDiagnostics(
            stage = PipelineStage.HYPOTHESIS_GENERATION,
            status = StageStatus.COMPLETED,
            startedAtMs = genStart,
            completedAtMs = System.currentTimeMillis(),
            outputSizeChars = rawJson.length,
            rawJsonGenerated = rawJson,
            outputSummary = "Generated ${rawJson.length} chars in ${"%.1f".format(seconds)}s"
        ))

        // ── Stage 6: CODE_EXECUTION ──────────────────────────────────────────
        val codeStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.CODE_EXECUTION, StageStatus.ACTIVE, startedAtMs = codeStart))
        val parsed = parseRefinerJsonSafely(rawJson)
        val refined = sanitizeRefined(parsed.refined.trim()).smartLimit(RefinerConfigDefaults.MAX_REFINED_CHARS)
        val nextFocus = sanitizeNextFocus(parsed.next_focus.trim()).smartLimit(RefinerConfigDefaults.MAX_NEXT_FOCUS_CHARS)
        // ExecutionLayer runs the JS sandbox reality check
        val empReport = ExecutionLayer.executeRealityValidation(refined, temperature, topK, topP, minP, repeatPenalty)
        onDiag(StageDiagnostics(
            stage = PipelineStage.CODE_EXECUTION,
            status = if (empReport.survivedChallenge) StageStatus.COMPLETED else StageStatus.FAILED,
            startedAtMs = codeStart,
            completedAtMs = System.currentTimeMillis(),
            codeSuccess = empReport.survivedChallenge,
            codeOutput = if (empReport.survivedChallenge)
                "Reality check PASSED. Multiplier: ${"%.2f".format(empReport.finalRealityMultiplier)}"
            else
                "Reality check FAILED. Objection: ${empReport.fatalObjection}",
            outputSummary = "Empirical specificity: ${"%.2f".format(empReport.empiricalSpecificityScore)} | Multiplier: ${"%.2f".format(empReport.finalRealityMultiplier)}"
        ))

        // ── Stage 7: VERIFICATION_TESTING ───────────────────────────────────
        val verStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.VERIFICATION_TESTING, StageStatus.ACTIVE, startedAtMs = verStart))
        validateModelFields(refined, nextFocus, rawJson)
        val advScore = MesaEngine.evaluateAdversarialRobustness(refined, parsed.novelty_claim)
        val domainVerified = MesaEngine.verifyDomainTag(parsed.domain_tag, refined) == parsed.domain_tag
        onDiag(StageDiagnostics(
            stage = PipelineStage.VERIFICATION_TESTING,
            status = StageStatus.COMPLETED,
            startedAtMs = verStart,
            completedAtMs = System.currentTimeMillis(),
            jaccardScore = advScore,
            adversarialGate = parsed.novelty_claim.take(80),
            domainVerified = domainVerified,
            outputSummary = "Adversarial score: ${"%.3f".format(advScore)} | Domain verified: $domainVerified"
        ))

        // ── Stage 8: REPAIR_RETRY ────────────────────────────────────────────
        val repairStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.REPAIR_RETRY, StageStatus.ACTIVE, startedAtMs = repairStart))
        val deltaRes = CognitiveOsMemory.registerDeltaUpdate(
            newClaim = refined,
            supportsId = parsed.supports?.takeIf { it.isNotBlank() },
            contradictsId = parsed.contradicts?.takeIf { it.isNotBlank() },
            closedQuestion = parsed.close_q?.takeIf { it.isNotBlank() },
            newQuestion = parsed.open_q?.takeIf { it.isNotBlank() }
        )
        val isDup = deltaRes == "duplicate"
        val establishedElite = MesaEngine.commitIterationResult(
            parsed.domain_tag,
            parsed.abstraction_level,
            refined,
            parsed.novelty_claim,
            isDup,
            empReport.finalRealityMultiplier
        )
        var changed = false
        var repairLog = ""
        if (isDup || !establishedElite) {
            stuckCount += 1
            changed = true
            repairLog = "Stuck count: $stuckCount | isDuplicate: $isDup | Not elite: ${!establishedElite}"
            if (stuckCount >= 2) {
                val diagnosis = generateFailurePostMortem(refined, lastDirective ?: grounding)
                MesaEngine.recordReflexionFailure(refined.take(30), diagnosis.first, diagnosis.second)
                repairLog += " | Failure postmortem: ${diagnosis.first}"
                stuckCount = 0
            }
            rotateLens()
            lastDirective = "[STRICT REPETITION BREAKER]: Pivot to lens: $currentLens"
        } else {
            stuckCount = 0
            lastRefined = refined
            lastDirective = templateDirective(nextFocus)
            changed = checkDrift(refined)
            repairLog = "Elite established. Score: ${"%.3f".format(advScore * empReport.finalRealityMultiplier)}"
        }
        onDiag(StageDiagnostics(
            stage = PipelineStage.REPAIR_RETRY,
            status = StageStatus.COMPLETED,
            startedAtMs = repairStart,
            completedAtMs = System.currentTimeMillis(),
            repairAttempts = stuckCount,
            repairLog = repairLog,
            outputSummary = if (establishedElite) "New elite established" else "No elite. Rotating lens to $currentLens"
        ))

        // ── Stage 9: PERSISTENCE_SNAPSHOT ───────────────────────────────────
        val persStart = System.currentTimeMillis()
        onDiag(StageDiagnostics(PipelineStage.PERSISTENCE_SNAPSHOT, StageStatus.ACTIVE, startedAtMs = persStart))
        CognitiveOsMemory.saveSnapshot(context)
        val snapFile = java.io.File(context.filesDir, "cognitive_os.json")
        val snapSize = if (snapFile.exists()) snapFile.length() else 0L
        onDiag(StageDiagnostics(
            stage = PipelineStage.PERSISTENCE_SNAPSHOT,
            status = StageStatus.COMPLETED,
            startedAtMs = persStart,
            completedAtMs = System.currentTimeMillis(),
            snapshotSizeBytes = snapSize,
            snapshotWriteMs = System.currentTimeMillis() - persStart,
            nodesConsolidated = CognitiveOsMemory.getActiveNodesCount(),
            outputSummary = "Snapshot: ${snapSize / 1024}KB in ${System.currentTimeMillis() - persStart}ms"
        ))

        // ── Build and store iteration snapshot ───────────────────────────────
        val iterSnap = IterationSnapshot(
            iterNumber = iteration,
            startedAtMs = iterStartMs,
            completedAtMs = System.currentTimeMillis(),
            targetCell = "${targetCell.domainAxis}/${targetCell.abstractionAxis}",
            winningPolicy = activePolicy.name,
            rawJson = rawJson,
            refinedText = refined,
            nextFocus = nextFocus,
            qualityScore = advScore * empReport.finalRealityMultiplier,
            becameElite = establishedElite,
            isDuplicate = isDup,
            generationSecs = seconds,
            stuckCount = stuckCount,
            empiricalReport = if (empReport.survivedChallenge) "PASSED: mult=${empReport.finalRealityMultiplier}" else "FAILED: ${empReport.fatalObjection}"
        )
        ObservatoriumSession.addIterationSnapshot(iterSnap)
        AppLog.append("Refiner iteration $iteration finished OK.")

        return RefinerIteration(
            iteration = iteration,
            lens = lensUsed,
            lensChanged = changed,
            refined = refined,
            nextFocus = nextFocus,
            generationTimeSeconds = seconds,
            stuckCount = stuckCount
        )
    }

    private fun buildPrompt(targetCell: ArchiveCell, activePolicy: ReasoningPolicy): String {
        val systemHeader = "You are MESA, a self-evolving scientific reasoning agent. Target MAP-Elites Coordinate: [${targetCell.domainAxis}/${targetCell.abstractionAxis}]. " +
                "Active Thompson Reasoning Policy: ${activePolicy.name} (${"%.0f".format(activePolicy.successRate * 100)}% win prior).\n"
        val lastDirectiveText = lastDirective ?: "Initial objective: Develop a comprehensive foundational hypothesis based on the grounding idea."
        val directiveHeader = "\n[LIVE REFLEXION DIRECTIVE]:\n$lastDirectiveText\n\n"
        val elitesSb = StringBuilder()
        elitesSb.append("\n[CURRENT MAP-ELITES ELITES (Top Surviving Hypotheses)]:\n")
        MesaEngine.archiveGrid.values.sortedByDescending { it.qualityScore }.take(3).forEach { elite ->
            if (elite.bestHypothesis.isNotBlank()) {
                elitesSb.append("Cell [${elite.domainAxis}/${elite.abstractionAxis}]: \"${elite.bestHypothesis.take(110)}\" (Quality: ${"%.2f".format(elite.qualityScore)})\n")
            }
        }
        val reflexionSb = StringBuilder()
        if (MesaEngine.failureMemoryStore.isNotEmpty()) {
            reflexionSb.append("\n[REFLEXION FAILURE MEMORY (Avoid Traps)]:\n")
            MesaEngine.failureMemoryStore.take(2).forEach { fm ->
                reflexionSb.append("Warning: Stalled on \"${fm.stuckPhrase}\". Cause: ${fm.whyStuck} Pivot: ${fm.pivotDirection}\n")
            }
        }
        val searchSb = StringBuilder()
        val searchGrounding = WebSearchClient.formatGrounding(lastSearchResults)
        if (searchGrounding.isNotEmpty()) {
            searchSb.append("\n").append(searchGrounding).append("\n")
        }
        val workingSetText = CognitiveOsMemory.assembleWorkingSetPrompt(iteration, maxCharsBudget = 400)
        val dynamicContext = buildString {
            append(elitesSb.toString().take(350))
            append(reflexionSb.toString().take(250))
            append(searchSb.toString().take(300))
            append("\n[COGNITIVE WORKING MEMORY SET]:\n")
            append(workingSetText.take(450))
        }
        val finalPrompt = buildString {
            append(systemHeader)
            append("\nOriginal permanent grounding reminder: ").append(grounding.take(180)).append("\n\n")
            append(directiveHeader)
            append(dynamicContext)
            append("\n\n")
            append(schemaDescription())
        }
        return if (finalPrompt.length > 3200) {
            AppLog.append("Warning: Hard prompt size limit reached. Truncating dynamic context.")
            finalPrompt.take(1500) + "\n[...context omitted...]\n\n" + schemaDescription()
        } else {
            finalPrompt
        }
    }

    private fun generateFailurePostMortem(stuckHypothesis: String, nextFocusQuery: String): Pair<String, String> {
        val pmPrompt = buildString {
            appendLine("This hypothesis has hit a loop attractor: \"${stuckHypothesis.take(150)}\"")
            appendLine("State why this is stuck in the 'refined' field (max 100 chars).")
            appendLine("State a completely different physical mechanism or pivot in 'next_focus' (max 100 chars).")
            appendLine("Fill the other 7 fields of the JSON schema with placeholder tags.")
        }
        return try {
            val raw = NativeRecursiveRefiner.refineOnce(pmPrompt, 250, 0.4f, 40, 0.9f, 0.05f, 1.1f)
            val parsed = json.decodeFromString<StrictRefinerJson>(raw)
            parsed.refined.take(100) to parsed.next_focus.take(100)
        } catch (e: Exception) {
            "Repeated valley attractor hypothesis." to "Pivot strictly to a different domain axis."
        }
    }

    private fun buildCachedGrounding(text: String): String =
        "PERMANENT GROUNDING — immutable original idea:\n" +
            text.trim() +
            "\nEND PERMANENT GROUNDING. All future refinements must stay grounded in this idea.\n"

    private fun schemaDescription(): String =
        "Output ONE compact JSON object matching exactly these 9 fields:\n" +
            "- \"refined\": improved version of the idea — concrete, max 420 chars.\n" +
            "- \"next_focus\": what to examine next and why — max 160 chars.\n" +
            "- \"domain_tag\": ONE of [structural, biological, economic, physical, computational]. Pick the domain content reasons in.\n" +
            "- \"abstraction_level\": ONE of [concrete, intermediate, abstract].\n" +
            "- \"novelty_claim\": ONE sentence naming a specific element in \"refined\". Max 110 chars.\n" +
            "- \"supports\": existing [nNNN] id from working set that \"refined\" reinforces, or null.\n" +
            "- \"contradicts\": existing [nNNN] id that \"refined\" challenges, or null.\n" +
            "- \"close_q\": exact text of open question below that \"refined\" answers, or null.\n" +
            "- \"open_q\": one new specific question raised by \"refined\", or null.\n" +
            "Output ONLY the JSON object, nothing before or after it."

    private fun templateDirective(nextFocus: String): String =
        "Your task now: $nextFocus\n" +
            "Refine specifically toward this task. Examine it through the lens of: $currentLens. " +
            "Do not merely restate the previous refinement; add exactly one compact concrete improvement, measurable criterion, or physical implementation detail."

    private fun sanitizeRefined(value: String): String {
        var v = value
            .replace(Regex("(?is)\\n?\\s*next[_\\s-]*focus\\s*[:=].*$"), "")
            .replace(Regex("(?is)\\n?\\s*\"next_focus\"\\s*:\\s*\".*$"), "")
            .trim()
        v = v.replace(Regex("(?is)\\s+Next focus is .*$"), "").trim()
        return v
    }

    private fun sanitizeNextFocus(value: String): String = value
        .replace(Regex("(?is)^next[_\\s-]*focus\\s*[:=]\\s*"), "")
        .trim()

    private fun validateModelFields(refined: String, nextFocus: String, rawJson: String) {
        if (refined.length < RefinerConfigDefaults.MIN_REFINED_CHARS || nextFocus.length < RefinerConfigDefaults.MIN_NEXT_FOCUS_CHARS) {
            val msg = "Model returned empty JSON fields. refinedChars=${refined.length}, nextFocusChars=${nextFocus.length}."
            AppLog.append(msg)
            throw IllegalStateException(msg)
        }
    }

    private fun checkDrift(newRefined: String): Boolean {
        var maxOverlap = 0f
        for (old in history) {
            maxOverlap = max(maxOverlap, wordOverlap(newRefined, old))
        }
        stuckCount = if (maxOverlap > driftThreshold) stuckCount + 1 else 0
        var changed = false
        if (stuckCount >= driftWindow) {
            rotateLens()
            stuckCount = 0
            changed = true
        }
        history.addLast(newRefined)
        while (history.size > historySize) history.removeFirst()
        return changed
    }

    private fun rotateLens() {
        lensIndex = (lensIndex + 1) % RefinerConfigDefaults.lenses.size
        currentLens = RefinerConfigDefaults.lenses[lensIndex]
    }

    private fun String.smartLimit(limit: Int): String {
        if (length <= limit) return this
        return take(limit) + "\n[Truncated; continue improving from here.]"
    }

    private fun wordOverlap(a: String, b: String): Float {
        val wordsA = a.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        val wordsB = b.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        if (wordsA.isEmpty() || wordsB.isEmpty()) return 0f
        val intersection = wordsA.intersect(wordsB).size
        val union = wordsA.union(wordsB).size
        return intersection.toFloat() / union.toFloat()
    }

    private fun parseRefinerJsonSafely(rawJson: String): StrictRefinerJson {
        runCatching { return json.decodeFromString<StrictRefinerJson>(rawJson) }
        AppLog.append("WARN: strict JSON parse failed, attempting auto-repair. raw=" + rawJson.take(300))
        val repaired = attemptJsonRepair(rawJson)
        runCatching { return json.decodeFromString<StrictRefinerJson>(repaired) }
        val refinedMatch = Regex("\"refined\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").find(rawJson)
        val nextFocusMatch = Regex("\"next_focus\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").find(rawJson)
        val domainTagMatch = Regex("\"domain_tag\"\\s*:\\s*\"([^\"]+)\"").find(rawJson)
        val absLevelMatch = Regex("\"abstraction_level\"\\s*:\\s*\"([^\"]+)\"").find(rawJson)
        val noveltyMatch = Regex("\"novelty_claim\"\\s*:\\s*\"([^\"]+)\"").find(rawJson)

        if (refinedMatch != null && nextFocusMatch != null) {
            AppLog.append("WARN: repair failed, salvaged fields via regex matches.")
            return StrictRefinerJson(
                refined = refinedMatch.groupValues[1],
                next_focus = nextFocusMatch.groupValues[1],
                domain_tag = domainTagMatch?.groupValues?.get(1) ?: "structural",
                abstraction_level = absLevelMatch?.groupValues?.get(1) ?: "intermediate",
                novelty_claim = noveltyMatch?.groupValues?.get(1) ?: "Iterative progression"
            )
        }
        throw IllegalStateException("Unrecoverable JSON. raw=" + rawJson.take(800))
    }

    private fun attemptJsonRepair(raw: String): String {
        var s = raw.trim()
        val quoteCount = s.count { it == '"' } - Regex("\\\\\"").findAll(s).count()
        if (quoteCount % 2 != 0) s += "\""
        val openBrace = s.count { it == '{' }
        val closeBrace = s.count { it == '}' }
        if (openBrace > closeBrace) {
            s += "}".repeat(openBrace - closeBrace)
        }
        return s
    }
}