package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.max

object RefinerConfigDefaults {
    const val MAX_TOKENS = 300
    const val MIN_REFINED_CHARS = 30
    const val MIN_NEXT_FOCUS_CHARS = 12
    const val TEMPERATURE = 0.7f
    const val TOP_K = 40
    const val TOP_P = 0.9f
    const val MIN_P = 0.05f
    const val REPEAT_PENALTY = 1.1f
    const val DRIFT_THRESHOLD = 0.65f
    const val DRIFT_WINDOW = 3
    const val HISTORY_SIZE = 3

    val lenses = listOf(
        "structural improvement",
        "feasibility and practicality",
        "cost and resource analysis",
        "risk identification",
        "user experience and accessibility",
        "edge cases and failure modes",
        "opposite perspective — argue against the idea",
        "analogy — relate it to something completely different"
    )
}

@Serializable
data class StrictRefinerJson(
    val refined: String,
    val next_focus: String
)

data class RefinerIteration(
    val iteration: Int,
    val lens: String,
    val lensChanged: Boolean,
    val refined: String,
    val nextFocus: String,
    val generationTimeSeconds: Float,
    val stuckCount: Int
)

class RecursiveRefinerController(
    private val grounding: String,
    private val maxTokens: Int = RefinerConfigDefaults.MAX_TOKENS,
    private val temperature: Float = RefinerConfigDefaults.TEMPERATURE,
    private val topK: Int = RefinerConfigDefaults.TOP_K,
    private val topP: Float = RefinerConfigDefaults.TOP_P,
    private val minP: Float = RefinerConfigDefaults.MIN_P,
    private val repeatPenalty: Float = RefinerConfigDefaults.REPEAT_PENALTY,
    private val strictKvCache: Boolean = false,
    private val driftThreshold: Float = RefinerConfigDefaults.DRIFT_THRESHOLD,
    private val driftWindow: Int = RefinerConfigDefaults.DRIFT_WINDOW,
    private val historySize: Int = RefinerConfigDefaults.HISTORY_SIZE
) {
    private val json = Json { ignoreUnknownKeys = false }

    private var currentLens = RefinerConfigDefaults.lenses.first()
    private var lensIndex = 0
    private var lastRefined: String? = null
    private var lastDirective: String? = null
    private val history = ArrayDeque<String>()
    private var stuckCount = 0
    private var iteration = 0
    private var started = false

    fun startSession() {
        AppLog.append("Refiner startSession: strictKvCache=$strictKvCache groundingChars=${grounding.length}")
        NativeRecursiveRefiner.setStrictKvMode(strictKvCache)
        val cachedGrounding = buildCachedGrounding(grounding)
        val code = NativeRecursiveRefiner.beginSession(cachedGrounding)
        require(code == 0) { "Native refiner failed to cache grounding. Code: $code" }
        currentLens = RefinerConfigDefaults.lenses.first()
        lensIndex = 0
        lastRefined = null
        lastDirective = null
        history.clear()
        stuckCount = 0
        iteration = 0
        started = true
    }

    fun reset() {
        NativeRecursiveRefiner.resetSession()
        started = false
    }

    fun runOneIteration(): RefinerIteration {
        check(started) { "Start a refiner session first." }
        iteration += 1
        val lensUsed = currentLens
        val prompt = buildPrompt()
        AppLog.append("Refiner iteration $iteration begin: strictKvCache=$strictKvCache lens=$lensUsed promptChars=${prompt.length}")
        NativeRecursiveRefiner.setStrictKvMode(strictKvCache)
        val start = System.nanoTime()
        val rawJson = NativeRecursiveRefiner.refineOnce(
            prompt = prompt,
            maxTokens = maxTokens,
            temperature = temperature,
            topK = topK,
            topP = topP,
            minP = minP,
            repeatPenalty = repeatPenalty
        )
        val seconds = ((System.nanoTime() - start).toDouble() / 1_000_000_000.0).toFloat()
        AppLog.append("Refiner iteration $iteration native returned chars=${rawJson.length}: ${rawJson.take(160)}")
        val parsed = json.decodeFromString<StrictRefinerJson>(rawJson)

        val refined = parsed.refined.trim()
        val nextFocus = parsed.next_focus.trim()
        validateModelFields(refined, nextFocus, rawJson)

        lastDirective = templateDirective(nextFocus)
        lastRefined = refined
        val changed = checkDrift(refined)
        if (changed) {
            // Re-template with the newly rotated lens so the NEXT iteration is forced to use it.
            lastDirective = templateDirective(nextFocus)
        }

        AppLog.append("Refiner iteration $iteration parsed OK lensUsed=$lensUsed currentLens=$currentLens changed=$changed")
        return RefinerIteration(
            iteration = iteration,
            lens = lensUsed,
            lensChanged = changed,
            refined = refined,
            nextFocus = nextFocus,
            generationTimeSeconds = seconds,
            stuckCount = stuckCount
        )
    }

    private fun buildPrompt(): String {
        val sb = StringBuilder()
        sb.append("You are a recursive idea refiner. The permanent grounding was evaluated immediately before this prompt. ")
        sb.append("Treat that grounding as the immutable original idea. Improve it through the requested lens. ")
        sb.append("Be concrete, specific, and constructive. Identify real gaps and propose real improvements. ")
        sb.append("Never return empty strings. Never copy the previous refinement verbatim. ")
        sb.append("If the previous result is already strong, add a new concrete constraint, metric, test, risk, implementation step, or tradeoff.\n\n")
        sb.append(schemaDescription()).append("\n\n")
        sb.append("Refinement lens for THIS iteration: ").append(currentLens).append("\n\n")
        val prev = lastRefined
        val directive = lastDirective
        if (prev != null && directive != null) {
            sb.append("Previous refinement result:\n").append(prev).append("\n\n")
            sb.append(directive).append("\n\n")
        }
        return sb.toString()
    }

    private fun buildCachedGrounding(text: String): String =
        "PERMANENT GROUNDING — immutable original idea:\n" +
            text.trim() +
            "\nEND PERMANENT GROUNDING. All future refinements must stay grounded in this idea.\n"

    private fun schemaDescription(): String =
        "Output a JSON object with exactly two fields:\n" +
            "- \"refined\": your improved version of the idea (non-empty, concrete string)\n" +
            "- \"next_focus\": what should be examined next and why (non-empty, specific string)\n" +
            "Output ONLY the JSON object. No explanation before or after. Do not use empty strings."

    private fun templateDirective(nextFocus: String): String =
        "Your task now: $nextFocus\n" +
            "This is not optional — refine specifically toward this. " +
            "Examine it from the lens of: $currentLens. " +
            "Do not merely restate the previous refinement; add a concrete improvement, measurable criterion, implementation detail, or risk mitigation."

    private fun validateModelFields(refined: String, nextFocus: String, rawJson: String) {
        if (refined.length < RefinerConfigDefaults.MIN_REFINED_CHARS || nextFocus.length < RefinerConfigDefaults.MIN_NEXT_FOCUS_CHARS) {
            val msg = "Model returned too-short/empty JSON fields. refinedChars=${refined.length}, nextFocusChars=${nextFocus.length}. Raw=$rawJson"
            AppLog.append(msg)
            throw IllegalStateException(msg)
        }
    }

    private fun checkDrift(newRefined: String): Boolean {
        var maxOverlap = 0f
        for (old in history) {
            maxOverlap = max(maxOverlap, wordOverlap(newRefined, old))
        }
        stuckCount = if (maxOverlap > driftThreshold) stuckCount + 1 else 0

        var changed = false
        if (stuckCount >= driftWindow) {
            rotateLens()
            stuckCount = 0
            changed = true
        }

        history.addLast(newRefined)
        while (history.size > historySize) history.removeFirst()
        return changed
    }

    private fun rotateLens() {
        lensIndex = (lensIndex + 1) % RefinerConfigDefaults.lenses.size
        currentLens = RefinerConfigDefaults.lenses[lensIndex]
    }

    private fun wordOverlap(a: String, b: String): Float {
        val wordsA = a.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        val wordsB = b.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        if (wordsA.isEmpty() || wordsB.isEmpty()) return 0f
        val intersection = wordsA.intersect(wordsB).size
        val union = wordsA.union(wordsB).size
        return intersection.toFloat() / union.toFloat()
    }
}
