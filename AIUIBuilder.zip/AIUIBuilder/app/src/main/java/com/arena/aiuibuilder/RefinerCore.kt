package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.max

object RefinerConfigDefaults {
    const val MAX_TOKENS = 180
    const val MIN_REFINED_CHARS = 30
    const val MIN_NEXT_FOCUS_CHARS = 12
    const val MAX_REFINED_CHARS = 420
    const val MAX_NEXT_FOCUS_CHARS = 160
    const val PREVIOUS_REFINED_CHAR_LIMIT = 420
    const val TEMPERATURE = 0.7f
    const val TOP_K = 40
    const val TOP_P = 0.9f
    const val MIN_P = 0.05f
    const val REPEAT_PENALTY = 1.1f
    const val DRIFT_THRESHOLD = 0.65f
    const val DRIFT_WINDOW = 3
    const val HISTORY_SIZE = 3

    val lenses = listOf(
        "structural improvement",
        "feasibility and practicality",
        "cost and resource analysis",
        "risk identification",
        "user experience and accessibility",
        "edge cases and failure modes",
        "opposite perspective — argue against the idea",
        "analogy — relate it to something completely different"
    )
}

@Serializable
data class StrictRefinerJson(
    val refined: String,
    val next_focus: String,
    val domain_tag: String = "structural",
    val abstraction_level: String = "intermediate",
    val novelty_claim: String = "Iterative structural progression.",
    val supports: String? = null,
    val contradicts: String? = null,
    val close_q: String? = null,
    val open_q: String? = null
)

data class RefinerIteration(
    val iteration: Int,
    val lens: String,
    val lensChanged: Boolean,
    val refined: String,
    val nextFocus: String,
    val generationTimeSeconds: Float,
    val stuckCount: Int
)

class RecursiveRefinerController(
    private val context: android.content.Context,
    private val grounding: String,
    private val maxTokens: Int = RefinerConfigDefaults.MAX_TOKENS,
    private val temperature: Float = RefinerConfigDefaults.TEMPERATURE,
    private val topK: Int = RefinerConfigDefaults.TOP_K,
    private val topP: Float = RefinerConfigDefaults.TOP_P,
    private val minP: Float = RefinerConfigDefaults.MIN_P,
    private val repeatPenalty: Float = RefinerConfigDefaults.REPEAT_PENALTY,
    private val strictKvCache: Boolean = false,
    private val thinkingMode: String = "OFF",
    private val driftThreshold: Float = RefinerConfigDefaults.DRIFT_THRESHOLD,
    private val driftWindow: Int = RefinerConfigDefaults.DRIFT_WINDOW,
    private val historySize: Int = RefinerConfigDefaults.HISTORY_SIZE
) {
    private val json = Json { ignoreUnknownKeys = false }

    private var currentLens = RefinerConfigDefaults.lenses.first()
    private var lensIndex = 0
    private var lastRefined: String? = null
    private var lastDirective: String? = null
    private val history = ArrayDeque<String>()
    private var stuckCount = 0
    private var iteration = 0
    private var started = false

    var webSearchEnabled: Boolean = false
    var lastSearchQuery: String = ""
    var lastSearchResults: List<SearchResult> = emptyList()

    fun startSession() {
        MesaEngine.initMesa(grounding)
        CognitiveOsMemory.initSession(context, grounding)
        AppLog.append("Refiner startSession: strictKvCache=$strictKvCache thinkingMode=$thinkingMode groundingChars=${grounding.length}")
        NativeRecursiveRefiner.setStrictKvMode(strictKvCache)
        NativeRecursiveRefiner.setThinkingMode(thinkingMode != "OFF", if (thinkingMode == "FORCE") 128 else 64)
        val cachedGrounding = buildCachedGrounding(grounding)
        val code = NativeRecursiveRefiner.beginSession(cachedGrounding)
        require(code == 0) { "Native refiner failed to cache grounding. Code: $code" }
        currentLens = RefinerConfigDefaults.lenses.first()
        lensIndex = 0
        lastRefined = null
        lastDirective = null
        history.clear()
        stuckCount = 0
        iteration = 0
        started = true
    }

    fun reset() {
        NativeRecursiveRefiner.resetSession()
        started = false
    }

    fun runOneIteration(): RefinerIteration {
        check(started) { "Start a refiner session first." }
        iteration += 1

        val targetCell = MesaEngine.selectExplorationTargetCell()
        val activePolicy = MesaEngine.selectWinningPolicy()
        currentLens = activePolicy.lens
        val lensUsed = currentLens

        if (webSearchEnabled) {
            val queryText = lastDirective ?: grounding
            val kw = WebSearchClient.extractKeywords(queryText)
            lastSearchQuery = kw
            lastSearchResults = kotlinx.coroutines.runBlocking { WebSearchClient.search(kw, 3) }
        } else {
            lastSearchQuery = ""
            lastSearchResults = emptyList()
        }

        val prompt = buildPrompt(targetCell, activePolicy)
        AppLog.append("Refiner iteration $iteration begin: strictKvCache=$strictKvCache thinkingMode=$thinkingMode policy=${activePolicy.name} promptChars=${prompt.length}")
        NativeRecursiveRefiner.setStrictKvMode(strictKvCache)
        NativeRecursiveRefiner.setThinkingMode(thinkingMode != "OFF", if (thinkingMode == "FORCE") 128 else 64)
        val start = System.nanoTime()
        val rawJson = NativeRecursiveRefiner.refineOnce(
            prompt = prompt,
            maxTokens = maxTokens,
            temperature = temperature,
            topK = topK,
            topP = topP,
            minP = minP,
            repeatPenalty = repeatPenalty
        )
        val seconds = ((System.nanoTime() - start).toDouble() / 1_000_000_000.0).toFloat()
        AppLog.append("Refiner iteration $iteration native returned chars=${rawJson.length}: ${rawJson.take(160)}")
        val parsed = parseRefinerJsonSafely(rawJson)

        val refined = sanitizeRefined(parsed.refined.trim()).smartLimit(RefinerConfigDefaults.MAX_REFINED_CHARS)
        val nextFocus = sanitizeNextFocus(parsed.next_focus.trim()).smartLimit(RefinerConfigDefaults.MAX_NEXT_FOCUS_CHARS)
        validateModelFields(refined, nextFocus, rawJson)

        val deltaRes = CognitiveOsMemory.registerDeltaUpdate(
            newClaim = refined,
            supportsId = parsed.supports?.takeIf { it.isNotBlank() },
            contradictsId = parsed.contradicts?.takeIf { it.isNotBlank() },
            closedQuestion = parsed.close_q?.takeIf { it.isNotBlank() },
            newQuestion = parsed.open_q?.takeIf { it.isNotBlank() }
        )
        val isDup = deltaRes == "duplicate"
        val establishedElite = MesaEngine.commitIterationResult(parsed.domain_tag, parsed.abstraction_level, refined, parsed.novelty_claim, isDup)
        CognitiveOsMemory.saveSnapshot(context)

        var changed = false
        if (isDup || !establishedElite) {
            stuckCount += 1
            changed = true
            if (stuckCount >= 2) {
                MesaEngine.recordReflexionFailure(refined.take(30), "Repeated valley attractor hypothesis.", "Jump distant MAP-Elites domain axis.")
                stuckCount = 0
            }
            rotateLens()
            lastDirective = "[STRICT REPETITION BREAKER]: Your last attempt failed to produce elite novelty. Axis closed. Pivot strictly to lens: " + currentLens
        } else {
            stuckCount = 0
            lastRefined = refined
            lastDirective = templateDirective(nextFocus)
            changed = checkDrift(refined)
            if (changed) lastDirective = templateDirective(nextFocus)
        }

        AppLog.append("Refiner iteration $iteration parsed OK lensUsed=$lensUsed currentLens=$currentLens changed=$changed")
        return RefinerIteration(
            iteration = iteration,
            lens = lensUsed,
            lensChanged = changed,
            refined = refined,
            nextFocus = nextFocus,
            generationTimeSeconds = seconds,
            stuckCount = stuckCount
        )
    }

    private fun buildPrompt(targetCell: ArchiveCell, activePolicy: ReasoningPolicy): String {
        val sb = StringBuilder()
        sb.append("You are MESA, a self-evolving reasoning agent. Target MAP-Elites Coordinate: [${targetCell.domainAxis}/${targetCell.abstractionAxis}]. ")
        sb.append("Active Thompson Reasoning Policy: ${activePolicy.name} (Prior Success Probability: ${"%.2f".format(activePolicy.successRate)}).\n")
        sb.append("\n[CURRENT MAP-ELITES ELITES (Top Surviving Diverse Hypotheses)]:\n")
        MesaEngine.archiveGrid.values.sortedByDescending { it.qualityScore }.take(3).forEach { elite ->
            sb.append("Cell [${elite.domainAxis}/${elite.abstractionAxis}]: \"${elite.bestHypothesis.take(110)}\" (Quality: ${"%.2f".format(elite.qualityScore)})\n")
        }
        if (MesaEngine.failureMemoryStore.isNotEmpty()) {
            sb.append("\n[REFLEXION VERBAL FAILURE MEMORY (Avoid Traps)]:\n")
            MesaEngine.failureMemoryStore.take(2).forEach { fm ->
                sb.append("Warning: Stalled on \"${fm.stuckPhrase}\". Root Cause: ${fm.whyStuck} Pivot: ${fm.pivotDirection}\n")
            }
        }
        sb.append("\nOriginal permanent grounding reminder: ")
        sb.append("Treat that grounding as the immutable original idea. Improve it through the requested lens. ")
        sb.append("Original grounding reminder: ").append(grounding.smartLimit(220)).append("\n")
        sb.append("Do not drift into unrelated systems; every refinement must directly answer or improve the original grounding. ")
        sb.append("Be concrete, specific, and constructive. Identify real gaps and propose real improvements. ")
        sb.append("Never return empty strings. Never copy the previous refinement verbatim. ")
        sb.append("Keep refined under ${RefinerConfigDefaults.MAX_REFINED_CHARS} characters and next_focus under ${RefinerConfigDefaults.MAX_NEXT_FOCUS_CHARS} characters. ")
        sb.append("If the previous result is already strong, add ONE new concrete constraint, metric, test, risk, implementation step, or tradeoff.\n")
        if (thinkingMode == "AUTO") {
            sb.append("Native thinking pre-stage is enabled: if helpful, think briefly in <think>...</think>, then final output must still be compact JSON.\n")
        } else if (thinkingMode == "FORCE") {
            sb.append("Native thinking pre-stage is enabled: think briefly in <think>...</think>, then final output must still be compact JSON.\n")
        }
        sb.append("\n")

        val searchGrounding = WebSearchClient.formatGrounding(lastSearchResults)
        if (searchGrounding.isNotEmpty()) {
            sb.append(searchGrounding).append("\n\n")
        }

        sb.append("[LIVE REFERENCE DIRECTIVE]: Bracketed IDs like [n001] below are references. Put them in supports/contradicts.\n").append(CognitiveOsMemory.assembleWorkingSetPrompt(iteration)).append("\n\n")
        sb.append(schemaDescription()).append("\n\n")
        sb.append("Refinement lens for THIS iteration: ").append(currentLens).append("\n\n")
        val prev = lastRefined
        val directive = lastDirective
        if (prev != null && directive != null) {
            sb.append("Previous refinement result, trimmed if long:\n")
                .append(prev.smartLimit(RefinerConfigDefaults.PREVIOUS_REFINED_CHAR_LIMIT))
                .append("\n\n")
            sb.append(directive).append("\n\n")
        }
        return sb.toString()
    }

    private fun buildCachedGrounding(text: String): String =
        "PERMANENT GROUNDING — immutable original idea:\n" +
            text.trim() +
            "\nEND PERMANENT GROUNDING. All future refinements must stay grounded in this idea.\n"

    private fun schemaDescription(): String =
        "Output ONE compact JSON object with exactly these 9 fields:\n" +
            "- \"refined\": improved version of idea — concrete, max 420 chars.\n" +
            "- \"next_focus\": what to examine next and why — max 160 chars.\n" +
            "- \"domain_tag\": ONE of [structural, biological, economic, physical, computational]. Pick domain CONTENT of \"refined\" reasons in.\n" +
            "- \"abstraction_level\": ONE of [concrete, intermediate, abstract].\n" +
            "- \"novelty_claim\": ONE sentence naming SPECIFIC new element in \"refined\". Max 110 chars.\n" +
            "- \"supports\": existing [nNNN] id from working set below that \"refined\" reinforces, or null.\n" +
            "- \"contradicts\": existing [nNNN] id that \"refined\" challenges, or null.\n" +
            "- \"close_q\": exact text of open question below that \"refined\" answers, or null.\n" +
            "- \"open_q\": one new specific question raised by \"refined\", or null.\n" +
            "Output ONLY the JSON object, nothing before or after it."

    private fun templateDirective(nextFocus: String): String =
        "Your task now: $nextFocus\n" +
            "This is not optional — refine specifically toward this. " +
            "Examine it from the lens of: $currentLens. " +
            "Do not merely restate the previous refinement; add exactly one compact concrete improvement, measurable criterion, implementation detail, or risk mitigation."

    private fun sanitizeRefined(value: String): String {
        var v = value
            .replace(Regex("(?is)\\n?\\s*next[_\\s-]*focus\\s*[:=].*$"), "")
            .replace(Regex("(?is)\\n?\\s*\\\"next_focus\\\"\\s*:\\s*\\\".*$"), "")
            .trim()
        // Some small models leak the second field in prose at the end of refined.
        v = v.replace(Regex("(?is)\\s+Next focus is .*$"), "").trim()
        return v
    }

    private fun sanitizeNextFocus(value: String): String = value
        .replace(Regex("(?is)^next[_\\s-]*focus\\s*[:=]\\s*"), "")
        .trim()

    private fun validateModelFields(refined: String, nextFocus: String, rawJson: String) {
        if (refined.length < RefinerConfigDefaults.MIN_REFINED_CHARS || nextFocus.length < RefinerConfigDefaults.MIN_NEXT_FOCUS_CHARS) {
            val msg = "Model returned too-short/empty JSON fields. refinedChars=${refined.length}, nextFocusChars=${nextFocus.length}. Raw=$rawJson"
            AppLog.append(msg)
            throw IllegalStateException(msg)
        }
    }

    private fun checkDrift(newRefined: String): Boolean {
        var maxOverlap = 0f
        for (old in history) {
            maxOverlap = max(maxOverlap, wordOverlap(newRefined, old))
        }
        stuckCount = if (maxOverlap > driftThreshold) stuckCount + 1 else 0

        var changed = false
        if (stuckCount >= driftWindow) {
            rotateLens()
            stuckCount = 0
            changed = true
        }

        history.addLast(newRefined)
        while (history.size > historySize) history.removeFirst()
        return changed
    }

    private fun rotateLens() {
        lensIndex = (lensIndex + 1) % RefinerConfigDefaults.lenses.size
        currentLens = RefinerConfigDefaults.lenses[lensIndex]
    }

    private fun String.smartLimit(limit: Int): String {
        if (length <= limit) return this
        return take(limit) + "\n[Previous refinement truncated for speed; continue improving from this summary.]"
    }

    private fun wordOverlap(a: String, b: String): Float {
        val wordsA = a.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        val wordsB = b.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        if (wordsA.isEmpty() || wordsB.isEmpty()) return 0f
        val intersection = wordsA.intersect(wordsB).size
        val union = wordsA.union(wordsB).size
        return intersection.toFloat() / union.toFloat()
    }


    private fun parseRefinerJsonSafely(rawJson: String): StrictRefinerJson {
        runCatching { return json.decodeFromString<StrictRefinerJson>(rawJson) }

        AppLog.append("WARN: strict JSON parse failed, attempting auto-repair. raw=" + rawJson.take(300))
        val repaired = attemptJsonRepair(rawJson)
        runCatching { return json.decodeFromString<StrictRefinerJson>(repaired) }

        val refinedMatch = Regex("\"refined\"\s*:\s*\"((?:[^\"\\\\]|\\\\.)*)\"").find(rawJson)
        val nextFocusMatch = Regex("\"next_focus\"\s*:\s*\"((?:[^\"\\\\]|\\\\.)*)\"").find(rawJson)
        if (refinedMatch != null && nextFocusMatch != null) {
            AppLog.append("WARN: repair failed, salvaged refined/next_focus via regex.")
            return StrictRefinerJson(refined = refinedMatch.groupValues[1], next_focus = nextFocusMatch.groupValues[1])
        }
        throw IllegalStateException("Unrecoverable JSON from native generation. raw=" + rawJson.take(800))
    }

    private fun attemptJsonRepair(raw: String): String {
        var s = raw.trim()
        if (!s.endsWith("}")) {
            if (s.count { it == """ } % 2 != 0) s += """
            s += "}"
        }
        return s
    }
}