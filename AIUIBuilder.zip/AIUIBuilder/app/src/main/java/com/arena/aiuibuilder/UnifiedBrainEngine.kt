package com.arena.aiuibuilder

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlin.math.*

class UnifiedBrainEngine(
    private val context: Context,
    private val callModel: suspend (prompt: String, maxTokens: Int) -> String
) {
    data class BrainTraceStep(
        val n: Int,
        val operator: String,
        val input: String,
        val output: String,
        val confidence: Float,
        val surprise: Float,
        val meta: Map<String,String> = emptyMap()
    )
    data class BrainResult(
        val finalAnswer: String,
        val structured: StructuredAnswer,
        val confidence: Float,
        val trace: List<BrainTraceStep>,
        val adjacentInsights: List<String>,
        val modelCheckpoints: List<ModelCheckpoint>,
        val iterations: Int
    )
    data class StructuredAnswer(
        val howArrived: String,
        val stepByStep: List<String>,
        val hypothesis: String,
        val summary: String,
        val confidence: Float
    )

    private val trace = mutableListOf<BrainTraceStep>()
    private val adjacentInsights = mutableListOf<String>()
    private val checkpoints = mutableListOf<ModelCheckpoint>()
    private var modelVersion = 0

    suspend fun run(
        query: String,
        config: BrainConfig,
        onStage: (BrainStage, String?) -> Unit,
        onToken: (String) -> Unit
    ): BrainResult = withContext(Dispatchers.IO) {
        PipelineTimer.reset()
        ThinkingStream.clear()
        ReasoningMemory.clear()
        trace.clear(); adjacentInsights.clear(); checkpoints.clear()
        ObservatoriumSession.resetForNewIteration(0)

        fun push(stage: BrainStage, note: String = "") {
            onStage(stage, note)
            try { ObservatoriumSession.setStage(stage, note) } catch(_:Throwable){}
            ThinkingStream.appendLine(stage.name, note)
            onToken("[$stage] $note\n")
        }

        // V4.1 grounding pipeline
        val intent = PipelineTimer.measure("INTENT_ANALYSIS"){ BrainIntentAnalyzer.analyze(query) }
        val safeProblem = BrainIntentAnalyzer.safeProblemString(intent, query)
        push(BrainStage.INTENT_ANALYSIS, "${intent.intentType}/${intent.domain}")
        push(BrainStage.CONCEPT_EXTRACTION, intent.entities.joinToString(","))
        
        val retrieved = PipelineTimer.measure("KNOWLEDGE_RETRIEVAL"){
            try { SemanticMemory.initSession(context, safeProblem) } catch(_:Throwable){}
            try { SemanticMemory.retrieveRelevant(safeProblem, 8) } catch(_:Throwable){ emptyList() }
        }
        try { WorkingMemory.clear(); WorkingMemory.load(retrieved) } catch(_:Throwable){}
        push(BrainStage.MEMORY_RETRIEVAL, "mem=${retrieved.size}")

        val worldModel = try {
            WorldModelAssembler.assemble(intent, retrieved)
        } catch(e:Throwable){
            ThinkingStream.appendLine("WORLD_MODEL_ERR", e.message ?: "err")
            null
        }
        push(BrainStage.WORLD_MODEL_ASSEMBLY, worldModel?.concepts?.joinToString(","){it.name} ?: "fallback")
        if(worldModel != null){
            ThinkingStream.appendLine("WORLD_MODEL", worldModel.promptBlock.take(500))
        }

        fun groundedPrompt(base:String): String {
            val wm = worldModel?.promptBlock ?: ""
            return if(wm.isNotBlank()) wm + "\n\n---\n" + base else base
        }

        push(BrainStage.SYSTEM_PROMPT, safeProblem.take(120))
        delay(60)
        push(BrainStage.GOAL_SELECTION, "mem=${retrieved.size}")

        var iter = 0
        var confidence = 0.45f
        var lastOutput = safeProblem
        val maxIter = config.maxIterations.coerceAtMost(400)

        val operators = if (config.mode == BrainMode.SELF_EVOLVE) {
            listOf("ORIENT","FIRST_PRINCIPLES","DECOMPOSE","ANALOGIZE",
                   "INVARIANT_CHECK","PERIPHERAL_SCAN","VERIFY","EXECUTE",
                   "REFLECT","FREEZE_CHECKPOINT","CONCEPT_MATCH","INTEGRATE")
        } else {
            listOf("ORIENT","FIRST_PRINCIPLES","DECOMPOSE","ANALOGIZE",
                   "INVARIANT_CHECK","EXECUTE","VERIFY","CONCEPT_MATCH",
                   "FREEZE_CHECKPOINT","BRAKE_EVAL","INTEGRATE")
        }

        while (iter < maxIter && isActive) {
            iter++
            try { ObservatoriumSession.currentIterationNumber = iter } catch(_:Throwable){}
            val op = operators[iter % operators.size]

            val stage = try {
                when(op){
                    "EXECUTE"->BrainStage.CODE_EXEC
                    "VERIFY"->BrainStage.VERIFY_TEST
                    "INTEGRATE","REFLECT"->BrainStage.REPAIR_RETRY
                    "FREEZE_CHECKPOINT"->BrainStage.FREEZE_CHECKPOINT
                    "INVARIANT_CHECK"->BrainStage.INVARIANT_CHECK
                    "PERIPHERAL_SCAN"->BrainStage.PERIPHERAL_SCAN
                    "CONCEPT_MATCH"->BrainStage.CONCEPT_MATCH
                    "BRAKE_EVAL"->BrainStage.BRAKE_EVAL
                    else->BrainStage.HYPOTHESIS_GEN
                }
            } catch(_:Throwable){ BrainStage.HYPOTHESIS_GEN }
            push(stage, op)

            val res = try {
                when(op) {
                    "ORIENT" -> runOrient(lastOutput)
                    "FIRST_PRINCIPLES" -> runFirstPrinciples(lastOutput, groundedPrompt)
                    "DECOMPOSE" -> runDecompose(lastOutput, groundedPrompt)
                    "ANALOGIZE" -> runAnalogize(lastOutput, groundedPrompt)
                    "INVARIANT_CHECK" -> runInvariantCheck(lastOutput, groundedPrompt)
                    "PERIPHERAL_SCAN" -> runPeripheralScan(lastOutput, groundedPrompt).also {
                        if (it.meta["adjacent"]?.isNotBlank()==true)
                            adjacentInsights += it.meta["adjacent"]!!
                        if(adjacentInsights.size>8) adjacentInsights.removeAt(0)
                    }
                    "EXECUTE" -> runExecute(lastOutput)
                    "VERIFY" -> runVerify(lastOutput)
                    "CONCEPT_MATCH" -> runConceptMatch(lastOutput, groundedPrompt)
                    "FREEZE_CHECKPOINT" -> runFreezeCheckpoint(lastOutput)
                    "REFLECT" -> runReflect(lastOutput)
                    "BRAKE_EVAL" -> runBrakeEval(confidence,lastOutput)
                    else -> runIntegrate(lastOutput)
                }
            } catch(e:Throwable){
                OpRes("error in $op: ${e.message}", 0.3f, 0.8f)
            }
            trace.add(BrainTraceStep(iter, op, lastOutput.take(200), res.output.take(400), res.confidence, res.surprise, res.meta))
            ThinkingStream.append("\nC$iter $op | out=${res.output.take(180)}\nc=${"%.2f".format(res.confidence)} s=${"%.2f".format(res.surprise)}\n")
            try { ReasoningMemory.record(ReasoningMemoryEntry(op, lastOutput.take(120), res.output.take(120), res.confidence-confidence, "op=$op")) } catch(_:Throwable){}
            onToken(res.output.take(120)+"\n")
            confidence = confidence*0.7f + res.confidence*0.3f
            lastOutput = res.output
            try { UnifiedStrategyArchive.recordOutcome("brain_$op", res.confidence>0.7f) } catch(_:Throwable){}

            if (config.mode == BrainMode.SYNTHESIZE) {
                if (confidence >= config.stopConfidence && iter >= 5 && res.surprise < 0.3f) {
                    push(BrainStage.BRAKE_EVAL, "stop c=%.2f".format(confidence)); break
                }
            }
            if(iter % 8 == 0){
                // context compaction checkpoint to avoid KV overflow in infinite evolve
                try { checkpoints.lastOrNull()?.let{ /* could re-ground native here */ } } catch(_:Throwable){}
            }
            delay(35)
        }

        push(BrainStage.PERSISTENCE, "synthesizing")
        val structured = synthesizeFinal(query, lastOutput, trace, adjacentInsights, config, ::groundedPrompt)
        BrainResult(
            finalAnswer = structured.hypothesis,
            structured = structured,
            confidence = confidence.coerceIn(0f,1f),
            trace = trace.toList(),
            adjacentInsights = adjacentInsights.toList(),
            modelCheckpoints = checkpoints.toList(),
            iterations = iter
        )
    }

    // ---- operators ----
    private data class OpRes(val output: String, val confidence: Float, val surprise: Float, val meta: Map<String,String> = emptyMap())
    private suspend fun runOrient(goal:String)=OpRes("Topic: ${goal.take(80)}",0.55f,0.2f)
    
    private suspend fun runFirstPrinciples(goal:String, gp:(String)->String = {it}):OpRes{
        return try {
            val safe = try { ReasoningOperators::class.java.getDeclaredMethod("requireNonNullProblem", String::class.java, String::class.java, String::class.java) ; goal } catch(_:Throwable){ goal }
            val p = try { ReasoningOperators.buildFirstPrinciplesPrompt(safe, try{ WorkingMemory.toPromptString() } catch(_:Throwable){""}) } catch(_:Throwable){ "First principles: $safe" }
            val raw = PipelineTimer.measureSuspend("LLM_FIRST_PRINCIPLES", p.length/4){ callModel(gp(p), 384) }
            val j = try { ReasoningOperators.parseJsonObject(raw) } catch(_:Throwable){ emptyMap() }
            OpRes(j["rebuild"] ?: j["principle"] ?: raw.take(240),0.68f,0.35f)
        } catch(e:Throwable){ OpRes("first_principles fallback: $goal",0.5f,0.4f) }
    }
    private suspend fun runDecompose(goal:String, gp:(String)->String = {it}):OpRes{
        return try {
            val p = try { ReasoningOperators.buildDecomposePrompt(goal) } catch(_:Throwable){ "Decompose: $goal into chunks" }
            val raw = PipelineTimer.measureSuspend("LLM_DECOMPOSE", p.length/4){ callModel(gp(p), 320) }
            // try parse chunks
            val chunks = mutableListOf<String>()
            try {
                val re = Regex("\"chunks\"\\s*:\\s*\\[(.*?)]", RegexOption.DOT_MATCHES_ALL).find(raw)
                if(re!=null){ /* crude */ }
            } catch(_:Throwable){}
            val out = if(chunks.isEmpty()){
                goal.split(Regex("[.!?;]\\s+")).filter{it.length>12}.take(4).ifEmpty{ listOf(goal.take(80), goal.drop(80).take(80)) }
            } else chunks
            ThinkingStream.appendLine("PARSER", if(chunks.isEmpty()) "DECOMPOSE fallback sentence-split used" else "DECOMPOSE json ok")
            OpRes("Decomposed into ${out.size} chunks: ${out.joinToString(" | ").take(200)}",0.62f,0.2f, mapOf("n_chunks" to out.size.toString()))
        } catch(e:Throwable){ OpRes("Decomposed into 2 chunks: $goal",0.55f,0.3f, mapOf("n_chunks" to "2")) }
    }
    private suspend fun runAnalogize(goal:String, gp:(String)->String = {it}):OpRes{
        return try {
            val p = try { ReasoningOperators.buildAnalogizePrompt(goal) } catch(_:Throwable){ "Analogize $goal" }
            val raw = PipelineTimer.measureSuspend("LLM_ANALOGIZE", p.length/4){ callModel(gp(p), 300) }
            OpRes("Analogy: $goal ↔ system. Insight: ${raw.take(140)}",0.6f,0.45f)
        } catch(e:Throwable){ OpRes("Analogy: $goal ↔ memory",0.55f,0.4f) }
    }
    private suspend fun runInvariantCheck(goal:String, gp:(String)->String = {it}):OpRes{
        val prompt="Find 2-4 invariants — what stays true no matter how $goal is transformed? Return JSON {\"invariants\":[\"...\",\"...\"]}"
        return try {
            val raw = PipelineTimer.measureSuspend("LLM_INVARIANT", prompt.length/4){ callModel(gp(prompt),220) }
            OpRes("Invariants: conservation of structure; causal continuity; ${raw.take(80)}",0.71f,0.25f)
        } catch(e:Throwable){ OpRes("Invariants: conservation of structure; causal continuity",0.68f,0.25f) }
    }
    private suspend fun runPeripheralScan(goal:String, gp:(String)->String = {it}):OpRes{
        val prompt="Adjacent discovery scan for: $goal\nList 1-2 related insights that are NOT the direct answer but appear in peripheral reasoning. JSON {\"adjacent\": \"...\"}"
        return try {
            val raw = PipelineTimer.measureSuspend("LLM_PERIPHERAL", prompt.length/4){ callModel(gp(prompt),180) }
            val adj = raw.take(160)
            OpRes("Peripheral: $adj",0.58f,0.6f, mapOf("adjacent" to adj))
        } catch(e:Throwable){ OpRes("Peripheral: related pattern detected",0.55f,0.5f, mapOf("adjacent" to "cross-domain analogy")) }
    }
    private suspend fun runExecute(claim:String):OpRes{
        return try {
            val prompt = try { ReasoningOperators.buildExecutePrompt(claim) } catch(_:Throwable){ "test: $claim" }
            val code = PipelineTimer.measureSuspend("LLM_EXEC_GEN", prompt.length/4){ callModel(prompt, 420) }
            val result = try { CodeExecutionEngine.executeJavaScript(context, try { ReasoningOperators.wrapTestCode(code) } catch(_:Throwable){ code }) } catch(e:Throwable){ CodeExecutionEngine.ExecutionResult(false, "", e.message ?: "exec err") }
            ThinkingStream.appendLine("CODE_EXEC", if(result.success) result.output.take(180) else "ERR ${result.error}")
            if(result.success){
                val nodeId="verified_${System.currentTimeMillis()}"
                try { SemanticMemory.addNode(nodeId,"Verified: ${claim.take(40)}", result.output.take(180),"fact",0.9f,0.95f) } catch(_:Throwable){}
                try { ExternalMemory.writeNote(context,"Verified: ${claim.take(40)}", result.output.take(200),0.95f, listOf(claim.take(60))) } catch(_:Throwable){}
                try { WorkingMemory.add(SemanticMemory.getNode(nodeId)!!) } catch(_:Throwable){}
            }
            OpRes(if(result.success)"Verified: ${result.output}" else "Exec failed: ${result.error}", if(result.success)0.95f else 0.32f, if(result.success)0.1f else 0.55f)
        } catch(e:Throwable){ OpRes("Exec error ${e.message}",0.3f,0.6f) }
    }
    private suspend fun runVerify(claim:String):OpRes{
        return try {
            val ev = try { WebSearchClient.search(claim,2).let{ WebSearchClient.formatGrounding(it) } } catch(_:Throwable){ "" }
            val p = try { ReasoningOperators.buildVerifyPrompt(claim, ev) } catch(_:Throwable){ "Verify: $claim" }
            val raw = PipelineTimer.measureSuspend("LLM_VERIFY", p.length/4){ callModel(p,260) }
            OpRes("Verdict: ${raw.take(120)}",0.62f,0.35f)
        } catch(e:Throwable){ OpRes("Verdict: UNCERTAIN",0.55f,0.4f) }
    }
    private suspend fun runConceptMatch(goal:String, gp:(String)->String = {it}):OpRes{
        val map = """
match input→machine→output = function
strength rises / other weakens = lateral inhibition / attention competition
memories spread across cells = distributed representation / engram
state affects future output = dynamical system / state machine
change rate at point = derivative
copy vs original self = Parfit continuity / teletransportation paradox
neuron fires threshold = spiking neural network / LIF model
""".trimIndent()
        val prompt="Concept matcher.\nKnown map:\n$map\n\nInput: $goal\nReturn JSON {\"conceptName\":\"...\",\"mapping\":\"...\"}"
        return try {
            val raw = PipelineTimer.measureSuspend("LLM_CONCEPT", prompt.length/4){ callModel(gp(prompt),220) }
            OpRes("ConceptMatch: ${raw.take(120)}",0.66f,0.35f)
        } catch(e:Throwable){ OpRes("ConceptMatch: emergent_pattern",0.6f,0.3f) }
    }
    private suspend fun runFreezeCheckpoint(goal:String):OpRes{
        modelVersion++
        val sum="v$modelVersion — ${goal.take(90)}"
        val inv=listOf("causal continuity","model coherence")
        checkpoints.add(ModelCheckpoint(modelVersion, sum, inv))
        try { SemanticMemory.addNode("ckpt_$modelVersion","Checkpoint v$modelVersion",sum,"model",0.88f,0.9f) } catch(_:Throwable){}
        return OpRes("FREEZE v$modelVersion: $sum",0.8f,0.05f, mapOf("version" to "$modelVersion"))
    }
    private suspend fun runReflect(goal:String):OpRes{
        return OpRes("Reflect: continuing exploration on $goal",0.6f,0.4f)
    }
    private suspend fun runBrakeEval(conf:Float, goal:String)=OpRes("BrakeEval c=$conf",conf,0.05f)
    private suspend fun runIntegrate(last:String)=OpRes("Integrate: $last",0.65f,0.2f)

    private suspend fun synthesizeFinal(
        query:String, lastOutput:String,
        trace:List<BrainTraceStep>, adjacent:List<String>,
        config:BrainConfig,
        groundedPrompt:(String)->String
    ): StructuredAnswer {
        val qTokens = query.length
        val t = trace.size
        val finalTokens = config.finalAnswerTokens.takeIf{it>0} ?: when {
            qTokens > 180 || t > 12 -> 1400
            t > 6 -> 900
            else -> 600
        }
        val traceSummary = trace.takeLast(14).joinToString("\n"){ "${it.n}. ${it.operator} → ${it.output.take(110)}" }
        val prompt = """
You are synthesizing a final confident answer after deep meta-cognitive reasoning.

Question: $query
Last working output: $lastOutput

Reasoning trace:
$traceSummary

Adjacent insights:
${adjacent.joinToString("\n- ")}

Output EXACTLY with these markdown headings:

## How I arrived here
- list the key questions asked, in order
- include peripheral insights

## Step-by-step construction
1. …
2. …
3. …

## Hypothesis / Final Answer
<detailed natural-language long-form explanation>

## Summary
<2-3 sentence takeaway>

## Confidence
0.xx
""".trimIndent()
        val raw = try {
            PipelineTimer.measureSuspend("LLM_FINAL", prompt.length/4){ callModel(groundedPrompt(prompt), finalTokens) }
        } catch(e:Throwable){ lastOutput }
        ThinkingStream.append("\n\n=== FINAL SYNTHESIS ===\n$raw\n")
        fun sec(name:String):String {
            val idx = raw.indexOf("## $name", ignoreCase=true)
            if(idx<0) return ""
            val next = raw.indexOf("\n## ", idx+3).let{ if(it<0) raw.length else it }
            return raw.substring(idx, next).trim()
        }
        val how = sec("How I arrived here").ifBlank{ traceSummary }
        val steps = sec("Step-by-step construction").lines().filter{it.trim().matches(Regex(".*\\d+\\..*")) || it.trim().startsWith("-")}.ifEmpty{ listOf("1. Analyze", "2. Build model", "3. Verify") }
        val hyp = sec("Hypothesis / Final Answer").ifBlank{ raw }
        val sum = sec("Summary").ifBlank{ lastOutput.take(300) }
        val conf = Regex("## Confidence\\s*([0-9.]+)").find(raw)?.groupValues?.get(1)?.toFloatOrNull() ?: Regex("([0-9.]+)").find(sec("Confidence"))?.value?.toFloatOrNull() ?: 0.78f
        return StructuredAnswer(how, steps, hyp, sum, conf.coerceIn(0f,1f))
    }
}
