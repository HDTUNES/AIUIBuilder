package com.arena.aiuibuilder

import android.content.Context
import kotlinx.coroutines.*
import kotlin.math.*

class UnifiedBrainEngine(
    private val context: Context,
    private val callModel: suspend (prompt: String, maxTokens: Int) -> String
) {
    data class BrainTraceStep(
        val n: Int,
        val operator: String,
        val input: String,
        val output: String,
        val confidence: Float,
        val surprise: Float,
        val meta: Map<String,String> = emptyMap()
    )
    data class BrainResult(
        val finalAnswer: String,
        val structured: StructuredAnswer,
        val confidence: Float,
        val trace: List<BrainTraceStep>,
        val adjacentInsights: List<String>,
        val modelCheckpoints: List<ModelCheckpoint>,
        val iterations: Int
    )
    data class StructuredAnswer(
        val howArrived: String,
        val stepByStep: List<String>,
        val hypothesis: String,
        val summary: String,
        val confidence: Float
    )

    private data class OpRes(val output: String, val confidence: Float, val surprise: Float, val meta: Map<String,String> = emptyMap())

    private val trace = mutableListOf<BrainTraceStep>()
    private val adjacentInsights = mutableListOf<String>()
    private val checkpoints = mutableListOf<ModelCheckpoint>()
    private var modelVersion = 0

    suspend fun run(
        query: String,
        config: BrainConfig,
        onStage: (BrainStage, String?) -> Unit,
        onToken: (String) -> Unit
    ): BrainResult = withContext(Dispatchers.IO) {
        try { PipelineTimer.reset() } catch(_:Throwable){}
        try { ThinkingStream.clear() } catch(_:Throwable){}
        try { ReasoningMemory.clear() } catch(_:Throwable){}
        trace.clear(); adjacentInsights.clear(); checkpoints.clear()
        try { ObservatoriumSession.resetForNewIteration(0) } catch(_:Throwable){}
        try {
            val m = ObservatoriumSession::class.java.methods.find { it.name == "resetForNewBrainIteration" }
            m?.invoke(ObservatoriumSession, 0)
        } catch(_:Throwable){}

        fun push(stage: BrainStage, note: String = "") {
            try { onStage(stage, note) } catch(_:Throwable){}
            try {
                val mm = ObservatoriumSession::class.java.methods.find { it.name == "setStage" && it.parameterCount == 2 }
                mm?.invoke(ObservatoriumSession, stage, note)
            } catch(_:Throwable){}
            try { ThinkingStream.appendLine(stage.name, note) } catch(_:Throwable){}
            try { onToken("[$stage] $note\n") } catch(_:Throwable){}
        }

        val intent = try {
            PipelineTimer.measure("INTENT_ANALYSIS", 0) { BrainIntentAnalyzer.analyze(query) }
        } catch(_:Throwable){
            BrainIntent(query, query, "general", emptyList(), "explore", true, null)
        }
        val safeProblem = try { BrainIntentAnalyzer.safeProblemString(intent, query) } catch(_:Throwable){ query }
        push(BrainStage.INTENT_ANALYSIS, "${intent.intentType}/${intent.domain}")
        push(BrainStage.CONCEPT_EXTRACTION, intent.entities.joinToString(","))

        val retrieved = try {
            PipelineTimer.measure("KNOWLEDGE_RETRIEVAL", 0) {
                try { SemanticMemory.initSession(context, safeProblem) } catch(_:Throwable){}
                try { SemanticMemory.retrieveRelevant(safeProblem, 8) } catch(_:Throwable){ emptyList() }
            }
        } catch(_:Throwable){ emptyList<SemanticNode>() }

        try { WorkingMemory.load(retrieved) } catch(_:Throwable){}
        push(BrainStage.MEMORY_RETRIEVAL, "mem=${retrieved.size}")

        val worldModel = try { WorldModelAssembler.assemble(intent, retrieved) } catch(_:Throwable){ null }
        push(BrainStage.WORLD_MODEL_ASSEMBLY, worldModel?.concepts?.joinToString(","){ it.name } ?: "fallback")
        if (worldModel != null) { try { ThinkingStream.appendLine("WORLD_MODEL", worldModel.promptBlock.take(380)) } catch(_:Throwable){} }

        fun groundedPrompt(base: String): String {
            val wm = worldModel?.promptBlock ?: ""
            return if (wm.isNotBlank()) wm + "\n\n---\n" + base else base
        }

        push(BrainStage.SYSTEM_PROMPT, safeProblem.take(120))
        delay(50)
        push(BrainStage.GOAL_SELECTION, "mem=${retrieved.size}")

        var iter = 0
        var confidence = 0.45f
        var lastOutput = safeProblem
        val maxIter = config.maxIterations.coerceAtMost(400)

        val operators = if (config.mode == BrainMode.SELF_EVOLVE) {
            listOf("ORIENT","FIRST_PRINCIPLES","DECOMPOSE","ANALOGIZE","INVARIANT_CHECK","PERIPHERAL_SCAN","VERIFY","EXECUTE","REFLECT","FREEZE_CHECKPOINT","CONCEPT_MATCH","INTEGRATE")
        } else {
            listOf("ORIENT","FIRST_PRINCIPLES","DECOMPOSE","ANALOGIZE","INVARIANT_CHECK","EXECUTE","VERIFY","CONCEPT_MATCH","FREEZE_CHECKPOINT","BRAKE_EVAL","INTEGRATE")
        }

        while (iter < maxIter && isActive) {
            iter++
            try { ObservatoriumSession.currentIterationNumber = iter } catch(_:Throwable){}
            val op = operators[iter % operators.size]
            val stage = try {
                when(op) {
                    "EXECUTE" -> BrainStage.CODE_EXEC
                    "VERIFY" -> BrainStage.VERIFY_TEST
                    "INTEGRATE", "REFLECT" -> BrainStage.REPAIR_RETRY
                    "FREEZE_CHECKPOINT" -> BrainStage.FREEZE_CHECKPOINT
                    "INVARIANT_CHECK" -> BrainStage.INVARIANT_CHECK
                    "PERIPHERAL_SCAN" -> BrainStage.PERIPHERAL_SCAN
                    "CONCEPT_MATCH" -> BrainStage.CONCEPT_MATCH
                    "BRAKE_EVAL" -> BrainStage.BRAKE_EVAL
                    else -> BrainStage.HYPOTHESIS_GEN
                }
            } catch(_:Throwable){ BrainStage.HYPOTHESIS_GEN }
            push(stage, op)

            val res: OpRes = try {
                when(op) {
                    "ORIENT" -> runOrient(lastOutput)
                    "FIRST_PRINCIPLES" -> runFirstPrinciples(lastOutput, ::groundedPrompt)
                    "DECOMPOSE" -> runDecompose(lastOutput, ::groundedPrompt)
                    "ANALOGIZE" -> runAnalogize(lastOutput, ::groundedPrompt)
                    "INVARIANT_CHECK" -> runInvariantCheck(lastOutput, ::groundedPrompt)
                    "PERIPHERAL_SCAN" -> runPeripheralScan(lastOutput, ::groundedPrompt)
                    "EXECUTE" -> runExecute(lastOutput)
                    "VERIFY" -> runVerify(lastOutput)
                    "CONCEPT_MATCH" -> runConceptMatch(lastOutput, ::groundedPrompt)
                    "FREEZE_CHECKPOINT" -> runFreezeCheckpoint(lastOutput)
                    "REFLECT" -> runReflect(lastOutput)
                    "BRAKE_EVAL" -> runBrakeEval(confidence, lastOutput)
                    else -> runIntegrate(lastOutput)
                }
            } catch(e: Throwable) {
                OpRes("error $op: ${e.message}", 0.3f, 0.7f)
            }

            if (op == "PERIPHERAL_SCAN") {
                val adj = res.meta["adjacent"]
                if (!adj.isNullOrBlank()) { adjacentInsights.add(adj); if (adjacentInsights.size > 8) adjacentInsights.removeAt(0) }
            }

            trace.add(BrainTraceStep(iter, op, lastOutput.take(200), res.output.take(400), res.confidence, res.surprise, res.meta))
            try { ThinkingStream.append("\n[$op #$iter] ${res.output.take(180)}\nconf=${"%.2f".format(res.confidence)}\n") } catch(_:Throwable){}
            try { ReasoningMemory.record(ReasoningMemoryEntry(op, lastOutput.take(100), res.output.take(100), res.confidence - confidence, "brain")) } catch(_:Throwable){}
            try { onToken(res.output.take(80) + "\n") } catch(_:Throwable){}
            confidence = confidence * 0.7f + res.confidence * 0.3f
            lastOutput = res.output
            try { UnifiedStrategyArchive.recordOutcome("brain_$op", res.confidence > 0.7f) } catch(_:Throwable){}
            if (config.mode == BrainMode.SYNTHESIZE && confidence >= config.stopConfidence && iter >= 5 && res.surprise < 0.3f) {
                push(BrainStage.BRAKE_EVAL, "stop %.2f".format(confidence)); break
            }
            delay(25)
        }

        push(BrainStage.PERSISTENCE, "synthesizing")
        val structured = synthesizeFinal(query, lastOutput, trace, adjacentInsights, config, ::groundedPrompt)
        BrainResult(
            finalAnswer = structured.hypothesis,
            structured = structured,
            confidence = confidence.coerceIn(0f, 1f),
            trace = trace.toList(),
            adjacentInsights = adjacentInsights.toList(),
            modelCheckpoints = checkpoints.toList(),
            iterations = iter
        )
    }

    // ---------- operators (single definition each, compile-safe) ----------
    private suspend fun runOrient(goal: String) = OpRes("ORIENT: $goal", 0.55f, 0.2f)

    private suspend fun runFirstPrinciples(goal: String, gp: (String) -> String): OpRes {
        return try {
            val prompt = gp("First principles analysis:\n$goal\nReturn JSON {\"principle\":\"...\",\"rebuild\":\"...\"}")
            val raw = try { PipelineTimer.measureSuspend("LLM_FIRST_PRINCIPLES", prompt.length/4){ callModel(prompt, 320) } }
                      catch(_:Throwable){ callModel(prompt, 280) }
            OpRes(raw.take(240).ifBlank{"principle analysis $goal"}, 0.68f, 0.35f)
        } catch(e: Throwable) { OpRes("first_principles: $goal", 0.55f, 0.35f) }
    }

    private suspend fun runDecompose(goal: String, gp: (String) -> String): OpRes {
        return try {
            val prompt = gp("Decompose into 3-5 testable subproblems: $goal")
            val raw = try { PipelineTimer.measureSuspend("LLM_DECOMPOSE", prompt.length/4){ callModel(prompt, 280) } }
                      catch(_:Throwable){ callModel(prompt, 240) }
            // never 0 chunks — sentence split fallback
            val parts = goal.split(Regex("[.!?;\\n]+")).map{it.trim()}.filter{it.length>8}.take(4)
            val out = if(parts.isEmpty()) listOf(goal.take(90), "analyze implications", "test hypothesis") else parts
            try { ThinkingStream.appendLine("PARSER", "DECOMPOSE chunks=${out.size}") } catch(_:Throwable){}
            OpRes("Decomposed into ${out.size} chunks: ${out.joinToString(" | ").take(200)}", 0.62f, 0.2f, mapOf("n_chunks" to out.size.toString()))
        } catch(e: Throwable) {
            OpRes("Decomposed into 2 chunks: $goal", 0.55f, 0.3f, mapOf("n_chunks" to "2"))
        }
    }

    // SINGLE analogize — fixes conflicting overloads CI error
    private suspend fun runAnalogize(goal: String, gp: (String) -> String): OpRes {
        return try {
            val prompt = gp("Find a close physical/electrical analogy for: $goal\nReturn JSON {\"analogy\":\"...\",\"insight\":\"...\",\"limit\":\"...\"}")
            val raw = try { PipelineTimer.measureSuspend("LLM_ANALOGIZE", prompt.length/4){ callModel(prompt, 260) } }
                      catch(_:Throwable){ callModel(prompt, 220) }
            val out = raw.take(200).ifBlank{"Analogy: $goal ↔ system"}
            OpRes(out, 0.60f, 0.45f)
        } catch(e: Throwable) {
            OpRes("Analogy: $goal ↔ memory", 0.55f, 0.4f)
        }
    }

    private suspend fun runInvariantCheck(goal: String, gp: (String) -> String): OpRes {
        val prompt = gp("List 2-4 invariants that stay true for: $goal\nJSON {\"invariants\":[\"...\",\"...\"]}")
        return try {
            val raw = PipelineTimer.measureSuspend("LLM_INVARIANT", prompt.length/4){ callModel(prompt, 200) }
            OpRes("Invariants: ${raw.take(140)}", 0.71f, 0.25f)
        } catch(e:Throwable){ OpRes("Invariants: conservation; continuity; threshold", 0.68f, 0.25f) }
    }

    private suspend fun runPeripheralScan(goal: String, gp: (String) -> String): OpRes {
        val prompt = gp("Peripheral/adjacent insight scan (not direct answer) for: $goal\nJSON {\"adjacent\":\"...\"}")
        return try {
            val raw = PipelineTimer.measureSuspend("LLM_PERIPHERAL", prompt.length/4){ callModel(prompt, 160) }
            val adj = raw.take(160).replace(Regex("[\\r\\n]+"), " ")
            OpRes("Peripheral: $adj", 0.58f, 0.6f, mapOf("adjacent" to adj))
        } catch(e:Throwable){
            OpRes("Peripheral: cross-domain analogy", 0.55f, 0.5f, mapOf("adjacent" to "cross-domain analogy"))
        }
    }

    private suspend fun runExecute(claim: String): OpRes {
        return try {
            val prompt = "Generate a short JavaScript test to verify: $claim\nReturn only code, no markdown."
            val code = try { PipelineTimer.measureSuspend("LLM_EXEC_GEN", prompt.length/4){ callModel(prompt, 300) } }
                       catch(_:Throwable){ "console.log('test ok');" }
            val result = try { CodeExecutionEngine.executeJavaScript(context, code) }
                         catch(e: Throwable){ CodeExecutionEngine.ExecutionResult(false, "", e.message ?: "exec err") }
            try { ThinkingStream.appendLine("CODE_EXEC", if(result.success) result.output.take(180) else "ERR ${result.error}") } catch(_:Throwable){}
            if (result.success) {
                val nodeId = "verified_${System.currentTimeMillis()}"
                try { SemanticMemory.addNode(nodeId, "Verified: ${claim.take(40)}", result.output.take(180), "fact", 0.9f, 0.95f) } catch(_:Throwable){}
                try { ExternalMemory.writeNote(context, "Verified: ${claim.take(40)}", result.output.take(200), 0.95f, listOf(claim.take(60))) } catch(_:Throwable){}
            }
            OpRes(if(result.success) "Verified: ${result.output}" else "Exec failed: ${result.error}", if(result.success)0.95f else 0.32f, if(result.success)0.1f else 0.55f)
        } catch(e:Throwable){ OpRes("Exec error ${e.message}",0.3f,0.6f) }
    }

    private suspend fun runVerify(claim: String): OpRes {
        return try {
            val ev = try { WebSearchClient.search(claim,2).let{ WebSearchClient.formatGrounding(it) } } catch(_:Throwable){ "" }
            val p = "Verify claim with evidence:\nClaim: $claim\nEvidence: $ev\nJSON {\"verdict\":\"SUPPORTED|REFUTED|UNCERTAIN\",\"confidence\":0.0}"
            val raw = PipelineTimer.measureSuspend("LLM_VERIFY", p.length/4){ callModel(p, 220) }
            OpRes("Verify: ${raw.take(140)}", 0.62f, 0.35f)
        } catch(e:Throwable){ OpRes("Verify: UNCERTAIN",0.55f,0.4f) }
    }

    private suspend fun runConceptMatch(goal: String, gp: (String) -> String): OpRes {
        val prompt = gp("Name the closest known scientific/engineering concept for: $goal\nJSON {\"conceptName\":\"...\",\"mapping\":\"...\"}")
        return try {
            val raw = PipelineTimer.measureSuspend("LLM_CONCEPT", prompt.length/4){ callModel(prompt, 180) }
            OpRes("ConceptMatch: ${raw.take(120)}",0.66f,0.35f)
        } catch(e:Throwable){ OpRes("ConceptMatch: emergent_pattern",0.6f,0.3f) }
    }

    private suspend fun runFreezeCheckpoint(goal: String): OpRes {
        modelVersion++
        val sum = "v$modelVersion — ${goal.take(90)}"
        val inv = listOf("causal continuity","model coherence")
        checkpoints.add(ModelCheckpoint(modelVersion, sum, inv))
        try { SemanticMemory.addNode("ckpt_$modelVersion", "Checkpoint v$modelVersion", sum, "model", 0.88f, 0.9f) } catch(_:Throwable){}
        return OpRes("FREEZE v$modelVersion: $sum",0.8f,0.05f, mapOf("version" to "$modelVersion"))
    }

    private suspend fun runReflect(goal: String): OpRes {
        return OpRes("Reflect: $goal",0.6f,0.4f)
    }

    private suspend fun runBrakeEval(conf: Float, goal: String) = OpRes("BrakeEval c=$conf", conf, 0.05f)
    private suspend fun runIntegrate(last: String) = OpRes("Integrate: $last",0.65f,0.2f)

    private suspend fun synthesizeFinal(
        query: String,
        lastOutput: String,
        trace: List<BrainTraceStep>,
        adjacent: List<String>,
        config: BrainConfig,
        groundedPrompt: (String) -> String
    ): StructuredAnswer {
        val qTokens = query.length
        val t = trace.size
        val finalTokens = config.finalAnswerTokens.takeIf{it>0} ?: when {
            qTokens > 180 || t > 12 -> 1400
            t > 6 -> 900
            else -> 600
        }
        val traceSummary = trace.takeLast(14).joinToString("\n"){ "${it.n}. ${it.operator} → ${it.output.take(110)}" }
        val promptText = """
You are synthesizing a final confident answer after deep meta-cognitive reasoning.

Question: $query
Last working output: $lastOutput

Reasoning trace:
$traceSummary

Adjacent insights:
${adjacent.joinToString("\n- ")}

Output EXACTLY with these markdown headings:

## How I arrived here
- list the key questions asked, in order
- include peripheral insights

## Step-by-step construction
1. …
2. …
3. …

## Hypothesis / Final Answer
<detailed natural-language long-form explanation>

## Summary
<2-3 sentence takeaway>

## Confidence
0.xx
""".trimIndent()
        val raw = try {
            PipelineTimer.measureSuspend("LLM_FINAL", promptText.length/4){ callModel(groundedPrompt(promptText), finalTokens) }
        } catch(e:Throwable){ lastOutput }
        try { ThinkingStream.append("\n\n=== FINAL SYNTHESIS ===\n$raw\n") } catch(_:Throwable){}
        fun sec(name:String):String {
            val idx = raw.indexOf("## $name", ignoreCase=true)
            if(idx<0) return ""
            val next = raw.indexOf("\n## ", idx+3).let{ if(it<0) raw.length else it }
            return raw.substring(idx, next).trim()
        }
        val how = sec("How I arrived here").ifBlank{ traceSummary }
        val steps = sec("Step-by-step construction").lines()
            .map{it.trim()}.filter{ it.matches(Regex(".*\\d+\\..*")) || it.startsWith("-") || it.startsWith("•") }
            .ifEmpty{ listOf("1. Analyze", "2. Build model", "3. Verify") }
        val hyp = sec("Hypothesis / Final Answer").ifBlank{ raw }
        val sum = sec("Summary").ifBlank{ lastOutput.take(300) }
        val conf = Regex("## Confidence\\s*([0-9.]+)").find(raw)?.groupValues?.get(1)?.toFloatOrNull()
            ?: Regex("([0-9.]+)").find(sec("Confidence"))?.value?.toFloatOrNull()
            ?: 0.78f
        return StructuredAnswer(how, steps, hyp, sum, conf.coerceIn(0f,1f))
    }
}
