package com.arena.aiuibuilder

import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object PipelineTimer {
    data class Span(val stage:String, val ms:Long, val tokensIn:Int=0, val tokensOut:Int=0, val ok:Boolean=true, val note:String="")
    private val spans = mutableListOf<Span>()
    private val _live = MutableStateFlow<List<Span>>(emptyList())
    val live: StateFlow<List<Span>> = _live

    inline fun <T> measure(stage:String, tokensIn:Int=0, block:()->T): T {
        val t0 = SystemClock.elapsedRealtime()
        var ok=true; var note=""; var outTok=0
        try {
            val r = block()
            if(r is String) outTok = r.length/4
            return r
        } catch(e:Throwable){ ok=false; note=e.message?:"err"; throw e }
        finally {
            val ms = SystemClock.elapsedRealtime()-t0
            synchronized(spans){
                spans.add(Span(stage, ms, tokensIn, outTok, ok, note))
                if(spans.size>400) spans.removeAt(0)
                _live.value = spans.takeLast(40)
            }
            val flag = if(ms>5000) "🚨" else if(ms>1000) "⚠" else "·"
            val line = "$flag $stage ${ms}ms in=$tokensIn out~$outTok ${if(!ok)"FAIL $note" else ""}"
            AppLog.log("TIMER", line)
            try { ThinkingStream.appendLine("TIMER", line) } catch(_:Throwable){}
        }
    }
    suspend inline fun <T> measureSuspend(stage:String, tokensIn:Int=0, crossinline block:suspend()->T): T {
        val t0 = SystemClock.elapsedRealtime()
        var ok=true; var note=""
        try { return block() }
        catch(e:Throwable){ ok=false; note=e.message?:"err"; throw e }
        finally {
            val ms = SystemClock.elapsedRealtime()-t0
            synchronized(spans){ spans.add(Span(stage, ms, tokensIn,0,ok,note)); _live.value = spans.takeLast(40) }
            val flag = if(ms>120000) "🚨 LLM ${ms/1000}s" else if(ms>5000) "⚠" else "·"
            try { ThinkingStream.appendLine("TIMER", "$flag $stage ${ms}ms") } catch(_:Throwable){}
            AppLog.log("TIMER", "$stage ${ms}ms")
        }
    }
    fun summary(): String {
        val g = spans.groupBy{it.stage}
        return g.entries.joinToString("\n"){ (k,v)->
            val tot=v.sumOf{it.ms}; val avg=tot/maxOf(1,v.size); val fails=v.count{!it.ok}
            "%-22s %4d calls  tot %6dms  avg %4dms  fails %d".format(k, v.size, tot, avg, fails)
        } + "\nTOTAL ${spans.sumOf{it.ms}}ms across ${spans.size} spans"
    }
    fun reset(){ synchronized(spans){ spans.clear(); _live.value = emptyList() } }
}
