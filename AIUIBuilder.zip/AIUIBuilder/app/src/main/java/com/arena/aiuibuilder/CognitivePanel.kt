package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.launch

private val Panel = Color(0xFF111827)
private val Panel2 = Color(0xFF0F172A)
private val Stroke = Color(0xFF263244)
private val TextMain = Color(0xFFE5E7EB)
private val TextMuted = Color(0xFF94A3B8)
private val Accent = Color(0xFF7C3AED)

@Composable
fun CognitivePanel(
    engine: InferenceEngine,
    enabled: Boolean,
    maxTokens: Int,
    onStatus: (String) -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = AppScopes.main
    val clipboard = LocalClipboardManager.current

    var query by remember { mutableStateOf("") }
    var isRunning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CognitiveResult?>(null) }
    var rawTrace by remember { mutableStateOf("") }

    // FIX (architecture blueprint Part 5.0): engine.sendUserPrompt() appends to the
    // shared native context on every call and never resets it -- across a 20-iteration
    // reason() loop, the native context (default 2048 tokens) fills up within the
    // first ~3 iterations, after which automatic context-shifting silently evicts
    // earlier iterations from the model's attention. NativeRecursiveRefiner's
    // beginSession()/generateGrounded() resets the context to a fixed checkpoint
    // before every call instead, so the loop stays bounded no matter how many
    // iterations run. generateGrounded() is the schema-free counterpart to
    // refineOnce() -- it does NOT force the Refiner's fixed JSON grammar, so each
    // operator's own JSON shape (DECOMPOSE's chunks array, VERIFY's confidence
    // float, etc.) is unaffected.
    //
    // Trade-off, by design: beginSession()/resetSession() clear the ENTIRE shared
    // llama.cpp context (there's only one), so the Chat tab's system-prompt framing
    // will be gone if you switch back to it after running the Cognitive engine.
    // That's a real cost of sharing one native context across tabs -- see Part 5.0
    // for the follow-up needed to close that gap (re-decoding the system prompt on
    // session end), not yet implemented here.
    val callModel: suspend (String, Int) -> String = { prompt, tokens ->
        NativeRecursiveRefiner.generateGrounded(
            prompt = prompt,
            maxTokens = tokens,
            temperature = 0.4f,
            topK = 40,
            topP = 0.9f,
            minP = 0.05f,
            repeatPenalty = 1.1f
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Stroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Cognitive Engine", color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Systematic, human-brain-like reasoning: orient, decompose, analogize, verify, integrate, and learn.", color = TextMuted)

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Enter a complex question or topic") },
                minLines = 3
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    enabled = enabled && query.isNotBlank() && !isRunning,
                    onClick = {
                        scope.launch {
                            isRunning = true
                            result = null
                            rawTrace = ""
                            onStatus("Cognitive engine reasoning...")
                            try {
                                // Reset observatory for new cognitive session
                                ObservatoriumSession.resetForNewIteration(0)

                                // Bounded-context fix: ground the native session on a short,
                                // fixed framing + the user's question, NOT the evolving
                                // WorkingMemory (which changes every iteration -- grounding
                                // is meant to be the one thing that stays fixed for the
                                // whole session). Compatibility mode (strict=false) re-decodes
                                // this small grounding each call instead of relying on
                                // llama_memory_seq_rm, which is the safer choice across
                                // unknown/exotic model architectures -- see Part 5.0 if you
                                // want to opt into strict mode for speed once you've verified
                                // it behaves correctly with your specific model.
                                NativeRecursiveRefiner.setStrictKvMode(false)
                                val grounding = "You are a careful, systematic reasoner. " +
                                    "The question you are working through is:\n$query"
                                val sessionResult = NativeRecursiveRefiner.beginSession(grounding)
                                if (sessionResult != 0) {
                                    onError("Could not start cognitive session (is a model loaded?)")
                                    onStatus("Cognitive engine failed.")
                                    return@launch
                                }

                                val cognitiveEngine = CognitiveEngine(context, callModel)
                                val res = cognitiveEngine.reason(query)
                                result = res
                                rawTrace = res.trace.joinToString("\n")
                                onStatus("Cognitive reasoning complete. Confidence: ${"%.0f".format(res.confidence * 100)}%")
                            } catch (t: Throwable) {
                                AppLog.appendError("Cognitive engine failed", t)
                                onError(t.message ?: t.toString())
                                onStatus("Cognitive engine failed.")
                            } finally {
                                runCatching { NativeRecursiveRefiner.resetSession() }
                                isRunning = false
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Think")
                }
                if (isRunning) CircularProgressIndicator(modifier = Modifier.height(24.dp), color = Accent, strokeWidth = 2.dp)
            }

            // ── Embedded Observatory for Cognitive Mode ────────────────────────
            LiveObservatoryPanel(
                iterationNumber = ObservatoriumSession.currentIterationNumber,
                stageMap = ObservatoriumSession.stageMap,
                liveTokenStream = ObservatoriumSession.liveTokenStream
            )

            result?.let { res ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel2),
                    border = BorderStroke(1.dp, Stroke),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Final Answer", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(res.finalAnswer)) }) { Text("Copy") }
                        }
                        LatexAwareText(res.finalAnswer, color = TextMain)
                        Text("Confidence: ${"%.0f".format(res.confidence * 100)}%", color = TextMuted)
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF080B12)),
                    border = BorderStroke(1.dp, Stroke),
                    modifier = Modifier.fillMaxWidth().height(280.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Reasoning Trace", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(rawTrace)) }) { Text("Copy") }
                        }
                        Text(rawTrace, color = TextMuted)
                    }
                }
            }
        }
    }
}
