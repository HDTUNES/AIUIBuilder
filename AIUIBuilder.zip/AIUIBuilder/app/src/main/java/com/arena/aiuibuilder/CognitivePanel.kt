package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.arm.aichat.InferenceEngine

// Local colors for this panel (same palette as MainActivity but file-private)
private val Panel = Color(0xFF111827)
private val Panel2 = Color(0xFF0F172A)
private val Stroke = Color(0xFF263244)
private val TextMain = Color(0xFFE5E7EB)
private val TextMuted = Color(0xFF94A3B8)
private val Accent = Color(0xFF7C3AED)
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

/**
 * CognitivePanel — UI for the human-brain-like reasoning engine.
 *
 * This panel lets the user enter a complex question and watch the system
 * orient, decompose, analogize, solve chunks, verify, and integrate.
 */

@Composable
fun CognitivePanel(
    engine: InferenceEngine,
    enabled: Boolean,
    maxTokens: Int,
    onStatus: (String) -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var query by remember { mutableStateOf("") }
    var isRunning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CognitiveResult?>(null) }
    var rawTrace by remember { mutableStateOf("") }

    val callModel: suspend (String, Int) -> String = { prompt, tokens ->
        val sb = StringBuilder()
        engine.sendUserPrompt(prompt, tokens).collect { token -> sb.append(token) }
        sb.toString()
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Stroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Cognitive Engine", color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Systematic, human-brain-like reasoning: orient, decompose, analogize, verify, integrate, and learn.", color = TextMuted)

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Enter a complex question or topic") },
                minLines = 3
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    enabled = enabled && query.isNotBlank() && !isRunning,
                    onClick = {
                        scope.launch {
                            isRunning = true
                            result = null
                            rawTrace = ""
                            onStatus("Cognitive engine reasoning...")
                            try {
                                val cognitiveEngine = CognitiveEngine(context, callModel)
                                val res = cognitiveEngine.reason(query)
                                result = res
                                rawTrace = res.trace.joinToString("\n")
                                onStatus("Cognitive reasoning complete. Confidence: ${"%.0f".format(res.confidence * 100)}%")
                            } catch (t: Throwable) {
                                AppLog.appendError("Cognitive engine failed", t)
                                onError(t.message ?: t.toString())
                                onStatus("Cognitive engine failed.")
                            } finally {
                                isRunning = false
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Think")
                }
                if (isRunning) CircularProgressIndicator(modifier = Modifier.height(24.dp), color = Accent, strokeWidth = 2.dp)
            }

            result?.let { res ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel2),
                    border = BorderStroke(1.dp, Stroke),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Final Answer", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(res.finalAnswer)) }) { Text("Copy") }
                        }
                        LatexAwareText(res.finalAnswer, color = TextMain)
                        Text("Confidence: ${"%.0f".format(res.confidence * 100)}%", color = TextMuted)
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF080B12)),
                    border = BorderStroke(1.dp, Stroke),
                    modifier = Modifier.fillMaxWidth().height(280.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Reasoning Trace", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(rawTrace)) }) { Text("Copy") }
                        }
                        Text(rawTrace, color = TextMuted)
                    }
                }
            }
        }
    }
}
