# AIUIBuilder — Full Handoff Document for Next Session

> Purpose: paste or upload this file into a fresh AI/agent session so the new assistant can continue the project without reading the entire old chat.
>
> Current date/context: This project is an Android Kotlin + Jetpack Compose app that runs local GGUF models through llama.cpp on Android. The user works from mobile only and builds APKs through GitHub Actions.

---

## 1. What this project is

**AIUIBuilder** is an Android app prototype for local/offline AI on Android using GGUF models. It currently supports:

1. **Local GGUF model loading** from Android storage.
2. **Chat mode** using llama.cpp Android wrapper.
3. **Builder mode** that generates JSON UI / HTML / React-style output.
4. **Recursive Refiner mode**:
   - iterative idea refinement loop
   - native grammar-constrained JSON generation
   - optional strict KV cache erasure
   - compatibility mode for Granite/MoE models
   - live raw JSON preview
   - rendered refinement view
   - timing diagnostics
   - thinking UI support
5. **Logs tab** for debugging and copying internal logs.
6. **Dark UI** with stable rotation handling.
7. **Basic LaTeX rendering** in chat/refiner outputs.

The app is being built entirely from mobile using GitHub Actions. The assistant provides:

```text
AIUIBuilder.zip
AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml
```

The user uploads `AIUIBuilder.zip` to the GitHub repo root and pastes `USE_THIS_SHORT_WORKFLOW.yml` into `.github/workflows/mobile-build.yml`.

---

## 2. Most important current workspace files

Current generated files in the workspace:

```text
/home/user/AIUIBuilder.zip
/home/user/AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml
/home/user/AIUIBuilder/MOBILE_BUILD_FROM_ZIP_REFINER.yml
/home/user/AIUIBuilder/HANDOFF_TO_NEXT_SESSION.md
```

The workflow files are intentionally short. The old long YAML workflows caused copy/paste escaping issues on mobile. The current safe workflow is only about 65 lines.

### Correct workflow file to use

Use:

```text
AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml
```

It should look like:

```yaml
name: AIUIBuilder Mobile Build

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 90

    steps:
      - name: Checkout repo
        uses: actions/checkout@v4

      - name: Unzip AIUIBuilder project
        shell: bash
        run: |
          test -f AIUIBuilder.zip || (echo "AIUIBuilder.zip not found in repo root" && exit 1)
          rm -rf app llamaLib external build-support build.gradle.kts settings.gradle.kts gradle.properties README.md .gitignore
          unzip -q AIUIBuilder.zip -d /tmp/project
          cp -R /tmp/project/AIUIBuilder/. .
          echo "Project files ready:"
          find . -maxdepth 3 -type f | sort | head -200

      - name: Clone llama.cpp Android runtime
        shell: bash
        run: |
          mkdir -p external
          git clone --depth 1 https://github.com/ggml-org/llama.cpp external/llama.cpp
          mkdir -p llamaLib/src/main/cpp llamaLib/src/main/java
          cp external/llama.cpp/examples/llama.android/lib/src/main/cpp/ai_chat.cpp llamaLib/src/main/cpp/ai_chat.cpp
          cp external/llama.cpp/examples/llama.android/lib/src/main/cpp/logging.h llamaLib/src/main/cpp/logging.h
          cp -R external/llama.cpp/examples/llama.android/lib/src/main/java/* llamaLib/src/main/java/

      - name: Patch llama.cpp for tuning and recursive refiner
        shell: bash
        run: python3 build-support/patch_llama_refiner.py

      - name: Set up Java 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android SDK, NDK, and CMake
        shell: bash
        run: sdkmanager "platforms;android-35" "build-tools;35.0.0" "ndk;29.0.13113456" "cmake;3.31.6"

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.9

      - name: Build debug APK
        shell: bash
        run: gradle assembleDebug --stacktrace

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: AIUIBuilder-Recursive-Refiner-GGUF-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

---

## 3. Expected GitHub/mobile build flow

The user has no PC and uses a phone/tablet.

### To build APK from mobile

1. Upload latest:

```text
AIUIBuilder.zip
```

to GitHub repo root.

2. Edit or create:

```text
.github/workflows/mobile-build.yml
```

3. Paste content from:

```text
AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml
```

4. Commit.

5. Go to:

```text
Actions → AIUIBuilder Mobile Build → Run workflow
```

6. Download artifact:

```text
AIUIBuilder-Recursive-Refiner-GGUF-debug-apk
```

7. Extract artifact ZIP and install `app-debug.apk`.

### Common GitHub issue

If the Actions tab shows the workflow path instead of the workflow name, or the Run button is missing, it usually means the YAML was pasted incorrectly or HTML-escaped. The current short workflow should avoid this. Avoid copying rendered old giant YAML that contains escaped symbols like:

```text
&amp;&amp;
&amp;lt;
&amp;gt;
```

GitHub needs real symbols:

```text
&&
<<
>
<
```

---

## 4. Current project tree inside ZIP

The ZIP contains roughly:

```text
AIUIBuilder/
├── .github/
│   └── workflows/
│       └── build-apk.yml                 # older/simple workflow, not usually used now
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/
│       │   ├── drawable/ic_launcher.xml
│       │   └── values/styles.xml
│       └── java/com/arena/aiuibuilder/
│           ├── MainActivity.kt
│           ├── AppLog.kt
│           ├── AppScopes.kt
│           ├── ErrorLogPanel.kt
│           ├── NativeRecursiveRefiner.kt
│           ├── RefinerCore.kt
│           ├── RefinerPanel.kt
│           ├── ThinkingUi.kt
│           ├── LatexText.kt
│           ├── SearchUi.kt
│           └── WebSearchClient.kt
├── build-support/
│   └── patch_llama_refiner.py            # critical native patch script
├── llamaLib/
│   ├── build.gradle.kts
│   ├── consumer-rules.pro
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── cpp/CMakeLists.txt
│       └── java/                         # populated from llama.cpp during build
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── README.md
├── USE_THIS_SHORT_WORKFLOW.yml
└── MOBILE_BUILD_FROM_ZIP_REFINER.yml
```

The `external/llama.cpp` source is **not inside the ZIP**. GitHub Actions clones it every build.

---

## 5. Major app modules and what they do

### `MainActivity.kt`

Main Jetpack Compose app. Contains:

- dark UI shell
- model picker/load flow
- chat tab
- builder tab
- refiner tab hook
- logs tab hook
- dynamic JSON UI rendering
- HTML preview via WebView
- chat message display with thinking block detection
- rotation-stable layout

Important behavior:

```kotlin
AppLog.install(applicationContext)
```

is called in `onCreate()` to install crash/error logging.

### `NativeRecursiveRefiner.kt`

JNI declarations for native refiner features:

```kotlin
object NativeRecursiveRefiner {
    external fun setStrictKvMode(strict: Boolean)
    external fun setThinkingMode(enabled: Boolean, maxThinkingTokens: Int)
    external fun beginSession(grounding: String): Int
    external fun refineOnce(...): String
    external fun getProgressChars(): Int
    external fun getProgressTokens(): Int
    external fun getProgressText(): String
    external fun getTimingSummary(): String
    external fun resetSession()
}
```

These are implemented by patching `ai_chat.cpp` in `build-support/patch_llama_refiner.py`.

### `RefinerCore.kt`

Kotlin controller for recursive refinement.

Responsibilities:

- controller-owned loop logic
- prompt building
- grounding reminder
- directive templating
- drift detection
- lens rotation
- JSON parse/validation
- sanitize `refined` so `next_focus` does not leak into it
- compact output caps

Current defaults:

```kotlin
MAX_TOKENS = 180
MIN_REFINED_CHARS = 30
MIN_NEXT_FOCUS_CHARS = 12
MAX_REFINED_CHARS = 420
MAX_NEXT_FOCUS_CHARS = 160
PREVIOUS_REFINED_CHAR_LIMIT = 420
DRIFT_THRESHOLD = 0.65f
DRIFT_WINDOW = 3
HISTORY_SIZE = 3
```

Current lenses:

```kotlin
val lenses = listOf(
    "structural improvement",
    "feasibility and practicality",
    "cost and resource analysis",
    "risk identification",
    "user experience and accessibility",
    "edge cases and failure modes",
    "opposite perspective — argue against the idea",
    "analogy — relate it to something completely different"
)
```

### `RefinerPanel.kt`

Compose UI for refiner.

Features:

- grounding text input
- max token / sampling settings
- strict KV switch
- Thinking pre-stage Off / Auto / Force
- start session
- run once
- auto loop
- stop
- reset
- progress line
- live raw JSON output
- rendered output toggle
- copy JSON
- copy rendered
- iteration cards

Important: native operations run on a dedicated single-thread dispatcher:

```kotlin
private val RefinerNativeDispatcher = Executors.newSingleThreadExecutor { ... }.asCoroutineDispatcher()
```

This prevents main-thread ANR and serializes llama.cpp native state access.

### `ThinkingUi.kt`

UI support for `<think>...</think>` blocks.

Features:

- detects thinking tags
- animated metallic/glare `Thinking` text
- tap to expand reasoning
- copy reasoning
- hides thinking text from normal visible output so it is not duplicated

Used in:

- chat messages
- refiner live output

### `LatexText.kt`

Stable lightweight LaTeX renderer.

Detects:

```text
$...$
$$...$$
\(...\)
\[...\]
```

Beautifies common LaTeX into Unicode:

```text
\alpha → α
\beta → β
\lambda → λ
\Delta → Δ
\times → ×
\leq → ≤
\geq → ≥
\approx → ≈
\infty → ∞
\frac{a}{b} → (a)⁄(b)
x^{2} → x²
x_i → xᵢ
```

This is not full KaTeX/MathJax. It is intentionally stable and dependency-light.

### `AppLog.kt`

Internal logging and uncaught exception logging.

Log file path:

```text
context.filesDir/aiuibuilder_error_log.txt
```

### `ErrorLogPanel.kt`

Logs tab UI.

Features:

- refresh
- copy
- clear
- displays app internal log

If native hard-crashes occur, it may only capture last breadcrumb before crash, not native stack trace.

### `AppScopes.kt`

App-level coroutine scope. Created because using `rememberCoroutineScope()` caused:

```text
Coroutine scope left the composition
```

during long llama.cpp native calls.

---

## 6. Native llama.cpp patch script

### Critical file

```text
AIUIBuilder/build-support/patch_llama_refiner.py
```

This script runs during GitHub Actions after cloning llama.cpp and copying Android example files.

It patches:

```text
llamaLib/src/main/cpp/ai_chat.cpp
llamaLib/src/main/cpp/logging.h
llamaLib/src/main/java/com/arm/aichat/internal/InferenceEngineImpl.kt
```

### What it adds/fixes

1. Android API 26 logging fix:

```cpp
return __android_log_is_loggable(...)
```

replaced with:

```cpp
return prio >= LOG_MIN_LEVEL;
```

2. Better model load error instead of always `UnsupportedArchitectureException`.

3. Native runtime tuning:

```cpp
static int g_n_threads = 4;
static int g_context_size = 2048;
static int g_batch_size = 256;
static float g_sampler_temp = 0.25f;
```

and JNI:

```cpp
Java_com_arena_aiuibuilder_NativeTuning_setOptions(...)
```

4. Strict Recursive Refiner JNI bridge:

```cpp
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_setStrictKvMode(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_setThinkingMode(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_beginSession(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_refineOnce(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getProgressChars(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getProgressTokens(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getProgressText(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getTimingSummary(...)
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_resetSession(...)
```

### Strict refiner native behavior

Native state:

```cpp
static llama_pos rr_grounding_end = 0;
static llama_pos rr_current_position = 0;
static bool rr_started = false;
static bool rr_strict_kv_mode = false;
static bool rr_thinking_enabled = false;
static int rr_max_thinking_tokens = 96;
static llama_tokens rr_grounding_tokens;
static std::atomic<int> rr_progress_chars{0};
static std::atomic<int> rr_progress_tokens{0};
static std::mutex rr_progress_mutex;
static std::string rr_progress_text;
static std::atomic<long long> rr_ground_ms{0};
static std::atomic<long long> rr_prompt_ms{0};
static std::atomic<long long> rr_generation_ms{0};
```

Schema:

```json
{
  "type": "object",
  "properties": {
    "refined": { "type": "string", "minLength": 30, "maxLength": 420 },
    "next_focus": { "type": "string", "minLength": 12, "maxLength": 160 }
  },
  "required": ["refined", "next_focus"],
  "additionalProperties": false
}
```

The schema is compiled to GBNF with:

```cpp
json_schema_to_grammar(nlohmann::ordered_json::parse(RR_JSON_SCHEMA))
```

Then used in the sampler:

```cpp
sparams.grammar = common_grammar(COMMON_GRAMMAR_TYPE_USER, grammar_str);
common_sampler_sample(sampler, g_context, -1, true);
```

`grammar_first=true` is used so invalid JSON tokens are filtered before normal sampling.

### Strict KV vs compatibility mode

#### `strictKvCache=true`

Uses real memory/KV erasure:

```cpp
llama_memory_seq_rm(llama_get_memory(g_context), 0, rr_grounding_end, -1)
rr_current_position = rr_grounding_end
```

This is fastest and closest to the original architecture but can crash on Granite/MoE/hybrid models.

#### `strictKvCache=false`

Compatibility mode. Used for Granite MoE.

Behavior:

```cpp
llama_memory_clear(...)
rr_current_position = 0
rr_decode_tokens(rr_grounding_tokens, false)
rr_grounding_end = rr_current_position
```

This re-evaluates grounding every iteration. It is slower but stable for Granite/MoE.

### Thinking pre-stage

If enabled, before strict JSON generation:

```text
free-generate up to N thinking tokens without grammar
then generate final JSON with grammar
```

UI shows thinking output if `<think>...</think>` exists.

Modes in Kotlin UI:

```text
Off   → no thinking stage, fastest
Auto  → free thinking up to 64 tokens
Force → stronger prompt, free thinking up to 128 tokens
```

---

## 7. Strict requirements from earlier discussion

The recursive refiner was designed around these requirements:

1. Grammar-constrained decoding must use native llama.cpp GBNF sampling.
2. Strict KV cache mode must use llama memory/KV sequence erasure, not fake prompt rebuilding.
3. Grounding must be evaluated once and cached permanently in strict mode.
4. Grammar off during instruction evaluation, on during JSON generation.
5. JSON schema flat with exactly two fields:

```json
{ "refined": "...", "next_focus": "..." }
```

6. Directive templating happens in controller, not model.
7. Drift detection uses word overlap, not embeddings.
8. Max tokens per JSON generation should be small, currently default `180`.
9. Early JSON completion detection stops generation when top-level `}` closes.
10. Controller owns the loop; model only generates one JSON per call.
11. Lens rotation uses 8 predefined lenses.
12. GGUF compatibility: no hardcoded model token IDs; use llama.cpp vocab/EOS APIs.

Practical exception:

- For Granite MoE/hybrid, strict KV erase may be unstable. Compatibility mode intentionally re-evaluates grounding while preserving native grammar JSON.

---

## 8. Current known behavior from testing

### Stable behavior achieved

The user successfully ran Granite 4.0 MoE and got stable recursive iterations with:

```text
Strict KV cache erasure = OFF
Thinking pre-stage = OFF
```

Logs showed multiple iterations completing and JSON parsing OK.

### Speed issue

Granite MoE normal chat can be ~10 tok/s in other apps, but strict refiner is slower due to:

1. grammar-constrained decoding overhead
2. prompt prefill overhead
3. compatibility mode re-evaluating grounding every iteration
4. Granite MoE/hybrid behavior in llama.cpp Android
5. prompt size around 1500–1800 chars

Timing diagnostics now exist via:

```text
ground=...ms prompt=...ms gen=...ms ... tok/s
```

### Drift issue

The model sometimes drifts away from the original grounding after several iterations. Mitigations currently added:

- cached grounding wrapper
- explicit original grounding reminder in each prompt
- compact previous refinement cap
- drift detection and lens rotation

Potential future improvement:

- grounding relevance scoring
- force every output to include one phrase/key concept from grounding
- add a `grounding_keywords` controller extraction step

But schema must remain two fields.

### next_focus leakage

Sometimes model puts next-focus text inside `refined`. Mitigations:

- prompt says not to put next_focus inside refined
- Kotlin sanitizer removes leaked patterns like `next_focus:` from refined

### Chat thinking duplication

Fixed: `<think>...</think>` should appear only in Thinking block, not duplicate outside.

---

## 9. User’s current requests / likely next tasks

The user wants to continue improving the app. Important requested themes:

1. Keep stability first.
2. Improve live UI:
   - live JSON should persist, not vanish
   - permanent copy buttons for live JSON and rendered output
   - thinking block with animated metallic/glare text
3. Add better speed diagnostics.
4. Add thinking-model compatibility:
   - Thinking Off / Auto / Force
   - free thinking first, then grammar JSON
5. Add LaTeX rendering.
6. Eventually speed optimization:
   - shorten prompts
   - maybe handcrafted GBNF instead of JSON schema conversion
   - maybe strict KV for dense models only
   - maybe benchmark mode
7. Consider forcing thinking in normal chat with toggle, but not default.

---

## 10. Current exact user workflow expectation for future assistant

When modifying the app, the assistant should:

1. Edit files in `/home/user/AIUIBuilder/`.
2. Recreate `AIUIBuilder.zip` after changes:

```bash
cd /home/user
rm -f AIUIBuilder.zip
zip -r AIUIBuilder.zip AIUIBuilder \
  -x 'AIUIBuilder/MOBILE_ONLY_BUILD_WORKFLOW*.yml' \
     'AIUIBuilder/MOBILE_WORKFLOW_PATCH_STEP.txt' \
     'AIUIBuilder/FIX_LOGGING_PATCH.txt'
```

3. Keep `AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml` short and valid.
4. Tell the user to upload only:

```text
AIUIBuilder.zip
```

and paste:

```text
AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml
```

into GitHub.

Do not give giant embedded-base64 YAML again. It caused mobile copy/paste and parsing failures.

---

## 11. Notes for new AI/agent session

If you are the new assistant continuing this project:

- Do not ask the user to manually create all Android folders.
- Use the workspace and edit the existing project.
- Preserve the mobile workflow approach.
- Preserve stability: do not turn strict KV on by default for Granite/MoE.
- Keep `strictKvCache=false` default for Granite compatibility.
- If changing native C++, prefer modifying `build-support/patch_llama_refiner.py`, because GitHub Actions clones fresh llama.cpp every build.
- If adding native JNI functions, add declarations in `NativeRecursiveRefiner.kt` or relevant Kotlin bridge.
- If adding app UI, prefer small Compose components in separate files rather than making `MainActivity.kt` even larger.
- Always regenerate `AIUIBuilder.zip`.
- If user reports crashes, check Logs tab output first.

---

## 12. Recent state summary

Latest generated files as of this handoff:

```text
AIUIBuilder.zip                                  # latest project zip
AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml          # current short GitHub Actions workflow
AIUIBuilder/MOBILE_BUILD_FROM_ZIP_REFINER.yml    # same/similar workflow
AIUIBuilder/HANDOFF_TO_NEXT_SESSION.md           # this file
```

Latest implemented features:

- stable app-level coroutine scope
- refiner compatibility mode
- strict KV switch
- thinking Off/Auto/Force
- live JSON preview with progress text
- progress char/token/tok/s
- native timing summary
- persistent copy buttons
- logs tab
- chat thinking block
- LaTeX formula cards
- dark Material3 theme fixes for text visibility

Known safe test configuration for Granite MoE:

```text
Strict KV cache erasure: OFF
Thinking pre-stage: OFF
Max tokens: 180
```

Use thinking Auto/Force only after confirming base refiner stability.

---

## 13. Suggested opening prompt for next session

The user can start a fresh chat with:

```text
I am continuing my AIUIBuilder Android project. Please read HANDOFF_TO_NEXT_SESSION.md in the workspace. The app is a Kotlin Jetpack Compose Android app that runs local GGUF models through llama.cpp. I build from mobile using AIUIBuilder.zip + USE_THIS_SHORT_WORKFLOW.yml on GitHub Actions. Continue from the current state, preserve stability, and regenerate AIUIBuilder.zip after changes.
```

Then attach/upload:

```text
AIUIBuilder.zip
AIUIBuilder/HANDOFF_TO_NEXT_SESSION.md
```

or make sure the new workspace has them.
