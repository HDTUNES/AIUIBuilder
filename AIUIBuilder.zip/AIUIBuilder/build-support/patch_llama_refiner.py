from pathlib import Path
import re

CPP = r'''

// -----------------------------------------------------------------------------
// Strict Recursive Refiner JNI bridge
// Requirements:
// - grounding evaluated once and kept in llama.cpp memory/KV cache
// - each iteration removes positions [grounding_end, inf) via llama_memory_seq_rm
// - grammar OFF while evaluating instruction/directive prompt
// - fresh native GBNF grammar sampler ON during JSON generation
// - flat two-field JSON schema only: refined, next_focus
// -----------------------------------------------------------------------------

static llama_pos rr_grounding_end = 0;
static llama_pos rr_current_position = 0;
static bool rr_started = false;
static bool rr_strict_kv_mode = false;
static bool rr_thinking_enabled = false;
static int rr_max_thinking_tokens = 96;
static llama_tokens rr_grounding_tokens;
static std::atomic<int> rr_progress_chars{0};
static std::atomic<int> rr_progress_tokens{0};
static std::mutex rr_progress_mutex;
static std::string rr_progress_text;
static std::atomic<long long> rr_ground_ms{0};
static std::atomic<long long> rr_prompt_ms{0};
static std::atomic<long long> rr_generation_ms{0};

static const char * RR_JSON_SCHEMA = R"JSON({
  "type": "object",
  "properties": {
    "refined": { "type": "string", "minLength": 30, "maxLength": 420 },
    "next_focus": { "type": "string", "minLength": 12, "maxLength": 160 },
    "supports": { "type": "string", "maxLength": 8 },
    "contradicts": { "type": "string", "maxLength": 8 },
    "close_q": { "type": "string", "maxLength": 120 },
    "open_q": { "type": "string", "maxLength": 120 }
  },
  "required": ["refined", "next_focus"],
  "additionalProperties": false
})JSON";

static bool rr_json_complete(const std::string & text) {
    int depth = 0;
    bool in_string = false;
    bool escape_next = false;
    bool seen_object = false;

    for (char ch : text) {
        if (escape_next) {
            escape_next = false;
            continue;
        }
        if (ch == '\\' && in_string) {
            escape_next = true;
            continue;
        }
        if (ch == '"') {
            in_string = !in_string;
            continue;
        }
        if (in_string) continue;
        if (ch == '{') {
            depth++;
            seen_object = true;
        } else if (ch == '}') {
            depth--;
            if (seen_object && depth == 0) return true;
        }
    }
    return false;
}

static int rr_decode_tokens(const llama_tokens & tokens, bool compute_last_logit) {
    if (!g_context || tokens.empty()) return 0;
    const int n_ctx = (int) llama_n_ctx(g_context);
    int batch_cap = g_batch_size;
    if (batch_cap <= 0) batch_cap = 256;

    for (int i = 0; i < (int) tokens.size(); i += batch_cap) {
        const int cur = std::min((int) tokens.size() - i, batch_cap);
        if (rr_current_position + cur >= n_ctx - 4) {
            LOGe("rr_decode_tokens: context overflow: pos=%d cur=%d n_ctx=%d", (int) rr_current_position, cur, n_ctx);
            return 2;
        }
        common_batch_clear(g_batch);
        for (int j = 0; j < cur; ++j) {
            const bool want_logit = compute_last_logit && (i + j == (int) tokens.size() - 1);
            common_batch_add(g_batch, tokens[i + j], rr_current_position + j, {0}, want_logit);
        }
        if (llama_decode(g_context, g_batch) != 0) {
            LOGe("rr_decode_tokens: llama_decode failed");
            return 1;
        }
        rr_current_position += cur;
    }
    return 0;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_setStrictKvMode(JNIEnv *, jclass, jboolean strict) {
    rr_strict_kv_mode = (strict == JNI_TRUE);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_setThinkingMode(JNIEnv *, jclass, jboolean enabled, jint max_tokens) {
    rr_thinking_enabled = (enabled == JNI_TRUE);
    int mt = (int) max_tokens;
    if (mt < 0) mt = 0;
    if (mt > 512) mt = 512;
    rr_max_thinking_tokens = mt;
}


extern "C"
JNIEXPORT jint JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getProgressChars(JNIEnv *, jclass) {
    return rr_progress_chars.load();
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getProgressTokens(JNIEnv *, jclass) {
    return rr_progress_tokens.load();
}

static jstring rr_new_utf8_string(JNIEnv * env, const std::string & output) {
    jbyteArray bytes = env->NewByteArray((jsize) output.size());
    env->SetByteArrayRegion(bytes, 0, (jsize) output.size(), reinterpret_cast<const jbyte *>(output.data()));
    jclass string_cls = env->FindClass("java/lang/String");
    jmethodID ctor = env->GetMethodID(string_cls, "<init>", "([BLjava/lang/String;)V");
    jstring utf8 = env->NewStringUTF("UTF-8");
    return (jstring) env->NewObject(string_cls, ctor, bytes, utf8);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getProgressText(JNIEnv * env, jclass) {
    std::lock_guard<std::mutex> lock(rr_progress_mutex);
    return rr_new_utf8_string(env, rr_progress_text);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_getTimingSummary(JNIEnv * env, jclass) {
    char buf[192];
    const long long gen = rr_generation_ms.load();
    const int toks = rr_progress_tokens.load();
    const double tps = gen > 0 ? (1000.0 * toks / (double) gen) : 0.0;
    snprintf(buf, sizeof(buf), "ground=%lldms prompt=%lldms gen=%lldms %.2f tok/s",
             rr_ground_ms.load(), rr_prompt_ms.load(), gen, tps);
    return env->NewStringUTF(buf);
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_beginSession(JNIEnv * env, jclass, jstring jgrounding) {
    if (!g_model || !g_context) {
        env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "Model/context is not loaded");
        return 1;
    }

    const char * grounding_chars = env->GetStringUTFChars(jgrounding, nullptr);
    std::string grounding(grounding_chars ? grounding_chars : "");
    env->ReleaseStringUTFChars(jgrounding, grounding_chars);

    if (grounding.empty()) {
        env->ThrowNew(env->FindClass("java/lang/IllegalArgumentException"), "Grounding cannot be empty");
        return 2;
    }

    // Full clear only at session start. Requirement: grounding is evaluated once after this.
    llama_memory_clear(llama_get_memory(g_context), false);
    rr_grounding_end = 0;
    rr_current_position = 0;
    rr_started = false;

    // Grounding input evaluation: grammar OFF.
    rr_grounding_tokens = common_tokenize(g_context, grounding, true, true);
    int rc = rr_decode_tokens(rr_grounding_tokens, false);
    if (rc != 0) {
        env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "Failed to evaluate grounding");
        return rc;
    }

    rr_grounding_end = rr_current_position;
    rr_started = true;
    LOGi("Recursive refiner grounding cached through position %d", (int) rr_grounding_end);
    return 0;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_refineOnce(
    JNIEnv * env,
    jclass,
    jstring jprompt,
    jint jmax_tokens,
    jfloat jtemperature,
    jint jtop_k,
    jfloat jtop_p,
    jfloat jmin_p,
    jfloat jrepeat_penalty
) {
    if (!rr_started || !g_model || !g_context) {
        env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "Recursive refiner session not started");
        return env->NewStringUTF("");
    }

    const char * prompt_chars = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(prompt_chars ? prompt_chars : "");
    env->ReleaseStringUTFChars(jprompt, prompt_chars);

    const int max_tokens = std::max(1, (int) jmax_tokens);
    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    rr_progress_chars.store(0);
    rr_progress_tokens.store(0);
    rr_ground_ms.store(0);
    rr_prompt_ms.store(0);
    rr_generation_ms.store(0);
    { std::lock_guard<std::mutex> lock(rr_progress_mutex); rr_progress_text.clear(); }

    const int64_t t_ground_start = ggml_time_us();
    if (rr_strict_kv_mode) {
        // Strict KV cache erasure: remove only tokens after grounding boundary.
        // Current llama.cpp API equivalent of llama_kv_cache_seq_rm(ctx, 0, grounding_end, -1).
        if (!llama_memory_seq_rm(llama_get_memory(g_context), 0, rr_grounding_end, -1)) {
            env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "llama_memory_seq_rm failed");
            return env->NewStringUTF("");
        }
        rr_current_position = rr_grounding_end; // strict position reset after cache erase
    } else {
        // Compatibility mode for hybrid/MoE/recurrent models where partial cache removal can be unstable.
        // Grammar-constrained decoding remains native/strict, but grounding is re-evaluated for safety.
        llama_memory_clear(llama_get_memory(g_context), false);
        rr_current_position = 0;
        int grc = rr_decode_tokens(rr_grounding_tokens, false);
        if (grc != 0) {
            env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "Failed to re-evaluate grounding in compatibility mode");
            return env->NewStringUTF("");
        }
        rr_grounding_end = rr_current_position;
    }
    rr_ground_ms.store((ggml_time_us() - t_ground_start) / 1000);

    // Instruction/directive evaluation: grammar OFF.
    const int64_t t_prompt_start = ggml_time_us();
    llama_tokens prompt_tokens = common_tokenize(g_context, prompt, false, true);
    int rc = rr_decode_tokens(prompt_tokens, true);
    if (rc != 0) {
        env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "Failed to evaluate recursive prompt");
        return env->NewStringUTF("");
    }
    rr_prompt_ms.store((ggml_time_us() - t_prompt_start) / 1000);

    // Optional free thinking stage. This is deliberately separate from strict JSON generation.
    std::string thinking_output;
    if (rr_thinking_enabled && rr_max_thinking_tokens > 0) {
        common_params_sampling think_params;
        think_params.temp = (float) jtemperature;
        think_params.top_k = (int32_t) jtop_k;
        think_params.top_p = (float) jtop_p;
        think_params.min_p = (float) jmin_p;
        think_params.penalty_repeat = (float) jrepeat_penalty;
        common_sampler * think_sampler = common_sampler_init(g_model, think_params);
        for (int ti = 0; ti < rr_max_thinking_tokens; ++ti) {
            llama_token token = common_sampler_sample(think_sampler, g_context, -1, false);
            common_sampler_accept(think_sampler, token, true);
            if (llama_vocab_is_eog(vocab, token)) break;
            thinking_output += common_token_to_piece(g_context, token);
            { std::lock_guard<std::mutex> lock(rr_progress_mutex); rr_progress_text = thinking_output; }
            common_batch_clear(g_batch);
            common_batch_add(g_batch, token, rr_current_position, {0}, true);
            if (llama_decode(g_context, g_batch) != 0) break;
            rr_current_position++;
            if (thinking_output.find("</think>") != std::string::npos) break;
        }
        common_sampler_free(think_sampler);
    }

    // Compile JSON schema -> GBNF grammar fresh per generation.
    std::string grammar_str;
    try {
        grammar_str = json_schema_to_grammar(nlohmann::ordered_json::parse(RR_JSON_SCHEMA));
    } catch (...) {
        env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "Failed to compile JSON schema to GBNF grammar");
        return env->NewStringUTF("");
    }

    common_params_sampling sparams;
    sparams.temp = (float) jtemperature;
    sparams.top_k = (int32_t) jtop_k;
    sparams.top_p = (float) jtop_p;
    sparams.min_p = (float) jmin_p;
    sparams.penalty_repeat = (float) jrepeat_penalty;
    sparams.grammar = common_grammar(COMMON_GRAMMAR_TYPE_USER, grammar_str);

    common_sampler * sampler = nullptr;
    try {
        sampler = common_sampler_init(g_model, sparams);
    } catch (...) {
        env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "Failed to initialize grammar sampler");
        return env->NewStringUTF("");
    }

    std::string output;
    const int64_t t_generation_start = ggml_time_us();

    for (int i = 0; i < max_tokens; ++i) {
        // grammar_first=true: invalid JSON tokens are removed before normal sampling.
        llama_token token = common_sampler_sample(sampler, g_context, -1, true);
        common_sampler_accept(sampler, token, true);

        if (llama_vocab_is_eog(vocab, token)) {
            break;
        }

        output += common_token_to_piece(g_context, token);
        rr_progress_chars.store((int) output.size());
        rr_progress_tokens.store(i + 1);
        { std::lock_guard<std::mutex> lock(rr_progress_mutex); rr_progress_text = thinking_output + output; }
        rr_generation_ms.store((ggml_time_us() - t_generation_start) / 1000);

        common_batch_clear(g_batch);
        common_batch_add(g_batch, token, rr_current_position, {0}, true);
        if (llama_decode(g_context, g_batch) != 0) {
            common_sampler_free(sampler);
            env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), "llama_decode failed during recursive JSON generation");
            return env->NewStringUTF("");
        }
        rr_current_position++;

        if (rr_json_complete(output)) {
            break;
        }
    }

    rr_generation_ms.store((ggml_time_us() - t_generation_start) / 1000);
    common_sampler_free(sampler); // fresh grammar sampler per generation, then free
    return rr_new_utf8_string(env, output);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_arena_aiuibuilder_NativeRecursiveRefiner_resetSession(JNIEnv *, jclass) {
    rr_started = false;
    rr_grounding_end = 0;
    rr_current_position = 0;
    if (g_context) {
        llama_memory_clear(llama_get_memory(g_context), false);
    }
}
'''

def main():
    cpp_path = Path('llamaLib/src/main/cpp/ai_chat.cpp')
    log_path = Path('llamaLib/src/main/cpp/logging.h')
    impl_path = Path('llamaLib/src/main/java/com/arm/aichat/internal/InferenceEngineImpl.kt')
    arch_path = Path('external/llama.cpp/src/llama-arch.cpp')

    # Android API 26 logging compatibility.
    if log_path.exists():
        s = log_path.read_text()
        s = s.replace('return __android_log_is_loggable(prio, LOG_TAG, LOG_MIN_LEVEL);', 'return prio >= LOG_MIN_LEVEL;')
        log_path.write_text(s)

    # Better error message.
    if impl_path.exists():
        s = impl_path.read_text()
        s = s.replace(
            'if (it != 0) throw UnsupportedArchitectureException()',
            'if (it != 0) throw IOException("Model load failed. Try a smaller Q4 or Q5 GGUF. Possible causes: unsupported architecture, corrupt or split GGUF, or not enough RAM.")'
        )
        s = s.replace(
            'if (it != 0) throw IOException("Failed to prepare resources")',
            'if (it != 0) throw IOException("Failed to prepare resources (not enough RAM or context size too large).")'
        )
        impl_path.write_text(s)

    # Universal architecture alias normalization and fallback mapping.
    if arch_path.exists():
        s_arch = arch_path.read_text()
        marker = 'return LLM_ARCH_UNKNOWN;'
        func_start = 'llm_arch llm_arch_from_string('
        if func_start in s_arch and marker in s_arch:
            idx = s_arch.find(func_start)
            idx_end = s_arch.find(marker, idx)
            idx_brace = s_arch.find('}', idx_end)
            alias_code = '''
    std::string n = name;
    for (auto & c : n) c = std::tolower((unsigned char)c);
    if (n == "smollm" || n == "smollm2") return LLM_ARCH_LLAMA;
    if (n == "smollm3") return LLM_ARCH_SMOLLM3;
    if (n.find("hrm") != std::string::npos) return LLM_ARCH_LLAMA;
    if (n == "falcon-h1" || n == "falcon_h1") return LLM_ARCH_FALCON_H1;
    if (n.find("falcon") != std::string::npos) return LLM_ARCH_FALCON;
    if (n.find("qwen2") != std::string::npos) return LLM_ARCH_QWEN2;
    if (n.find("qwen3") != std::string::npos) return LLM_ARCH_QWEN3;
    if (n.find("gemma2") != std::string::npos) return LLM_ARCH_GEMMA2;
    if (n.find("gemma3") != std::string::npos) return LLM_ARCH_GEMMA3;
    if (n.find("gemma") != std::string::npos) return LLM_ARCH_GEMMA;
    if (n.find("phi3") != std::string::npos) return LLM_ARCH_PHI3;
    if (n.find("phi") != std::string::npos) return LLM_ARCH_PHI2;
    if (n.find("mistral") != std::string::npos) return LLM_ARCH_MISTRAL3;
    if (n.find("deepseek") != std::string::npos) return LLM_ARCH_DEEPSEEK2;
    if (n.find("llama") != std::string::npos) return LLM_ARCH_LLAMA;
    return LLM_ARCH_LLAMA;'''
            s_arch = s_arch[:idx_end] + alias_code + "\n" + s_arch[idx_brace:]
            arch_path.write_text(s_arch)

    if not cpp_path.exists():
        return

    s = cpp_path.read_text()

    # Ensure headers for JSON schema -> GBNF conversion.
    if '#include "json-schema-to-grammar.h"' not in s:
        s = s.replace('#include "llama.h"', '#include "llama.h"\n#include "json-schema-to-grammar.h"\n#include <nlohmann/json.hpp>\n#include <atomic>\n#include <mutex>', 1)

    # Robust tuning patch.
    s = re.sub(r'^\s*constexpr\s+int\s+N_THREADS_MIN\s*=\s*[^;]+;\s*\n', '', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+int\s+N_THREADS_MAX\s*=\s*[^;]+;\s*\n', '', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+int\s+N_THREADS_HEADROOM\s*=\s*[^;]+;\s*\n', '', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+int\s+DEFAULT_CONTEXT_SIZE\s*=\s*[^;]+;', 'static int g_context_size = 2048;', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+int\s+BATCH_SIZE\s*=\s*[^;]+;', 'static int g_batch_size = 256;', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+float\s+DEFAULT_SAMPLER_TEMP\s*=\s*[^;]+;', 'static float g_sampler_temp = 0.25f;', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+int\s+g_context_size\s*=\s*[^;]+;', 'static int g_context_size = 2048;', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+int\s+g_batch_size\s*=\s*[^;]+;', 'static int g_batch_size = 256;', s, flags=re.M)
    s = re.sub(r'^\s*constexpr\s+float\s+g_sampler_temp\s*=\s*[^;]+;', 'static float g_sampler_temp = 0.25f;', s, flags=re.M)

    if 'static int g_n_threads' not in s:
        marker = 'static int g_context_size = 2048;'
        if marker in s:
            s = s.replace(marker, 'static int g_n_threads = 4;\n' + marker, 1)
        else:
            s = 'static int g_n_threads = 4;\nstatic int g_context_size = 2048;\nstatic int g_batch_size = 256;\nstatic float g_sampler_temp = 0.25f;\n' + s

    s = re.sub(
        r'const\s+int\s+n_threads\s*=\s*std::max\([^;]+?N_THREADS_HEADROOM\s*\)\s*\)\s*;',
        'const int n_threads = g_n_threads;',
        s,
        flags=re.S
    )
    s = s.replace('DEFAULT_CONTEXT_SIZE', 'g_context_size')
    s = s.replace('BATCH_SIZE', 'g_batch_size')
    s = s.replace('DEFAULT_SAMPLER_TEMP', 'g_sampler_temp')

    target_load = 'auto *model = llama_model_load_from_file(model_path, model_params);'
    repl_load = 'struct llama_model *model = nullptr; try { model = llama_model_load_from_file(model_path, model_params); } catch (...) { env->ReleaseStringUTFChars(jmodel_path, model_path); return 1; }'
    s = s.replace(target_load, repl_load)

    target_prep = 'auto *context = init_context(g_model);'
    repl_prep = 'struct llama_context *context = nullptr; try { context = init_context(g_model); } catch (...) { return 1; }'
    s = s.replace(target_prep, repl_prep)

    if 'Java_com_arena_aiuibuilder_NativeTuning_setOptions' not in s:
        s += r'''

extern "C"
JNIEXPORT void JNICALL
Java_com_arena_aiuibuilder_NativeTuning_setOptions(JNIEnv *, jclass, jint threads, jint contextSize, jint batchSize, jfloat temperature) {
    int t = (int) threads;
    int c = (int) contextSize;
    int b = (int) batchSize;
    float temp = (float) temperature;
    if (t < 1) t = 1;
    if (t > 8) t = 8;
    if (c < 512) c = 512;
    if (c > 8192) c = 8192;
    if (b < 64) b = 64;
    if (b > 1024) b = 1024;
    if (temp < 0.01f) temp = 0.01f;
    if (temp > 2.0f) temp = 2.0f;
    g_n_threads = t;
    g_context_size = c;
    g_batch_size = b;
    g_sampler_temp = temp;
}
'''

    if 'Java_com_arena_aiuibuilder_NativeRecursiveRefiner_refineOnce' not in s:
        s += CPP

    required = [
        'static int g_n_threads',
        'static int g_context_size',
        'static int g_batch_size',
        'static float g_sampler_temp',
        'NativeTuning_setOptions',
        'NativeRecursiveRefiner_refineOnce',
        'NativeRecursiveRefiner_setStrictKvMode',
        'NativeRecursiveRefiner_getProgressChars',
        'NativeRecursiveRefiner_getProgressTokens',
        'NativeRecursiveRefiner_getProgressText',
        'NativeRecursiveRefiner_getTimingSummary',
        'NativeRecursiveRefiner_setThinkingMode',
        'llama_memory_seq_rm',
        'json_schema_to_grammar',
    ]
    missing = [x for x in required if x not in s]
    if missing:
        raise RuntimeError('patch failed, missing: ' + ', '.join(missing))

    cpp_path.write_text(s)
    print('Patched llama.cpp Android runtime for tuning + strict recursive refiner + universal architectures')

if __name__ == '__main__':
    main()
