# AIUIBuilder — Handoff to Next Session

> **Current phase:** MESA v2 Cognitive Engine + brain-like memory architecture.  
> **Date:** 2026-06-26  
> **Purpose:** This document lets a new AI/assistant continue the project without re-reading the full chat history.  
> **User context:** Builds entirely from a mobile phone/tablet via GitHub Actions. No PC.

---

## 1. What this app is

**AIUIBuilder** is an Android Kotlin + Jetpack Compose app that runs local GGUF models through **llama.cpp** on Android. It is a **self-evolving cognitive harness** wrapped around any frozen GGUF model. The model weights are never changed; all evolution happens in the Kotlin architecture (memory, evaluators, prompts, operators).

### Core modes

| Mode | What it does |
|---|---|
| **Chat** | Normal local LLM chat with optional web grounding. |
| **Builder** | Generates JSON UI, HTML, or React-style code from a prompt. |
| **Cognitive** | NEW. Human-brain-like reasoning engine: orient, decompose, analogize, solve chunks, verify, execute code, integrate, reflect. |
| **Refiner** | Recursive MAP-Elites idea refinement with grammar-constrained JSON output. |
| **Logs** | Internal structured log viewer. |
| **Tests** | LaTeX/math rendering validation suite. |

---

## 2. How the cognitive architecture works (the current phase)

The user wants a **true self-evolving AI** that mimics human cognition. The current architecture implements this without touching model weights:

```text
User question
    ↓
CognitiveEngine (Kotlin)
    ↓
Working Memory (max 5 items / ~800 chars)
    ↓
LLM call (small prompt ~500–1000 tokens)
    ↓
OperatorResult (JSON or structured text)
    ↓
Update SemanticMemory / EpisodicMemory / ExternalMemory
    ↓
MetacognitiveMonitor decides next operator
    ↓
Repeat
```

### Memory systems

- **SemanticMemory** — long-term belief graph with nodes/edges.
- **EpisodicMemory** — recent reasoning traces.
- **ProceduralMemory** — reusable skills / mini-strategies.
- **MetaMemory** — confidence map and knowledge-gap detection.
- **WorkingMemory** — tiny active window (max 5 items).
- **ExternalMemory** — disk notes (the notebook).

### Forgetting & reinforcement

- Forgetting is **interference-based**, not time-based. Every new memory weakens old ones.
- Memories are archived when activation drops below threshold.
- Repeated retrieval/use strengthens a memory (`touchCount`, `importance`, `confidence`).
- High-value insights are written to disk when working memory is near capacity.

### Operators

`ORIENT`, `DECOMPOSE`, `FIRST_PRINCIPLES`, `ANALOGIZE`, `SOLVE_CHUNK`, `VERIFY`, `EXECUTE`, `INTEGRATE`, `REFLECT`, `SAVE_NOTE`, `RETRIEVE_NOTE`.

Each operator is a small Kotlin function that builds a tight prompt, calls the LLM once, and parses the result.

---

## 3. Project structure

```text
AIUIBuilder/
├── .github/workflows/build-apk.yml
├── .gitignore
├── ACT_R_COGNITIVE_OS_SPEC.md
├── ARCHITECTURE_HumanBrainMimicry.md
├── ARCHITECTURE_WorkingMemory_Forgetting.md
├── HANDOFF_TO_NEXT_SESSION.md          # this file
├── README.md
├── RESEARCH_BrainInspired_Advancements.md
├── USE_THIS_SHORT_WORKFLOW.yml         # build workflow
├── MOBILE_BUILD_FROM_ZIP*.yml
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/...
│       └── java/com/arena/aiuibuilder/
│           ├── MainActivity.kt
│           ├── AppLog.kt
│           ├── AppScopes.kt
│           ├── CognitiveEngine.kt          # NEW core orchestrator
│           ├── CognitiveOsMemory.kt
│           ├── CognitivePanel.kt           # NEW Cognitive UI
│           ├── CognitiveTrackerUi.kt
│           ├── CodeExecutionEngine.kt      # NEW WebView JS sandbox
│           ├── ErrorLogPanel.kt
│           ├── ExecutionLayer.kt
│           ├── ExternalMemory.kt           # NEW disk notes
│           ├── LatexText.kt
│           ├── MemorySystems.kt            # NEW semantic/episodic/procedural memory
│           ├── MesaEngine.kt
│           ├── MetacognitiveMonitor.kt     # NEW metacognitive control
│           ├── NativeRecursiveRefiner.kt
│           ├── ReasoningOperators.kt       # NEW operator prompts
│           ├── RefinerCore.kt
│           ├── RefinerPanel.kt
│           ├── SearchUi.kt
│           ├── ThinkingUi.kt
│           └── WebSearchClient.kt
├── build-support/
│   └── patch_llama_refiner.py
└── llamaLib/
    ├── build.gradle.kts
    ├── consumer-rules.pro
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── cpp/CMakeLists.txt
        └── java/...
```

---

## 4. Key files for the next assistant

| File | Why it matters |
|---|---|
| `CognitiveEngine.kt` | Main SOR reasoning loop. Edit this to change how the system thinks. |
| `MemorySystems.kt` | Semantic/episodic/procedural/working memory. Edit this to change forgetting/reinforcement. |
| `MetacognitiveMonitor.kt` | Strategy selection, stuck detection, confidence. |
| `ReasoningOperators.kt` | Prompts for each cognitive operator. |
| `CodeExecutionEngine.kt` | WebView JS sandbox for reality checks. |
| `ExternalMemory.kt` | Disk-based notebook. |
| `CognitivePanel.kt` | UI for the new Cognitive tab. |
| `MainActivity.kt` | App shell. Added a new "Cognitive" tab. |
| `build-support/patch_llama_refiner.py` | Patches llama.cpp during GitHub Actions. |
| `USE_THIS_SHORT_WORKFLOW.yml` | The short workflow to paste into GitHub. |

---

## 5. How to build the APK from mobile

### What to upload to GitHub

1. **`AIUIBuilder.zip`** — upload to the **repo root**.
2. **`AIUIBuilder/USE_THIS_SHORT_WORKFLOW.yml`** — paste contents into `.github/workflows/mobile-build.yml`.

### Steps

1. Go to your GitHub repo in a mobile browser.
2. Upload/replace `AIUIBuilder.zip` at the root.
3. Edit `.github/workflows/mobile-build.yml` and paste the content from `USE_THIS_SHORT_WORKFLOW.yml`.
4. Commit.
5. Go to **Actions → AIUIBuilder Mobile Build → Run workflow**.
6. Wait ~15–90 minutes (depends on GitHub runner load and NDK build time).
7. Download artifact **`AIUIBuilder-Recursive-Refiner-GGUF-debug-apk`**.
8. Extract the ZIP and install `app-debug.apk`.

### Important YAML copy/paste rules

- GitHub needs real symbols: `&&`, `<<`, `>`, `<`.
- Do NOT paste HTML-escaped symbols like `&amp;&amp;`, `&lt;`, `&gt;`.
- The workflow is intentionally short (~65 lines) to avoid mobile copy/paste errors.

---

## 6. Current known issues / watch-outs

1. **New code is untested in a real APK build.** The Cognitive Engine and memory systems were written in this session. Expect at least one compile/fix cycle.
2. **Cognitive mode speed.** Each operator is one LLM call. On a 1B–3B model this may be several seconds per operator; 20 operators = minutes. The prompt size is bounded, so it does not slow down as iterations grow.
3. **WebView code execution.** Runs on the main thread. Long scripts can hang. Keep generated scripts tiny (<10 lines, <5s timeout).
4. **Strict KV cache.** Default should remain `OFF` for Granite/MoE. Only enable for dense models after testing.
5. **Context overflow is prevented** by the working-memory cap, but bad retrieval or a missing operator can still cause loops.

---

## 7. Safe first test

After installing the APK:

1. Load a small GGUF model (1B–3B, Q4 or Q5).
2. Go to **Cognitive** tab.
3. Enter a complex question like:
   - *"What is a mathematical function? Explain using real-world analogy and verify with a simple code example."*
   - *"How does quantum error correction work? Break it down from first principles."*
4. Tap **Think**.
5. Watch the reasoning trace and final answer.
6. If it crashes, check **Logs** tab and share the stack trace.

---

## 8. Rules for the next assistant

- Edit files in `/home/user/AIUIBuilder/`.
- Always regenerate `AIUIBuilder.zip` after changes:

```bash
cd /home/user
rm -f AIUIBuilder.zip
zip -r AIUIBuilder.zip AIUIBuilder \
  -x 'AIUIBuilder/MOBILE_ONLY_BUILD_WORKFLOW*.yml' \
     'AIUIBuilder/MOBILE_WORKFLOW_PATCH_STEP.txt' \
     'AIUIBuilder/FIX_LOGGING_PATCH.txt' \
     'AIUIBuilder/HANDOFF_TO_NEXT_SESSION.md' \
     'AIUIBuilder/RESEARCH_*.md' \
     'AIUIBuilder/ARCHITECTURE_*.md' \
     'AIUIBuilder/AIUIBuilder_FULL_SOURCE_BUNDLE.md'
```

- Keep the workflow short. Do not paste giant base64-encoded YAML.
- If changing native C++, prefer editing `build-support/patch_llama_refiner.py` because llama.cpp is cloned fresh every build.
- Preserve stability: do not turn strict KV on by default for Granite/MoE.
- If adding UI, keep it in a separate file; do not bloat `MainActivity.kt` further.
- Log everything important via `AppLog.logStructured(...)` so the user can debug from the Logs tab.

---

## 9. Suggested opening prompt for the user in next session

```text
I am continuing my AIUIBuilder Android project. Please read HANDOFF_TO_NEXT_SESSION.md and ARCHITECTURE_WorkingMemory_Forgetting.md in the workspace. The app is a Kotlin Jetpack Compose Android app that runs local GGUF models through llama.cpp. I build from mobile using AIUIBuilder.zip + USE_THIS_SHORT_WORKFLOW.yml on GitHub Actions. Continue from the current state, preserve the cognitive engine + bounded working memory + forgetting/reinforcement design, and regenerate AIUIBuilder.zip after changes.
```

Attach to the chat:

```text
AIUIBuilder.zip
AIUIBuilder/HANDOFF_TO_NEXT_SESSION.md
AIUIBuilder/ARCHITECTURE_WorkingMemory_Forgetting.md
```
