# Human-Brain Mimicry Architecture for AIUIBuilder (MESA v2)

> Goal: Make any locally-loaded GGUF model reason systematically like a human — activating prior knowledge, decomposing problems, grounding in reality, using metacognition, and evolving its own reasoning skills over time.  
> Constraint: Model weights stay frozen. All evolution happens in the **harness** (memory, operators, evaluators, prompts).  
> Hardware: Android mobile, standard ARM SoC, no neuromorphic silicon.

---

## 1. What human thinking actually looks like (the target)

From the research and your description, human cognition on a new topic follows this loop:

1. **Orient / Comprehend** — What is being asked? Parse the question, identify entities, unknowns, and emotional/cognitive salience.
2. **Activate prior knowledge** — What do I already know that relates? Retrieve from semantic memory (facts, principles) and episodic memory (similar past problems).
3. **Detect gaps** — What is missing? What confuses me? Mark uncertainty.
4. **Decompose / Chunk** — Break the complex whole into smaller, tractable sub-problems. Use first-principles reduction when lost.
5. **Select strategies** — For each chunk, pick a reasoning operator: analogy, calculation, verification, search, execution, etc.
6. **Execute & ground** — Solve the chunk. Use code, math, external search, or mental simulation to verify it against reality.
7. **Integrate** — Combine chunk results into a coherent whole. Check for contradictions.
8. **Metacognitive check** — Am I making progress? Am I stuck? Should I zoom in, zoom out, or change strategy?
9. **Consolidate** — Store successful reasoning traces as reusable skills; update semantic memory with what was learned.

The brain does this with **multiple memory systems** (hippocampus = fast episodic; cortex = slow semantic; basal ganglia = procedural habits) and a **global workspace** that serializes conscious processing. We implement algorithmic analogues of these.

---

## 2. Cognitive architecture blueprint

```
┌─────────────────────────────────────────────────────────────────┐
│                     GLOBAL WORKSPACE                           │
│  Current goal stack | active context | focus | partial result   │
└──────────────┬──────────────────────────────────────────────────┘
               │
    ┌──────────▼──────────┐    ┌──────────────┐    ┌──────────────┐
    │  REASONING ENGINE   │◄──►│  METACOGNITIVE│◄──►│  EVALUATION  │
    │  (State-Operator-  │    │  MONITOR      │    │  LENS POOL   │
    │   Result cycle)     │    │               │    │              │
    └──────────┬──────────┘    └──────────────┘    └──────────────┘
               │
    ┌──────────▼──────────┐    ┌──────────────┐    ┌──────────────┐
    │  MEMORY SYSTEMS    │    │  REALITY      │    │  EVOLUTIONARY│
    │  • Semantic graph   │    │  GROUNDING    │    │  ARCHIVE     │
    │  • Episodic buffer  │    │  • Code exec  │    │  • Skills    │
    │  • Procedural skills│    │  • Web search │    │  • Evaluators│
    │  • Meta-memory      │    │  • Math check │    │  • Prompts   │
    └─────────────────────┘    └──────────────┘    └──────────────┘
```

---

## 3. The State-Operator-Result (SOR) cycle

Inspired by SOAR, the engine repeatedly executes:

```
State: current problem state + goal stack + active memory
  ↓
Propose: which operators are applicable? (decompose, retrieve, analogize, verify, execute, synthesize)
  ↓
Select: which operator has highest priority given metacognitive assessment?
  ↓
Apply: run the operator (usually one native LLM call + deterministic post-processing)
  ↓
Update: update working memory, memory systems, and detect impasses
  ↓
(loop)
```

Operators are **not** prompts. They are small, deterministic Kotlin functions that build a tight prompt, call the LLM, and parse the result into structured memory updates. This is how we keep the system controlled and evolvable.

---

## 4. Operator catalog (what the system can *do*)

| Operator | Human analogue | Purpose |
|---|---|---|
| `ORIENT` | Read the question | Parse topic, extract unknowns, detect confusion |
| `RETRIEVE` | Recall what you know | Pull relevant beliefs/skills from memory |
| `DECOMPOSE` | Break into chunks | Convert complex problem into sub-goal tree |
| `FIRST_PRINCIPLES` | Ask “why does this exist?” | Reduce to foundational causes/principles |
| `ANALOGIZE` | “This is like…” | Find cross-domain structural mapping |
| `SOLVE_CHUNK` | Solve one small piece | Generate a concrete sub-answer |
| `EXECUTE` | Run a quick test | Use JavaScript sandbox to verify quantitative/logical claims |
| `VERIFY` | Check if it makes sense | Internal consistency + external search |
| `INTEGRATE` | Put it all together | Synthesize sub-answers into final answer |
| `REFLECT` | Metacognitive pause | Assess progress, detect stuckness, switch strategy |
| `CONSOLIDATE` | Learn from experience | Save successful trace as reusable skill |

---

## 5. Memory systems

### 5.1 Semantic Memory (`SemanticMemory` / belief graph)
- Nodes: concepts, principles, facts, claims
- Edges: `SUPPORTS`, `CONTRADICTS`, `DEPENDS_ON`, `ISA`, `PART_OF`, `CAUSES`
- Activation: ACT-R decay + centrality shielding (existing)
- New: concept hierarchy (`PART_OF`, `ISA`) for first-principles traversal

### 5.2 Episodic Memory (`EpisodicMemory`)
- Stores recent reasoning traces: `[goal, operator, result, surprise, success]`
- High-surprise traces replay during consolidation
- Cue-based retrieval: given current goal, find similar past episodes

### 5.3 Procedural Memory (`ProceduralMemory` / skill library)
- Reusable mini-strategies: “how to decompose a physics problem”, “how to verify a math claim”, “how to analogize biology→computing”
- Skills are extracted from successful episodic traces
- Skills are themselvesbelief nodes with conditions and actions

### 5.4 Meta-Memory (`MetaMemory`)
- What does the system know it knows?
- Confidence map over semantic nodes
- Knowledge-boundary detection: “I don’t have enough information about X”

---

## 6. Metacognitive monitor

Monitors the SOR cycle and emits control signals:

- **Progress tracker**: is the current operator making progress toward the goal?
- **Stuck detector**: has the same sub-goal been revisited without progress?
- **Confidence calibrator**: does the LLM’s confidence match verification results?
- **Strategy selector**: when stuck, choose a different operator or lower/higher abstraction level
- **Budget manager**: limit total iterations, native calls, and tokens per session

When stuck, the monitor can:
1. Zoom out (first-principles reduction)
2. Zoom in (decompose further)
3. Switch domain (analogize)
4. Verify reality (execute or search)
5. Ask for clarification (rare; usually the system keeps going)

---

## 7. Reality grounding / code execution

On Android, we use the **JavaScript sandbox** from `androidx.javascriptengine` (JavaScriptEngine) or a **WebView** with `addJavascriptInterface` to safely execute small scripts. The system can:

- Generate JavaScript/Python-like pseudocode to test a claim
- Execute the code in the sandbox
- Compare the output with the LLM’s prediction
- Flag contradictions and adjust confidence

For example, if the model claims “the Fibonacci sequence grows exponentially”, the system can run a quick JS loop to confirm and measure the ratio.

---

## 8. Evolution / self-improvement

The system evolves by:

1. **Skill extraction**: When a trace succeeds, generalize it into a procedural skill and store it.
2. **Evaluator evolution**: Maintain a pool of evaluation lenses (specificity, cross-domain, falsifiability, simplicity). A meta-critic updates their weights based on predictive accuracy.
3. **Prompt mutation**: Successful operator prompts are archived; occasionally the system generates variants and tests them.
4. **Archive-driven diversity**: MAP-Elites archive of reasoning styles, so the system does not collapse to one strategy.

This is **harness evolution**, not model evolution. The GGUF weights stay frozen.

---

## 9. Implementation plan

### Phase 1: Core cognitive engine
- `CognitiveEngine.kt` — SOR cycle orchestrator
- `MemorySystems.kt` — semantic + episodic + procedural + meta memory
- `ReasoningOperators.kt` — operator implementations
- `MetacognitiveMonitor.kt` — progress/stuck/confidence/strategy

### Phase 2: Reality grounding
- `CodeExecutionEngine.kt` — JavaScript sandbox integration
- `ExecutionLayer.kt` — update to use code execution for verification

### Phase 3: Integration
- Update `MainActivity.kt` to expose the new cognitive engine as a mode
- Update `RefinerCore.kt` to delegate to the engine
- Update `CognitiveOsMemory.kt` to use the new memory systems
- Update `MesaEngine.kt` to archive skills and evaluators

### Phase 4: Polish
- UI for reasoning trace, memory browser, skill viewer
- Zip and handoff update

---

## 10. Why this is different from a standard chain-of-thought

Standard CoT is one long text generation. This architecture is:

- **Modular**: each operator is a distinct, testable function.
- **Memory-aware**: it retrieves, updates, and consolidates knowledge across sessions.
- **Self-monitoring**: it detects when it is stuck and changes strategy.
- **Reality-grounded**: it executes code and searches the web to verify claims.
- **Evolving**: it extracts reusable skills and improves its evaluators over time.

This is the closest we can get on a 2026 Android phone without neuromorphic hardware or model fine-tuning.

---

## 11. Research grounding

- SOAR/ACT-R cognitive architectures [1][2][3]
- Complementary Learning Systems (hippocampus + cortex) [4][5][6]
- Predictive coding / Free Energy Principle [7][8]
- Analogical reasoning and conceptual blending [9][10]
- Metacognition in LLMs [11][12]
- Self-evolving agents / Darwin Gödel Machine [13][14]
- Code execution for reasoning verification [15]

---

## 12. Citations

[1] Laird, *The SOAR Cognitive Architecture*, 2012.  
[2] Anderson et al., *ACT-R*, 2004.  
[3] *Architectural Precedents for General Agents using LLMs*, arXiv:2505.07087, 2025.  
[4] McClelland et al., *Complementary Learning Systems*, 1995.  
[5] *A Neural Network Model of Complementary Learning Systems*, arXiv:2507.11393, 2025.  
[6] *Semi-parametric Memory Consolidation*, arXiv:2504.14727, 2025.  
[7] Friston, *The free-energy principle*, 2009.  
[8] *A prescriptive theory for brain-like inference*, arXiv:2410.19315, 2024.  
[9] *Unlocking LLM Creativity in Science through Analogical Reasoning*, arXiv:2605.11258, 2026.  
[10] *CHIMERA: Scientific Idea Recombinations*, arXiv:2505.20779, 2025.  
[11] *Think2: Grounded Metacognitive Reasoning in LLMs*, arXiv:2602.18806, 2026.  
[12] *LLMs Know When They Know, but Do Not Act on It*, arXiv:2605.14186, 2026.  
[13] *Darwin Gödel Machine*, arXiv:2505.22954, 2025.  
[14] *A Survey of Self-Evolving Agents*, arXiv:2507.21046, 2025/2026.  
[15] *The Illusion of Thinking*, arXiv:2507.10624, 2025.
